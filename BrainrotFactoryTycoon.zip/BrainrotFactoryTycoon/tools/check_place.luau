local fs = require("@lune/fs")
local roblox = require("@lune/roblox")
local path = require("@lune/process").args[1]
local raw = fs.readFile(path)
local place = roblox.deserializePlace(raw)
local workspace = place:GetService("Workspace")
local world = workspace:FindFirstChild("BrainrotWorld")
assert(world and #world.Plots:GetChildren()==8 and world.Scenery["Foundry Plaza"].CentralSpawn:IsA("SpawnLocation"))
for id=1,8 do
	local plot = world.Plots[string.format("Plot%02d",id)]
	assert(plot:GetAttribute("PlotId")==id and plot:GetAttribute("Owner")==0)
	assert(plot["Plot marquee"].OwnerTitle.Label:HasTag("FactoryText"))
end
assert(workspace.StreamingEnabled and workspace.StreamingMinRadius==96)
assert(raw:find('<int name="MaxPlayersInternal">8</int>',1,true))
assert(place.ServerScriptService.BrainrotServer.Boot:IsA("Script"))
assert(place.ServerScriptService.BrainrotServer.Services.AdminService:IsA("ModuleScript"))
assert(not place.ReplicatedStorage.Brainrot:FindFirstChild("AdminService"))
assert(place.ServerStorage.FactoryAssets.FactoryBuilder:IsA("ModuleScript"))
assert(place.ReplicatedStorage.Brainrot.EconomyConfig:IsA("ModuleScript"))
assert(place.StarterGui.FactoryHUD:IsA("ScreenGui"))
local client = place.StarterPlayer.StarterPlayerScripts.BrainrotClient
assert(client.Boot:IsA("LocalScript") and client.AdminController:IsA("ModuleScript"))
assert(not raw:find("TextChatCommand",1,true))
assert(raw:find('Instance.new("RemoteFunction")',1,true))
assert(place.Lighting.FactoryAtmosphere:IsA("Atmosphere"))
print("Rojo place deserialized successfully: baked map, eight plot slots, streaming, player limit and executable script placement")
