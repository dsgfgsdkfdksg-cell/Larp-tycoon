local mode = ...
local Config = require("../src/shared/EconomyConfig")
local Game = require("../src/shared/GameConfig")
local Economy = require("../src/server/Services/EconomyRules")(Config, Game)
local costumes = {
	{id="sahur", name="Tung Tung Tung Sahur"},
	{id="tralala", name="Tralalero Tralala"},
	{id="patapim", name="Brr Brr Patapim"},
	{id="saturnita", name="La Vacca Saturno Saturnita"},
}
local factory = {
	profile = {Stage=0,Cash=Game.StartCash,Chest=0,Costumes={}},
	shell = {SetAttribute=function() end},
}
local tick, stamp, beginning = 0, 0, 0
local csv = mode == "csv"
local within, longest = 0, 0
Economy.attach(factory,0)
local function time(value)
	local seconds = math.floor(value + .5)
	return string.format("%d:%02d:%02d", math.floor(seconds / 3600), math.floor(seconds / 60) % 60, seconds % 60)
end
if csv then print("id,floor,kind,name,price_usd,rate_before_usd_s,rate_after_usd_s,multiplier,wait_s,elapsed_s") end
local function pay(price)
	while factory.profile.Cash < price do
		if factory.profile.Cash + factory.profile.Chest >= price then
			Economy.collect(factory.profile)
			break
		end
		tick += 1
		assert(tick < 80000,"pacing exceeded the simulation bound")
		Economy.produce(factory,tick / 5)
	end
end
local function line(id,floor,kind,name,price,before,after,multiplier)
	local seconds = tick/5
	local waitTime = seconds-stamp
	if waitTime >= 30 and waitTime <= 180 then within += 1 end
	longest = math.max(longest,waitTime)
	if csv then
		print(string.format('%s,%d,%s,"%s",%d,%d,%d,%.4g,%.1f,%.1f',id,floor,kind,name,price,before,after,multiplier,waitTime,seconds))
	end
	stamp = seconds
end
for index, spec in ipairs(Config.Upgrades) do
	local prevRate = Config.Stages[index-1].rate
	pay(spec.price)
	assert(Economy.buyUpgrade(factory.profile,spec))
	Economy.syncLanes(factory,tick/5)
	line(spec.id,spec.floor,"upgrade",spec.en,spec.price,prevRate,spec.rate,spec.multiplier)
	if spec.order == 20 then
		local costume = costumes[spec.floor]
		local price = Config.CostumePrices[spec.floor]
		pay(price)
		assert(Economy.buyCostume(factory.profile,spec.floor,costume))
		line(costume.id,spec.floor,"costume",costume.name,price,spec.rate,spec.rate,spec.multiplier)
		if not csv then
			print(string.format("Floor %d  %s  |  cumulative %s  |  $%d/s",spec.floor,time(stamp-beginning),time(stamp),spec.rate))
		end
		local target = ({1800,2400,3000,3600})[spec.floor]
		assert(math.abs(stamp-beginning-target) <= target*.035,"pacing is outside 3.5% target")
		beginning = stamp
	end
end
assert(factory.profile.Stage == 80 and factory.profile.Cash >= 0 and factory.profile.Chest >= 0)
if not csv then print(string.format("Total %s | 30-180 s waits: %d of 84 | longest wait: %.1f s",time(stamp),within,longest)) end
