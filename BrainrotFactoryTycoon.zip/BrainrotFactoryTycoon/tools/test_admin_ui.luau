-- Mount the Roblox GUI with Lune instances and simulate button activation and replicated attributes.
local fs = require("@lune/fs")
local roblox = require("@lune/roblox")
local gameConfig = require("../src/shared/GameConfig")
local locale = require("../src/shared/Locale")
local fmt = require("../src/shared/NumberFormat")

local buttons = {}
roblox.implementProperty("TextButton","Activated",function(button)
	return {Connect=function(_,callback) buttons[button]=callback end}
end)

local values = {Ready=true,Language="en",Cash=1000,Floor=1}
local listeners = {}
local player = {LocaleId="en-us"}
function player:GetAttribute(key) return values[key] end
function player:GetAttributeChangedSignal(key)
	return {Connect=function(_,callback) listeners[key]=callback end}
end
local function replicate(key,value)
	values[key]=value
	if listeners[key] then listeners[key]() end
end

local shared = {GameConfig=gameConfig,Locale=locale,NumberFormat=fmt}
local services = {
	Players={LocalPlayer=player},
	ReplicatedStorage={WaitForChild=function() return shared end},
}
local gui = roblox.Instance.new("ScreenGui")
local hud = roblox.Instance.new("Frame")
hud.Parent = gui
local title = roblox.Instance.new("TextLabel")
title.Parent = hud
local requests = {}
local resetToken = "00000000-0000-0000-0000-000000000001"
local remote = {}
function remote:InvokeServer(action,value)
	table.insert(requests,{action,value})
	if action=="setCash" then
		replicate("Cash",value)
		return "adminCashSet",value
	elseif action=="addCash" then
		replicate("Cash",values.Cash+value)
		return "adminCashAdded",value
	elseif action=="infiniteCash" then
		replicate("InfiniteCash",value)
		return value and "adminInfiniteOn" or "adminInfiniteOff"
	elseif action=="unlockFloor" then
		replicate("Floor",value)
		return "adminFloorDone",value
	elseif action=="maxBase" then
		return "adminMaxBaseDone"
	elseif action=="teleportHome" then
		return "noPlot"
	elseif action=="walkSpeed" then
		replicate("AdminSpeed",value)
		return "adminSpeedSet",value
	elseif action=="resetRequest" then
		return "adminResetPrompt",{token=resetToken,seconds=30}
	elseif action=="resetCancel" then
		return "adminResetCancelled"
	elseif action=="resetConfirm" then
		assert(value==resetToken)
		return "adminResetDone"
	end
	error("Unknown request")
end

local code = assert(loadstring(fs.readFile("src/client/AdminController.luau"),"AdminController"))
local env = {
	game={GetService=function(_, service) return assert(services[service]) end},
	require=function(value) return value end,
	task={
		spawn=function(fn) assert(coroutine.resume(coroutine.create(fn))) end,
		wait=coroutine.yield,
	},
}
for key, value in pairs(roblox) do env[key]=value end
setfenv(code,setmetatable(env,{__index=getfenv()}))
code().start(gui,hud,title,remote)

local function click(label)
	for button, callback in pairs(buttons) do
		if button.Text==label then callback() return end
	end
	error("Missing button: " .. label)
end
local function input(placeholder,value)
	for _, object in ipairs(gui:GetDescendants()) do
		if object:IsA("TextBox") and object.PlaceholderText==placeholder then
			assert(object.TextInputType==roblox.Enum.TextInputType.Number)
			object.Text=value
			return
		end
	end
	error("Missing input: " .. placeholder)
end
local function last(action,value)
	local call = requests[#requests]
	assert(call and call[1]==action and call[2]==value)
end

local panel = gui.AdminPanel
assert(not hud.AdminButton.Visible and not panel.Visible)
click("ADMIN")
assert(not panel.Visible and #requests==0)
replicate("AdminAllowed",true)
click("ADMIN")
assert(hud.AdminButton.Visible and panel.Visible)
input("Enter amount in dollars","1 000 000")
click("Set Cash")
last("setCash",1000000)
click("Add Cash")
last("addCash",1000000)
click("Infinite Cash · Off")
last("infiniteCash",true)
click("Infinite Cash · On")
last("infiniteCash",false)
click("Max Base")
last("maxBase")
click("4")
click("Unlock Floor")
last("unlockFloor",4)
input("Current speed: 16","50")
click("Set Walk Speed")
last("walkSpeed",50)
click("Teleport Home")
last("teleportHome")
click("Reset Progress")
last("resetRequest")
click("Cancel")
last("resetCancel")
click("Reset Progress")
click("Confirm Reset")
last("resetConfirm",resetToken)
replicate("Language","ru")
click("Сбросить прогресс")
last("resetRequest")
replicate("AdminAllowed",false)
assert(not hud.AdminButton.Visible and not panel.Visible)
local requestCount = #requests
click("Подтвердить сброс")
assert(#requests==requestCount)
replicate("AdminAllowed",true)
click("ADMIN")
click("×")
assert(not panel.Visible)
print("Owner UI: verified visibility, numeric inputs, all actions, localization, reset, and panel close")
