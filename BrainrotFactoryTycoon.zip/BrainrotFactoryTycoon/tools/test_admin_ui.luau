-- Start the HUD and owner panel with Lune instances, button events, and replicated attributes.
local fs = require("@lune/fs")
local roblox = require("@lune/roblox")
local gameConfig = require("../src/shared/GameConfig")
local locale = require("../src/shared/Locale")
local fmt = require("../src/shared/NumberFormat")

local buttons = {}
roblox.implementProperty("TextButton","Activated",function(button)
	return {Connect=function(_,callback) buttons[button]=callback end}
end)

-- Lune supports the property for reflection. Studio denies this write to LocalScripts.
local objects, inputs = {}, {}
local function newInstance(class)
	local object = roblox.Instance.new(class)
	local changed = {}
	local proxy = setmetatable({},{
		__index=function(_,property)
			if property == "GetPropertyChangedSignal" then
				return function(_,name)
					return {Connect=function(_,callback) changed[name]=callback end}
				end
			end
			return object[property]
		end,
		__newindex=function(_,property,value)
			if class == "TextBox" and property == "TextInputType" then
				error("The current thread cannot write 'TextInputType' (lacking capability RobloxScript)")
			end
			object[property] = objects[value] or value
			if changed[property] then changed[property]() end
		end,
	})
	objects[proxy] = object
	if class == "TextBox" then table.insert(inputs,proxy) end
	return proxy
end

local values = {Ready=true,Language="en",Cash=1000,Floor=1}
local listeners = {}
local player = {LocaleId="en-us"}
function player:GetAttribute(key) return values[key] end
function player:GetAttributeChangedSignal(key)
	listeners[key] = listeners[key] or {}
	return {Connect=function(_,callback) table.insert(listeners[key],callback) end}
end
local function replicate(key,value)
	values[key]=value
	for _, callback in ipairs(listeners[key] or {}) do callback() end
end

local shared = {
	GameConfig=gameConfig, Locale=locale, NumberFormat=fmt, EconomyConfig=require("../src/shared/EconomyConfig"),
}
local services = {
	Players={LocalPlayer=player},
	ReplicatedStorage={WaitForChild=function() return shared end},
	TweenService={Create=function(_,object,_,goal)
		return {
			Play=function()
				for key, value in pairs(goal) do object[key]=value end
			end,
			Cancel=function() end,
		}
	end},
}
local gui = roblox.Instance.new("ScreenGui")
local requests = {}
local resetToken = "00000000-0000-0000-0000-000000000001"
local remote = {}
function remote:InvokeServer(action,value)
	table.insert(requests,{action,value})
	if action=="setCash" then
		replicate("Cash",value)
		return "adminCashSet",value
	elseif action=="addCash" then
		replicate("Cash",values.Cash+value)
		return "adminCashAdded",value
	elseif action=="infiniteCash" then
		replicate("InfiniteCash",value)
		return value and "adminInfiniteOn" or "adminInfiniteOff"
	elseif action=="unlockFloor" then
		replicate("Floor",value)
		return "adminFloorDone",value
	elseif action=="maxBase" then
		return "adminMaxBaseDone"
	elseif action=="teleportHome" then
		return "noPlot"
	elseif action=="walkSpeed" then
		replicate("AdminSpeed",value)
		return "adminSpeedSet",value
	elseif action=="resetRequest" then
		return "adminResetPrompt",{token=resetToken,seconds=30}
	elseif action=="resetCancel" then
		return "adminResetCancelled"
	elseif action=="resetConfirm" then
		assert(value==resetToken)
		return "adminResetDone"
	end
	error("Unknown request")
end

local noEvent = {Connect=function() end}
local env = {
	game={GetService=function(_, service) return assert(services[service]) end},
	require=function(value) return value end,
	workspace={GetPropertyChangedSignal=function() return noEvent end},
	TweenInfo={new=function() end},
	task={
		defer=function(fn) fn() end,
		spawn=function(fn) assert(coroutine.resume(coroutine.create(fn))) end,
		wait=coroutine.yield,
	},
}
for key, value in pairs(roblox) do env[key]=value end
env.Instance = {new=newInstance}
setmetatable(env,{__index=getfenv()})
local function loadModule(path)
	local code = assert(loadstring(fs.readFile(path),path))
	setfenv(code,env)
	return code()
end
shared.FloorConfig = loadModule("src/shared/FloorConfig.luau")
shared.CostumeConfig = loadModule("src/shared/CostumeConfig.luau")
env.script = {Parent={AdminController=loadModule("src/client/AdminController.luau")}}
loadModule("src/client/UIController.luau").start(gui,{Admin=remote,Feedback={OnClientEvent=noEvent}})

local function click(label)
	for button, callback in pairs(buttons) do
		if button.Text==label and (label~="×" or button:IsDescendantOf(gui.AdminPanel)) then callback() return end
	end
	error("Missing button: " .. label)
end
local function input(placeholder,value)
	for _, object in ipairs(inputs) do
		if object.PlaceholderText==placeholder then
			object.Text=value
			return object
		end
	end
	error("Missing input: " .. placeholder)
end
local function last(action,value)
	local call = requests[#requests]
	assert(call and call[1]==action and call[2]==value)
end

local panel, hud = gui.AdminPanel,gui.Dashboard
assert(gui.Navigation.Visible and not hud.AdminButton.Visible and not panel.Visible)
click("ADMIN")
assert(not panel.Visible and #requests==0)
replicate("AdminAllowed",true)
click("ADMIN")
assert(hud.AdminButton.Visible and panel.Visible)
local function rejects(field, text, action)
	local count = #requests
	input(field,text)
	click(action)
	assert(#requests==count,"Invalid value reached the server: " .. text)
end
local cashField = "Enter amount in dollars"
local cashInput = input(cashField,"1 000 000")
local neutralBorder = cashInput.UIStroke.Color
for _, invalid in ipairs({"","x20","-5","10.5","1e4","900000000000001","99999999999999999"}) do
	rejects(cashField,invalid,"Set Cash")
end
assert(cashInput.UIStroke.Color~=neutralBorder)
assert(cashInput.Text=="99999999999999999")
rejects(cashField,"0","Add Cash")
click("Set Cash")
last("setCash",0)
input(cashField,"1 000 000")
click("Set Cash")
last("setCash",1000000)
assert(cashInput.UIStroke.Color==neutralBorder)
input(cashField,"1\u{00A0}000\u{202F}000")
click("Add Cash")
last("addCash",1000000)
click("Infinite Cash · Off")
last("infiniteCash",true)
click("Infinite Cash · On")
last("infiniteCash",false)
click("Max Base")
last("maxBase")
click("4")
click("Unlock Floor")
last("unlockFloor",4)
for _, invalid in ipairs({"0","101","50km","5.5","-50","1e2"}) do
	rejects("Current speed: 16",invalid,"Set Walk Speed")
end
input("Current speed: 16","50")
click("Set Walk Speed")
last("walkSpeed",50)
click("Teleport Home")
last("teleportHome")
click("Reset Progress")
last("resetRequest")
click("Cancel")
last("resetCancel")
click("Reset Progress")
click("Confirm Reset")
last("resetConfirm",resetToken)
replicate("Language","ru")
click("Сбросить прогресс")
last("resetRequest")
replicate("AdminAllowed",false)
assert(not hud.AdminButton.Visible and not panel.Visible)
local requestCount = #requests
click("Подтвердить сброс")
assert(#requests==requestCount)
replicate("AdminAllowed",true)
click("ADMIN")
click("×")
assert(not panel.Visible)
print("HUD and owner UI: verified startup with restricted writes denied, integer validation, all actions, reset, and panel close")
