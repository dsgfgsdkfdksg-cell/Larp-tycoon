-- Run with Lune. This executes the actual Roblox builders with Lune's instance serializer.
local fs = require("@lune/fs")
local roblox = require("@lune/roblox")
local mode = require("@lune/process").args[1]

local workspace = roblox.Instance.new("Workspace")
local lighting = roblox.Instance.new("Lighting")
local shared = {
	GameConfig="src/shared/GameConfig.luau",
	NumberFormat="src/shared/NumberFormat.luau",
	EconomyConfig="src/shared/EconomyConfig.luau",
	FloorConfig="src/shared/FloorConfig.luau",
	CostumeConfig="src/shared/CostumeConfig.luau",
}
local assets = {
	Parts="src/assets/Parts.luau",
	CostumeBuilder="src/assets/CostumeBuilder.luau",
	FactoryBuilder="src/assets/FactoryBuilder.luau",
	WorldBuilder="src/assets/WorldBuilder.luau",
}
local serverModules = {DropperService="src/server/Services/DropperService.luau"}
local services = {
	Lighting=lighting, ServerStorage={WaitForChild=function() return assets end},
	ReplicatedStorage={WaitForChild=function() return shared end},
	CollectionService={AddTag=function(_, item, tag) item:AddTag(tag) end},
}
local loaded = {}
local function loadModule(path)
	if loaded[path] then return loaded[path] end
	local chunk = assert(loadstring(fs.readFile(path), "@" .. path))
	local env = {
		game={GetService=function(_, name) return assert(services[name], name) end},
		workspace=workspace, script={Parent=path=="src/server/Services/PlotService.luau" and serverModules or assets}, require=loadModule,
	}
	for name, typeObject in pairs(roblox) do env[name] = typeObject end
	setfenv(chunk,setmetatable(env,{__index=getfenv()}))
	local value = chunk()
	loaded[path] = value
	return value
end

local world = loadModule(assets.WorldBuilder)
local plots, spawn, board = world.build()
assert(spawn:IsA("SpawnLocation") and board:IsA("BasePart"))
for id=1,8 do world.plotShell(plots,id,world.plotFrame(id)) end
assert(#plots:GetChildren()==8 and world.build()==plots,"Eight reusable plots are required")

if mode == "bake" then
	if not fs.isDir("src/world") then fs.writeDir("src/world") end
	fs.writeFile("src/world/BrainrotWorld.rbxmx",roblox.serializeModel({plots.Parent},true))
	fs.writeFile("src/world/FactoryAtmosphere.rbxmx",roblox.serializeModel({lighting.FactoryAtmosphere},true))
	fs.writeFile("src/world/FactoryBloom.rbxmx",roblox.serializeModel({lighting.FactoryBloom},true))
	print("Baked the district, eight lots and lighting into src/world")
elseif mode == "test" then
	local factory = loadModule(assets.FactoryBuilder)
	local config = loadModule(shared.EconomyConfig)
	local costumes = loadModule(shared.CostumeConfig)
	local scene = roblox.Instance.new("Folder")
	scene.Parent = workspace
	local count, instances = 0, 0
	for plot = 1,8 do
		local frames = {}
		local plotFrame = world.plotFrame(plot)
		for floor=1,4 do
			local model = factory.floor(scene,plotFrame,floor)
			frames[floor] = model
			local costume = model:FindFirstChild("Display_" .. costumes[floor].id)
			assert(costume and #costume:GetChildren() >= 24,"Incomplete costume display")
			local deck = model.Deck
			assert(deck:FindFirstChild(floor==1 and "Foundation slab" or "Main slab").CanCollide)
		end
		for _, spec in ipairs(config.Upgrades) do
			local model = factory.upgrade(frames[spec.floor],plotFrame,spec)
			assert(#model:GetChildren()>0 and model:HasTag("FactoryBuild"))
			count += 1
			for _, object in ipairs(model:GetDescendants()) do
				if object:IsA("BasePart") then
					local point = plotFrame:PointToObjectSpace(object.CFrame.Position)
					assert(math.abs(point.X)<=44 and math.abs(point.Z)<=34 and point.Y<67,object.Name)
					assert(object.Anchored and not object.CanTouch)
					instances += 1
				end
			end
			if spec.order==1 then
				local marker = model.PacketStart
				assert(marker:GetAttribute("Floor")==spec.floor)
				assert((marker.CFrame.Position-marker:GetAttribute("Finish")).Magnitude > 55)
			elseif spec.kind=="stairs" then
				local steps = 0
				for _, part in ipairs(model:GetChildren()) do
					if part.Name=="Step" then
						steps += 1
						assert(part.CanCollide)
					end
				end
				assert(steps==19)
			end
		end
	end
	local builder = loadModule(assets.CostumeBuilder)
	for _, rig in ipairs({
		{"Head","Torso","Right Arm","Left Arm","Right Leg","Left Leg"},
		{"Head","UpperTorso","RightUpperArm","LeftUpperArm","RightUpperLeg","LeftUpperLeg","RightHand","LeftHand","RightFoot","LeftFoot"},
	}) do
		local character = roblox.Instance.new("Model")
		for _, name in ipairs(rig) do
			local bone = roblox.Instance.new("Part")
			bone.Name, bone.CFrame, bone.Parent = name,roblox.CFrame.identity,character
		end
		for _, costume in ipairs(costumes) do
			local worn = builder.wear(character,costume.id)
			assert(#worn:GetChildren()>=24)
			for _, item in ipairs(worn:GetChildren()) do
				assert(not item.CanCollide and item.Massless and not item.Anchored)
				assert(item.Weld.Part0.Parent==character and item.Weld.Part1==item)
			end
			worn:Destroy()
		end
	end
	roblox.implementProperty("ProximityPrompt","Triggered",function()
		return {Connect=function() end}
	end)
	local plotService = loadModule("src/server/Services/PlotService.luau")
	local sites = plotService.create({})
	local plot = sites[1]
	local owner = {UserId=41,DisplayName="Test owner"}
	local profile = {Stage=15,Cash=1000,Chest=0,Costumes={},Settings={Doors=true}}
	plotService.claim(plot,owner,profile,{})
	local previous = plot.factory
	assert(plot.buyPad and plot.door.CanCollide and #plot.floors==1)
	plot.shell:SetAttribute("LaneEpoch1",150)
	profile.Stage = #config.Upgrades
	plotService.rebuild(plot,{})
	assert(previous.Parent==nil and plot.factory.Parent==plot.factories)
	assert(plot.owner==owner and plot.profile==profile and #plot.floors==4 and plot.buyPad==nil)
	assert(plot.shell:GetAttribute("LaneEpoch1")==150 and plot.door.CanCollide)
	for floor=1,4 do assert(plot.costumePads[floor] and plot.liftPads[floor]) end
	for _, upgrade in ipairs(config.Upgrades) do
		assert(plot.floors[upgrade.floor]:FindFirstChild(upgrade.id),"Missing " .. upgrade.id)
	end
	plotService.release(plot,{})
	assert(plot.factory==nil and plot.claim and plot.shell:GetAttribute("LaneEpoch1")==nil)
	print("Verified rebuilding a claimed factory with all 80 upgrades, then releasing its plot")
	print("Verified non-colliding costume geometry and limb welds for R6 and R15")
	print(string.format("Constructed %d upgrades and 32 costume displays across 8 full factories (%d upgrade parts)",count,instances))
else
	error("Use bake or test")
end
