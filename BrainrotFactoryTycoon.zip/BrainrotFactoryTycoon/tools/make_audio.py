"""Render the game's original synth music and effects as mono PCM WAV."""
import math
from pathlib import Path
import struct
import wave

RATE = 24_000
TAU = math.tau
OUT = Path(__file__).resolve().parent.parent / "assets" / "audio"
OUT.mkdir(parents=True, exist_ok=True)


def render(name, seconds, signal):
    frames = bytearray()
    for index in range(round(RATE * seconds)):
        value = signal(index / RATE)
        frames.extend(struct.pack("<h", round(32767 * max(-1, min(1, value)))))
    with wave.open(str(OUT / f"{name}.wav"), "wb") as wav:
        wav.setparams((1, 2, RATE, 0, "NONE", "not compressed"))
        wav.writeframes(frames)


def note(midi):
    return 440 * 2 ** ((midi - 69) / 12)


def tone(frequency, t):
    return math.sin(TAU * frequency * t)


def attack(t, speed):
    return min(1, t * speed)


def chime(notes, step, volume):
    def signal(t):
        total = 0
        for index, midi in enumerate(notes):
            elapsed = t - index * step
            if elapsed >= 0:
                frequency = note(midi)
                total += (tone(frequency, elapsed) + .24 * tone(frequency * 2, elapsed)) * (
                    volume * attack(elapsed, 200) * math.exp(-elapsed * 9)
                )
        return total
    return signal


def background(t):
    beat = .58
    pulse = beat / 2
    index = int(t / pulse)
    local = t - index * pulse
    chords = [(48, 55, 60, 64), (45, 52, 60, 64), (41, 53, 57, 60), (43, 50, 55, 62)]
    order = [1, 2, 3, 2, 1, 2, 3, 2]
    chord = chords[(index // 8) % 4]
    frequency = note(chord[order[index % 8]] + (12 if index % 8 in (3, 7) else 0))
    pluck = (tone(frequency, local) + .21 * tone(frequency * 2, local))
    pluck *= .18 * attack(local, 105) * math.exp(-local * 13)
    bass_time = t % beat
    bass = .16 * tone(note(chord[0]), bass_time) * attack(bass_time, 50) * math.exp(-bass_time * 7.6)
    tail = min(1, max(0, (beat * 32 - t) * 25))
    return (pluck + bass) * tail


def conveyor(t):
    slow = .55 + .45 * tone(9, t)
    hum = tone(65, t) + .21 * tone(130, t) + .1 * tone(260, t)
    return slow * hum * .25


def generator(t):
    envelope = attack(t, 90) * math.exp(-t * 12)
    return .45 * (tone(112 + 57 * t, t) + .37 * tone(219, t)) * envelope


render("Music", .58 * 32, background)
render("Conveyor", 1.6, conveyor)
render("Generator", .36, generator)
render("Collect", .65, chime([76, 83, 88], .07, .35))
render("Purchase", .71, chime([60, 67, 72], .06, .29))
render("Celebrate", 1.45, chime([67, 72, 76, 79, 84, 88], .097, .24))
