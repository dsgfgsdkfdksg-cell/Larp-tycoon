-- Plain Luau tests with substitutes for the Roblox scheduler, players, events and DataStore transport.
local config = require("../src/shared/EconomyConfig")
local gameConfig = require("../src/shared/GameConfig")
local ledger = require("../src/server/Services/EconomyRules")(config,gameConfig)
local profileCodec = require("../src/server/Services/Profile")
local tutorial = require("../src/server/Services/TutorialService")
local costumes = {{id="sahur"},{id="tralala"},{id="patapim"},{id="saturnita"}}
local fs = require("@lune/fs")
local roblox = require("@lune/roblox")

local shared = {
	EconomyConfig=config, GameConfig=gameConfig, CostumeConfig=costumes,
}
local modules = {Profile=profileCodec, EconomyService=ledger, TutorialService=tutorial}
local time = 100
local scheduled = {}
local scheduler = {
	wait=function() end,
	spawn=function(callback, ...) table.insert(scheduled,{callback,table.pack(...)}) end,
}
local function drain()
	while #scheduled > 0 do
		local item = table.remove(scheduled,1)
		item[1](table.unpack(item[2],1,item[2].n))
	end
end

local function signal()
	local callbacks = {}
	return {
		Connect=function(_, callback) table.insert(callbacks,callback) end,
		Fire=function(_, ...) for _, callback in ipairs(callbacks) do callback(...) end end,
	}
end

local records, failCount, guid = {},0,0
local store = {
	UpdateAsync=function(_, key, transform)
		if failCount > 0 then failCount -= 1 error("mock storage failure") end
		local record = transform(records[key])
		if record ~= nil then records[key] = record end
		return record
	end,
}
local run = {IsStudio=function() return false end,Heartbeat=signal()}
local players = {PlayerAdded=signal(),PlayerRemoving=signal(),list={}}
function players:GetPlayers() return self.list end
function players:GetPlayerByUserId(userId)
	for _, player in ipairs(self.list) do
		if player.UserId == userId then return player end
	end
end
local creator = {CreatorType=roblox.Enum.CreatorType.User,CreatorId=41}
local groupOwner, groupUnavailable = 41,false
local services = {
	Players=players, RunService=run,StarterPlayer={CharacterWalkSpeed=16},
	GroupService={GetGroupInfoAsync=function(_,id)
		assert(id==creator.CreatorId)
		if groupUnavailable then error("mock group lookup failure") end
		return {Owner=groupOwner and {Id=groupOwner}}
	end},
	ReplicatedStorage={WaitForChild=function() return shared end},
	DataStoreService={GetDataStore=function(_, _) return store end},
	HttpService={GenerateGUID=function() guid+=1 return string.format("00000000-0000-0000-0000-%012d",guid) end},
}
local function module(name)
	local source = fs.readFile("src/server/Services/" .. name .. ".luau")
	local code = assert(loadstring(source,"@" .. name))
	local env = {
		game=setmetatable({GetService=function(_, service) return assert(services[service],service) end,
			BindToClose=function(_,callback) services.shutdown = callback end},{__index=creator}),
		Enum=roblox.Enum,CFrame=roblox.CFrame,
		script={Parent=modules}, require=function(value) return assert(value,"missing module value") end,
		workspace={GetServerTimeNow=function() return time end},
		task=scheduler, warn=function() end,
		os={time=function() return math.floor(time) end,clock=function() return time end},
	}
	setfenv(code,setmetatable(env,{__index=getfenv()}))
	return code()
end
local function mockPlayer(id)
	local point = roblox.Vector3.new(0,0,0)
	local attributes = {}
	local avatar = {
		FindFirstChild=function(self,name) return name=="HumanoidRootPart" and self.root or {} end,
		FindFirstChildOfClass=function(self) return self.humanoid end,
		WaitForChild=function(self,name) return name=="Humanoid" and self.humanoid or {} end,
		humanoid={Health=100,WalkSpeed=16},
		PivotTo=function(self,destination) self.root.Position = destination.Position end,
		root={Position=point},
	}
	local player = {
		UserId=id, LocaleId="ru-ru", DisplayName="Player" .. id, Parent=players,
		Character=avatar, CharacterAdded=signal(), CharacterAppearanceLoaded=signal(),
		SetAttribute=function(_,key,val) attributes[key]=val end,
		GetAttribute=function(_,key) return attributes[key] end,
		RequestStreamAroundAsync=function() end,
		Kick=function(self,text) self.kicked=text end,
	}
	return player
end

local A, B = module("DataService"),module("DataService")
local old = mockPlayer(33)
records.player_33 = {Version=1,Cash=2500,Chest=900,Stage=15,Costumes={},Settings={Language="ru",Sound=false},Tutorial=5}
failCount = 1
local saved = assert(A.acquire(old))
assert(saved.Cash==2500 and saved.Chest==900 and saved.Stage==15 and not saved.Settings.Sound)
local result, reason = B.acquire(mockPlayer(33))
assert(result==nil and reason=="busy")
local originalLease = records.player_33.Lease.Token
saved.Cash = 4444
A.autosave(33)
assert(records.player_33.Cash==4444 and records.player_33.Lease.Token==originalLease)
failCount = 4
A.release(old)
assert(records.player_33.Lease.Token==originalLease and A.get(old)==nil)
A.maintain(false)
drain()
assert(records.player_33.Lease==nil)
local newer = mockPlayer(33)
local newProfile = assert(B.acquire(newer))
assert(newProfile.Cash==4444 and newProfile.Tutorial==5)
time += gameConfig.LeaseSeconds+1
local takeover = mockPlayer(33)
local takeoverProfile = assert(A.acquire(takeover))
takeoverProfile.Cash = 9999
A.autosave(33)
newProfile.Cash = 1
B.autosave(33)
assert(B.get(newer)==nil and records.player_33.Cash==9999)
B.release(newer)
A.release(takeover)
records.player_999 = {Version=100,Cash=9876}
assert(A.acquire(mockPlayer(999)) == nil and records.player_999.Version==100 and records.player_999.Cash==9876)
print("DataStore substitute: verified retry, v1 migration, snapshot, failed release recovery, lease takeover and unknown versions")

local currentPlots = {}
local origin = roblox.Vector3.zero
local function pad(position) return {Parent=true,Position=position or origin} end
local function shell() return {SetAttribute=function() end} end
local handlers
local function currentPad(plot)
	plot.buyPad = pad()
	return plot.buyPad
end
modules.PlotService = {
	create=function(callbacks)
		handlers = callbacks
		for i=1,8 do currentPlots[i]={id=i, claim=pad(), shell=shell()} end
		return currentPlots,{CFrame=roblox.CFrame.new(0,1,0)},{}
	end,
	claim=function(plot,owner,profile)
		plot.owner,plot.profile,plot.claim,plot.costumePads = owner,profile,nil,{}
		currentPad(plot)
	end,
	upgrade=function(plot,upgrade)
		if upgrade.order==20 then plot.costumePads[upgrade.floor] = pad() end
		if upgrade.index==15 then plot.door = true end
		currentPad(plot)
	end,
	rebuild=function(plot)
		plot.rebuiltAt = plot.profile.Stage
		plot.floors = table.create(config.floorFor(plot.profile.Stage),true)
		plot.costumePads = {}
		for floor, costume in ipairs(costumes) do
			if plot.profile.Stage >= floor*20 and not plot.profile.Costumes[costume.id] then
				plot.costumePads[floor] = pad()
			end
		end
		if plot.profile.Stage < #config.Upgrades then currentPad(plot) else plot.buyPad = nil end
	end,
	refresh=function() end,
	release=function(plot)
		plot.owner,plot.profile,plot.production,plot.infiniteCash=nil,nil,nil,nil
		plot.claim = pad()
	end,
	costumeBought=function(plot,floor) plot.costumePads[floor]=nil end,
	setDoors=function() end,
	entry=function() return roblox.CFrame.new(0,4,22) end,
}
modules.DataService = A
modules.PurchaseService = module("PurchaseService")
modules.CollectorService = module("CollectorService")
modules.ConveyorService = module("ConveyorService")
modules.CostumeService = {
	valid=function(profile,id) return id=="" or profile.Costumes[id]==true end,
	apply=function(character,id) if character then character.wearing=id end end,
	mask=function() return 0 end,
}
modules.LeaderboardService = {sync=function() end,start=function() end}
modules.AdminService = module("AdminService")
local function remote()
	local messages = {}
	return {OnServerEvent=signal(),messages=messages,FireClient=function(_,player,key,value)
		table.insert(messages,{player=player,key=key,value=value})
	end}
end
local network = {Feedback=remote(),WorldFX=remote(),Action=remote(),Admin={}}
local one,two = mockPlayer(41),mockPlayer(42)
players.list = {one,two}
module("TycoonService").start(network)
-- Run the existing players' synchronous mock load tasks. Leave the background loop scheduled.
for _=1,2 do
	local launch = table.remove(scheduled,1)
	launch[1](table.unpack(launch[2],1,launch[2].n))
end
local function runLastTask()
	local item = table.remove(scheduled)
	item[1](table.unpack(item[2],1,item[2].n))
end
runLastTask()
runLastTask()
assert(one:GetAttribute("AdminAllowed")==true and two:GetAttribute("AdminAllowed")==false)
assert(one:GetAttribute("Cash")==1000 and two:GetAttribute("Cash")==1000)
local p1,p2 = currentPlots[1],currentPlots[2]
handlers.claim(one,p1,p1.claim)
assert(p1.owner==one and one:GetAttribute("Tutorial")==1)
time+=1
handlers.claim(one,p2,p2.claim)
handlers.claim(two,p1,pad())
assert(p2.owner==nil and p1.owner==one and two:GetAttribute("PlotId")==0)
time+=1
handlers.claim(two,p2,p2.claim)
assert(p2.owner==two)

local starter = config.Upgrades[1]
handlers.upgrade(two,p1,p1.buyPad,starter)
assert(p1.profile.Stage==0)
one.Character.root.Position = roblox.Vector3.new(400,0,0)
handlers.upgrade(one,p1,p1.buyPad,starter)
assert(p1.profile.Stage==0)
one.Character.root.Position = origin
time+=1
handlers.upgrade(one,p1,p1.buyPad,config.Upgrades[2])
assert(p1.profile.Stage==0 and p1.profile.Cash==1000)
time+=1
local spentPad = p1.buyPad
handlers.upgrade(one,p1,spentPad,starter)
assert(p1.profile.Stage==1 and p1.profile.Cash==0 and one:GetAttribute("Tutorial")==2)
time+=1
handlers.upgrade(one,p1,spentPad,starter)
handlers.upgrade(one,p1,p1.buyPad,starter)
assert(p1.profile.Stage==1 and p1.profile.Cash==0)
time+=1.5
run.Heartbeat:Fire(.21)
assert(p1.profile.Chest==24 and p1.profile.Cash==0 and one:GetAttribute("Tutorial")==3)
local collect = pad()
handlers.collect(two,p1,collect)
assert(p1.profile.Chest==24 and p2.profile.Cash==1000)
handlers.collect(one,p1,collect)
assert(p1.profile.Cash==24 and p1.profile.Chest==0 and one:GetAttribute("Tutorial")==4)
handlers.collect(one,p1,collect)
assert(p1.profile.Cash==24)
time+=1
network.Action.OnServerEvent:Fire(one,"equip","sahur")
assert(one.Character.wearing=="")
network.Action.OnServerEvent:Fire(one,{"equip"},"sahur")
assert(one.Character.wearing=="")
time+=1
network.Action.OnServerEvent:Fire(one,"teleport")
assert(one.Character.root.Position==roblox.Vector3.new(0,4,22))
one.Character.root.Position=origin

p1.profile.Cash=gameConfig.MaxCash
for index=2,80 do
	time+=1
	local spec = config.Upgrades[index]
	handlers.upgrade(one,p1,p1.buyPad,spec)
	assert(p1.profile.Stage==index)
	if spec.order==20 then
		time+=1
		handlers.costume(one,p1,p1.costumePads[spec.floor],spec.floor)
		assert(p1.profile.Costumes[costumes[spec.floor].id])
	end
end
assert(one:GetAttribute("Rate")==1000000 and one:GetAttribute("Tutorial")==5)
for n=1,4 do assert(p1.production[n]~=nil) end
network.Action.OnServerEvent:Fire(one,"equip","saturnita")
assert(one.Character.wearing=="saturnita")
time+=1
network.Action.OnServerEvent:Fire(one,"music",false)
assert(one:GetAttribute("Music")==false)
players.PlayerRemoving:Fire(one)
assert(p1.owner==nil and p1.claim.Parent and records.player_41.Lease==nil)
local nextOne = mockPlayer(41)
players.PlayerAdded:Fire(nextOne)
assert(nextOne:GetAttribute("Stage")==80 and nextOne:GetAttribute("PlotId")==0 and nextOne.Character.wearing=="saturnita")
assert(nextOne:GetAttribute("Music")==false)
time+=1
handlers.claim(nextOne,p1,p1.claim)
assert(p1.owner==nextOne and p1.profile.Stage==80 and p1.profile.Costumes.saturnita and p1.profile.Tutorial==5)
assert(config.Stages[7].multiplier==2 and config.Stages[7].rate==2*config.Stages[6].rate)
local savedAgain = profileCodec.snapshot(p1.profile,config)
assert(#savedAgain.Purchased==80 and savedAgain.UnlockedFloors==4)
print("Tycoon routes with Roblox substitutes: verified two players, claim, distance, ownership, duplicate guards, all purchases, rewards and profile restoration")

local function invoke(player, action, value, ...)
	time += 1
	return network.Admin.OnServerInvoke(player,action,value,...)
end
players.list={nextOne,two}
runLastTask()
assert(nextOne:GetAttribute("AdminAllowed")==true)
two.DisplayName=nextOne.DisplayName
A.autosave(42)
for _, attempt in ipairs({
	{"addCash",1000000000}, {"setCash",10}, {"infiniteCash",true}, {"maxBase"},
	{"unlockFloor",4}, {"walkSpeed",50}, {"teleportHome"}, {"resetRequest"}, {"resetCancel"},
	{"resetConfirm","00000000-0000-0000-0000-000000000000"},
}) do
	assert(invoke(two,attempt[1],attempt[2])=="adminDenied","Public access to " .. attempt[1])
end
assert(p2.profile.Cash==1000 and p2.profile.Stage==0 and two.Character.humanoid.WalkSpeed==16)
network.Action.OnServerEvent:Fire(two,"addCash",1000000000)
network.Action.OnServerEvent:Fire(nextOne,"resetConfirm","confirm")
assert(p2.profile.Cash==1000 and p1.profile.Stage==80)
assert(invoke(nextOne,nil)=="adminInvalidValue")
assert(invoke(nextOne,"maxBase",nil,true)=="adminInvalidValue")
assert(invoke(nextOne,"cash",1000000000)=="adminInvalidValue")

local profile = assert(A.get(nextOne))
assert(invoke(nextOne,"setCash",0)=="adminCashSet" and nextOne:GetAttribute("Cash")==0)
local reply, credit = invoke(nextOne,"addCash",1000000000)
assert(reply=="adminCashAdded" and credit==1000000000 and nextOne:GetAttribute("Cash")==1000000000)
assert(network.Admin.OnServerInvoke(nextOne,"addCash",1)=="adminRateLimit")
for _, argument in ipairs({-1,0,1.5,"100",0/0,math.huge,gameConfig.MaxCash+1}) do
	assert(invoke(nextOne,"addCash",argument)=="adminInvalidValue")
end
assert(invoke(nextOne,"setCash","10")=="adminInvalidValue")
assert(invoke(nextOne,"infiniteCash",1)=="adminInvalidValue")
assert(invoke(nextOne,"unlockFloor",5)=="adminInvalidValue")
assert(invoke(nextOne,"unlockFloor",2.5)=="adminInvalidValue")
assert(invoke(nextOne,"walkSpeed",101)=="adminInvalidValue")
assert(profile.Cash==1000000000)
assert(invoke(nextOne,"setCash",gameConfig.MaxCash-5)=="adminCashSet")
reply,credit=invoke(nextOne,"addCash",10)
assert(reply=="adminCashAdded" and credit==5 and profile.Cash==gameConfig.MaxCash)
assert(invoke(nextOne,"addCash",10)=="adminCashLimit")
assert(invoke(nextOne,"walkSpeed",50)=="adminSpeedSet")
assert(nextOne.Character.humanoid.WalkSpeed==50 and profile.AdminWalkSpeed==50)
nextOne.Character.humanoid.WalkSpeed = 16
nextOne.CharacterAdded:Fire(nextOne.Character)
assert(nextOne.Character.humanoid.WalkSpeed==50)
assert(invoke(nextOne,"teleportHome")=="teleported")
assert(nextOne.Character.root.Position==roblox.Vector3.new(0,4,22))
assert(invoke(nextOne,"infiniteCash",true)=="adminInfiniteOn" and nextOne:GetAttribute("InfiniteCash"))

local key,pending = invoke(nextOne,"resetRequest")
assert(key=="adminResetPrompt" and pending.seconds==30 and profile.Stage==80)
assert(invoke(two,"resetConfirm",pending.token)=="adminDenied")
assert(invoke(nextOne,"resetCancel")=="adminResetCancelled")
assert(invoke(nextOne,"resetConfirm",pending.token)=="adminResetExpired")
key,pending=invoke(nextOne,"resetRequest")
time+=31
assert(invoke(nextOne,"resetConfirm",pending.token)=="adminResetExpired")
assert(profile.Stage==80 and p1.owner==nextOne)
key,pending=invoke(nextOne,"resetRequest")
assert(invoke(nextOne,"resetConfirm","00000000-0000-0000-0000-000000000000")=="adminResetExpired")
assert(invoke(nextOne,"resetConfirm",pending.token)=="adminResetDone")
assert(invoke(nextOne,"resetConfirm",pending.token)=="adminResetExpired")
assert(profile.Stage==0 and profile.Cash==1000 and profile.Chest==0 and profile.Tutorial==0)
assert(profile.Costumes.saturnita and profile.Equipped=="saturnita" and profile.AdminWalkSpeed==50 and not profile.Settings.Music)
assert(not profile.AdminInfiniteCash and not nextOne:GetAttribute("InfiniteCash"))
assert(p1.owner==nil and p1.claim and p2.owner==two and nextOne:GetAttribute("PlotId")==0)
assert(nextOne.Character.root.Position==roblox.Vector3.new(0,5,0))
runLastTask()
assert(#records.player_41.Purchased==0 and records.player_41.Cash==1000 and records.player_41.Chest==0)
assert(invoke(nextOne,"teleportHome")=="noPlot")
assert(invoke(nextOne,"unlockFloor",1)=="adminFloorDone" and profile.Stage==0)

nextOne.Character.root.Position=origin
handlers.claim(nextOne,p1,p1.claim)
assert(invoke(nextOne,"setCash",0)=="adminCashSet")
handlers.upgrade(nextOne,p1,p1.buyPad,starter)
assert(profile.Stage==0)
assert(invoke(nextOne,"infiniteCash",true)=="adminInfiniteOn" and p1.infiniteCash)
time+=1
handlers.upgrade(nextOne,p1,p1.buyPad,starter)
assert(profile.Stage==1 and profile.Cash==0)
profile.Costumes.sahur=nil
assert(invoke(nextOne,"unlockFloor",3)=="adminFloorDone")
assert(profile.Stage==40 and nextOne:GetAttribute("Floor")==3 and p1.rebuiltAt==40 and #p1.floors==3)
assert(invoke(nextOne,"unlockFloor",2)=="adminFloorDone" and profile.Stage==40)
time+=1
handlers.costume(nextOne,p1,p1.costumePads[1],1)
assert(profile.Costumes.sahur and profile.Cash==0)

creator.CreatorType,creator.CreatorId=roblox.Enum.CreatorType.Group,800
local before = config.Upgrades[profile.Stage+1]
groupOwner=42
time+=1
handlers.upgrade(nextOne,p1,p1.buyPad,before)
assert(profile.Stage==40 and not p1.infiniteCash and nextOne.Character.humanoid.WalkSpeed==16)
assert(invoke(nextOne,"maxBase")=="adminDenied" and invoke(two,"teleportHome")=="teleported")
groupUnavailable=true
assert(invoke(two,"maxBase")=="adminDenied")
groupUnavailable=false
creator.CreatorType,creator.CreatorId=roblox.Enum.CreatorType.User,0
assert(invoke(nextOne,"maxBase")=="adminDenied")
creator.CreatorId=41
assert(invoke(nextOne,"maxBase")=="adminMaxBaseDone")
assert(profile.Stage==80 and p1.rebuiltAt==80 and #p1.floors==4 and p1.production[4] and profile.Cash==0)
assert(invoke(nextOne,"infiniteCash",false)=="adminInfiniteOff" and not p1.infiniteCash and profile.Cash==0)
assert(invoke(nextOne,"setCash",4200)=="adminCashSet")
assert(invoke(nextOne,"infiniteCash",true)=="adminInfiniteOn")
key,pending=invoke(nextOne,"resetRequest")
players.PlayerRemoving:Fire(nextOne)
assert(#records.player_41.Purchased==80 and records.player_41.AdminWalkSpeed==50 and records.player_41.AdminInfiniteCash)
local returned = mockPlayer(41)
players.list={returned,two}
players.PlayerAdded:Fire(returned)
assert(returned:GetAttribute("Stage")==80 and returned.Character.humanoid.WalkSpeed==16)
runLastTask()
assert(returned.Character.humanoid.WalkSpeed==50 and returned:GetAttribute("InfiniteCash"))
assert(invoke(returned,"resetConfirm",pending.token)=="adminResetExpired")
assert(invoke(returned,"infiniteCash",false)=="adminInfiniteOff" and returned:GetAttribute("Cash")==4200)
key,pending=invoke(returned,"resetRequest")
assert(invoke(returned,"resetConfirm",pending.token)=="adminResetDone")
assert(invoke(returned,"unlockFloor",4)=="adminFloorDone" and returned:GetAttribute("Stage")==60 and returned:GetAttribute("PlotId")==0)
assert(invoke(returned,"maxBase")=="adminMaxBaseDone" and returned:GetAttribute("Stage")==80 and returned:GetAttribute("PlotId")==0)
print("Owner panel: verified all actions, permission and payload checks, infinite cash, saves, and one-time reset confirmation")
