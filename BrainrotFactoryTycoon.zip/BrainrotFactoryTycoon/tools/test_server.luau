-- Plain Luau tests with substitutes for the Roblox scheduler, players, events and DataStore transport.
local config = require("../src/shared/EconomyConfig")
local gameConfig = require("../src/shared/GameConfig")
local ledger = require("../src/server/Services/EconomyRules")(config,gameConfig)
local profileCodec = require("../src/server/Services/Profile")
local tutorial = require("../src/server/Services/TutorialService")
local costumes = {{id="sahur"},{id="tralala"},{id="patapim"},{id="saturnita"}}
local fs = require("@lune/fs")
local roblox = require("@lune/roblox")

local shared = {
	EconomyConfig=config, GameConfig=gameConfig, CostumeConfig=costumes,
}
local modules = {Profile=profileCodec, EconomyService=ledger, TutorialService=tutorial}
local time = 100
local scheduled = {}
local scheduler = {
	wait=function() end,
	spawn=function(callback, ...) table.insert(scheduled,{callback,table.pack(...)}) end,
}
local function drain()
	while #scheduled > 0 do
		local item = table.remove(scheduled,1)
		item[1](table.unpack(item[2],1,item[2].n))
	end
end

local function signal()
	local callbacks = {}
	return {
		Connect=function(_, callback) table.insert(callbacks,callback) end,
		Fire=function(_, ...) for _, callback in ipairs(callbacks) do callback(...) end end,
	}
end

local records, failCount, guid = {},0,0
local store = {
	UpdateAsync=function(_, key, transform)
		if failCount > 0 then failCount -= 1 error("mock storage failure") end
		local record = transform(records[key])
		if record ~= nil then records[key] = record end
		return record
	end,
}
local run = {IsStudio=function() return false end,Heartbeat=signal()}
local players = {PlayerAdded=signal(),PlayerRemoving=signal(),list={}}
function players:GetPlayers() return self.list end
function players:GetPlayerByUserId(userId)
	for _, player in ipairs(self.list) do
		if player.UserId == userId then return player end
	end
end
local creator = {CreatorType=roblox.Enum.CreatorType.User,CreatorId=41}
local commands = {}
local groupOwner, groupUnavailable = 41,false
local services = {
	Players=players, RunService=run,TextChatService={},
	GroupService={GetGroupInfoAsync=function(_,id)
		assert(id==creator.CreatorId)
		if groupUnavailable then error("mock group lookup failure") end
		return {Owner=groupOwner and {Id=groupOwner}}
	end},
	ReplicatedStorage={WaitForChild=function() return shared end},
	DataStoreService={GetDataStore=function(_, _) return store end},
	HttpService={GenerateGUID=function() guid+=1 return "lease-" .. guid end},
}
local function module(name)
	local source = fs.readFile("src/server/Services/" .. name .. ".luau")
	local code = assert(loadstring(source,"@" .. name))
	local env = {
		game=setmetatable({GetService=function(_, service) return assert(services[service],service) end,
			BindToClose=function(_,callback) services.shutdown = callback end},{__index=creator}),
		Enum=roblox.Enum,CFrame=roblox.CFrame,
		Instance={new=function(className)
			assert(className=="TextChatCommand")
			local command = {Triggered=signal()}
			table.insert(commands,command)
			return command
		end},
		script={Parent=modules}, require=function(value) return assert(value,"missing module value") end,
		workspace={GetServerTimeNow=function() return time end},
		task=scheduler, warn=function() end,
		os={time=function() return math.floor(time) end,clock=function() return time end},
	}
	setfenv(code,setmetatable(env,{__index=getfenv()}))
	return code()
end
local function mockPlayer(id)
	local point = roblox.Vector3.new(0,0,0)
	local attributes = {}
	local avatar = {
		FindFirstChild=function(self,name) return name=="HumanoidRootPart" and self.root or {} end,
		FindFirstChildOfClass=function(self) return self.humanoid end,
		WaitForChild=function(self,name) return name=="Humanoid" and self.humanoid or {} end,
		humanoid={Health=100,WalkSpeed=16},
		PivotTo=function(self,destination) self.root.Position = destination.Position end,
		root={Position=point},
	}
	local player = {
		UserId=id, LocaleId="ru-ru", DisplayName="Player" .. id, Parent=players,
		Character=avatar, CharacterAdded=signal(), CharacterAppearanceLoaded=signal(),
		SetAttribute=function(_,key,val) attributes[key]=val end,
		GetAttribute=function(_,key) return attributes[key] end,
		RequestStreamAroundAsync=function() end,
		Kick=function(self,text) self.kicked=text end,
	}
	return player
end

local A, B = module("DataService"),module("DataService")
local old = mockPlayer(33)
records.player_33 = {Version=1,Cash=2500,Chest=900,Stage=15,Costumes={},Settings={Language="ru",Sound=false},Tutorial=5}
failCount = 1
local saved = assert(A.acquire(old))
assert(saved.Cash==2500 and saved.Chest==900 and saved.Stage==15 and not saved.Settings.Sound)
local result, reason = B.acquire(mockPlayer(33))
assert(result==nil and reason=="busy")
local originalLease = records.player_33.Lease.Token
saved.Cash = 4444
A.autosave(33)
assert(records.player_33.Cash==4444 and records.player_33.Lease.Token==originalLease)
failCount = 4
A.release(old)
assert(records.player_33.Lease.Token==originalLease and A.get(old)==nil)
A.maintain(false)
drain()
assert(records.player_33.Lease==nil)
local newer = mockPlayer(33)
local newProfile = assert(B.acquire(newer))
assert(newProfile.Cash==4444 and newProfile.Tutorial==5)
time += gameConfig.LeaseSeconds+1
local takeover = mockPlayer(33)
local takeoverProfile = assert(A.acquire(takeover))
takeoverProfile.Cash = 9999
A.autosave(33)
newProfile.Cash = 1
B.autosave(33)
assert(B.get(newer)==nil and records.player_33.Cash==9999)
B.release(newer)
A.release(takeover)
records.player_999 = {Version=100,Cash=9876}
assert(A.acquire(mockPlayer(999)) == nil and records.player_999.Version==100 and records.player_999.Cash==9876)
print("DataStore substitute: verified retry, v1 migration, snapshot, failed release recovery, lease takeover and unknown versions")

local currentPlots = {}
local origin = roblox.Vector3.zero
local function pad(position) return {Parent=true,Position=position or origin} end
local function shell() return {SetAttribute=function() end} end
local handlers
local function currentPad(plot)
	plot.buyPad = pad()
	return plot.buyPad
end
modules.PlotService = {
	create=function(callbacks)
		handlers = callbacks
		for i=1,8 do currentPlots[i]={id=i, claim=pad(), shell=shell()} end
		return currentPlots,{CFrame=roblox.CFrame.new(0,1,0)},{}
	end,
	claim=function(plot,owner,profile)
		plot.owner,plot.profile,plot.claim,plot.costumePads = owner,profile,nil,{}
		currentPad(plot)
	end,
	upgrade=function(plot,upgrade)
		if upgrade.order==20 then plot.costumePads[upgrade.floor] = pad() end
		if upgrade.index==15 then plot.door = true end
		currentPad(plot)
	end,
	rebuild=function(plot)
		plot.rebuiltAt = plot.profile.Stage
		plot.floors = table.create(config.floorFor(plot.profile.Stage),true)
		plot.buyPad = nil
	end,
	refresh=function() end,
	release=function(plot)
		plot.owner,plot.profile,plot.production=nil,nil,nil
		plot.claim = pad()
	end,
	costumeBought=function(plot,floor) plot.costumePads[floor]=nil end,
	setDoors=function() end,
	entry=function() return roblox.CFrame.new(0,4,22) end,
}
modules.DataService = A
modules.PurchaseService = module("PurchaseService")
modules.CollectorService = module("CollectorService")
modules.ConveyorService = module("ConveyorService")
modules.CostumeService = {
	valid=function(profile,id) return id=="" or profile.Costumes[id]==true end,
	apply=function(character,id) if character then character.wearing=id end end,
	mask=function() return 0 end,
}
modules.LeaderboardService = {sync=function() end,start=function() end}
modules.AdminService = module("AdminService")
local function remote()
	local messages = {}
	return {OnServerEvent=signal(),messages=messages,FireClient=function(_,player,key,value)
		table.insert(messages,{player=player,key=key,value=value})
	end}
end
local network = {Feedback=remote(),WorldFX=remote(),Action=remote()}
local one,two = mockPlayer(41),mockPlayer(42)
players.list = {one,two}
module("TycoonService").start(network)
-- Run the existing players' synchronous mock load tasks. Leave the background loop scheduled.
for _=1,2 do
	local launch = table.remove(scheduled,1)
	launch[1](table.unpack(launch[2],1,launch[2].n))
end
assert(one:GetAttribute("Cash")==1000 and two:GetAttribute("Cash")==1000)
local p1,p2 = currentPlots[1],currentPlots[2]
handlers.claim(one,p1,p1.claim)
assert(p1.owner==one and one:GetAttribute("Tutorial")==1)
time+=1
handlers.claim(one,p2,p2.claim)
handlers.claim(two,p1,pad())
assert(p2.owner==nil and p1.owner==one and two:GetAttribute("PlotId")==0)
time+=1
handlers.claim(two,p2,p2.claim)
assert(p2.owner==two)

local starter = config.Upgrades[1]
handlers.upgrade(two,p1,p1.buyPad,starter)
assert(p1.profile.Stage==0)
one.Character.root.Position = roblox.Vector3.new(400,0,0)
handlers.upgrade(one,p1,p1.buyPad,starter)
assert(p1.profile.Stage==0)
one.Character.root.Position = origin
time+=1
handlers.upgrade(one,p1,p1.buyPad,config.Upgrades[2])
assert(p1.profile.Stage==0 and p1.profile.Cash==1000)
time+=1
local spentPad = p1.buyPad
handlers.upgrade(one,p1,spentPad,starter)
assert(p1.profile.Stage==1 and p1.profile.Cash==0 and one:GetAttribute("Tutorial")==2)
time+=1
handlers.upgrade(one,p1,spentPad,starter)
handlers.upgrade(one,p1,p1.buyPad,starter)
assert(p1.profile.Stage==1 and p1.profile.Cash==0)
time+=1.5
run.Heartbeat:Fire(.21)
assert(p1.profile.Chest==24 and p1.profile.Cash==0 and one:GetAttribute("Tutorial")==3)
local collect = pad()
handlers.collect(two,p1,collect)
assert(p1.profile.Chest==24 and p2.profile.Cash==1000)
handlers.collect(one,p1,collect)
assert(p1.profile.Cash==24 and p1.profile.Chest==0 and one:GetAttribute("Tutorial")==4)
handlers.collect(one,p1,collect)
assert(p1.profile.Cash==24)
time+=1
network.Action.OnServerEvent:Fire(one,"equip","sahur")
assert(one.Character.wearing=="")
network.Action.OnServerEvent:Fire(one,{"equip"},"sahur")
assert(one.Character.wearing=="")
time+=1
network.Action.OnServerEvent:Fire(one,"teleport")
assert(one.Character.root.Position==roblox.Vector3.new(0,4,22))
one.Character.root.Position=origin

p1.profile.Cash=gameConfig.MaxCash
for index=2,80 do
	time+=1
	local spec = config.Upgrades[index]
	handlers.upgrade(one,p1,p1.buyPad,spec)
	assert(p1.profile.Stage==index)
	if spec.order==20 then
		time+=1
		handlers.costume(one,p1,p1.costumePads[spec.floor],spec.floor)
		assert(p1.profile.Costumes[costumes[spec.floor].id])
	end
end
assert(one:GetAttribute("Rate")==1000000 and one:GetAttribute("Tutorial")==5)
for n=1,4 do assert(p1.production[n]~=nil) end
network.Action.OnServerEvent:Fire(one,"equip","saturnita")
assert(one.Character.wearing=="saturnita")
time+=1
network.Action.OnServerEvent:Fire(one,"music",false)
assert(one:GetAttribute("Music")==false)
players.PlayerRemoving:Fire(one)
assert(p1.owner==nil and p1.claim.Parent and records.player_41.Lease==nil)
local nextOne = mockPlayer(41)
players.PlayerAdded:Fire(nextOne)
assert(nextOne:GetAttribute("Stage")==80 and nextOne:GetAttribute("PlotId")==0 and nextOne.Character.wearing=="saturnita")
assert(nextOne:GetAttribute("Music")==false)
time+=1
handlers.claim(nextOne,p1,p1.claim)
assert(p1.owner==nextOne and p1.profile.Stage==80 and p1.profile.Costumes.saturnita and p1.profile.Tutorial==5)
assert(config.Stages[7].multiplier==2 and config.Stages[7].rate==2*config.Stages[6].rate)
local savedAgain = profileCodec.snapshot(p1.profile,config)
assert(#savedAgain.Purchased==80 and savedAgain.UnlockedFloors==4)
print("Tycoon routes with Roblox substitutes: verified two players, claim, distance, ownership, duplicate guards, all purchases, rewards and profile restoration")

assert(#commands==5)
local byAlias = {}
for _, command in ipairs(commands) do
	assert(command.Parent==services.TextChatService and command.AutocompleteVisible==false)
	byAlias[command.PrimaryAlias] = command
end
local function say(player, alias, message)
	time += 1
	local messages = network.Feedback.messages
	local count = #messages
	byAlias[alias].Triggered:Fire({UserId=player.UserId},message or alias)
	if #messages > count then
		local reply = messages[#messages]
		assert(reply.player==player)
		return reply.key,reply.value
	end
end
players.list={nextOne,two}
two.DisplayName=nextOne.DisplayName
for _, attempt in ipairs({
	{"/cash","/cash 1000000000"}, {"/maxbase"}, {"/resetbase"}, {"/resetbase","/resetbase confirm"},
	{"/setspeed","/setspeed 50"}, {"/adminhelp"},
}) do
	assert(say(two,attempt[1],attempt[2])==nil,"Unauthorized command generated feedback")
end
assert(p2.profile.Cash==1000 and p2.profile.Stage==0 and two.Character.humanoid.WalkSpeed==16)
network.Action.OnServerEvent:Fire(two,"cash",1000000000)
network.Action.OnServerEvent:Fire(nextOne,"resetbase","confirm")
assert(p2.profile.Cash==1000 and p1.profile.Stage==80)
assert(say(nextOne,"/adminhelp")=="adminHelp")

local profile = assert(A.get(nextOne))
profile.Cash = 1000
local reply, credit = say(nextOne,"/cash","/CASH 1000000000 ")
assert(reply=="adminCash" and credit==1000000000 and nextOne:GetAttribute("Cash")==1000001000)
byAlias["/cash"].Triggered:Fire({UserId=nextOne.UserId},"/cash 1000000000")
assert(profile.Cash==1000001000,"Immediate repeated command passed the cooldown")
for _, argument in ipairs({"-1","0","1.5","1e9","nan","100 50","900000000000001"}) do
	assert(say(nextOne,"/cash","/cash " .. argument)=="adminUsage")
end
assert(say(nextOne,"/cash","/cashier 100")==nil)
assert(profile.Cash==1000001000)
profile.Cash=gameConfig.MaxCash-5
reply,credit=say(nextOne,"/cash","/cash 10")
assert(reply=="adminCash" and credit==5 and profile.Cash==gameConfig.MaxCash)
assert(say(nextOne,"/cash","/cash 10")=="adminCashLimit")
assert(say(nextOne,"/setspeed","/setspeed 101")=="adminUsage")
assert(say(nextOne,"/setspeed","/setspeed 50")=="adminSpeed")
assert(nextOne.Character.humanoid.WalkSpeed==50 and profile.AdminWalkSpeed==50)
nextOne.Character.humanoid.WalkSpeed = 16
nextOne.CharacterAdded:Fire(nextOne.Character)
assert(nextOne.Character.humanoid.WalkSpeed==50)

creator.CreatorType, creator.CreatorId = roblox.Enum.CreatorType.Group,800
assert(say(nextOne,"/adminhelp")=="adminHelp" and say(two,"/adminhelp")==nil)
groupOwner=42
assert(say(nextOne,"/adminhelp")==nil and say(two,"/adminhelp")=="adminHelp")
nextOne.Character.humanoid.WalkSpeed=16
nextOne.CharacterAdded:Fire(nextOne.Character)
assert(nextOne.Character.humanoid.WalkSpeed==16,"A former owner retained saved speed after respawn")
groupUnavailable=true
assert(say(two,"/adminhelp")==nil)
groupUnavailable=false
creator.CreatorType,creator.CreatorId=roblox.Enum.CreatorType.User,0
assert(say(nextOne,"/adminhelp")==nil)
creator.CreatorId=41

assert(say(nextOne,"/resetbase","/resetbase confirm")=="adminResetExpired")
assert(say(nextOne,"/resetbase")=="adminResetPrompt")
time+=31
assert(say(nextOne,"/resetbase","/resetbase confirm")=="adminResetExpired")
assert(profile.Stage==80 and p1.owner==nextOne)
assert(say(nextOne,"/resetbase")=="adminResetPrompt")
assert(say(nextOne,"/resetbase","/resetbase confirm")=="adminResetDone")
assert(profile.Stage==0 and profile.Cash==1000 and profile.Chest==0 and profile.Tutorial==0)
assert(profile.Costumes.saturnita and profile.Equipped=="saturnita" and profile.AdminWalkSpeed==50 and not profile.Settings.Music)
assert(p1.owner==nil and p1.claim and p2.owner==two and nextOne:GetAttribute("PlotId")==0)
assert(nextOne.Character.root.Position==roblox.Vector3.new(0,5,0))
local save = table.remove(scheduled)
save[1](table.unpack(save[2],1,save[2].n))
assert(#records.player_41.Purchased==0 and records.player_41.Cash==1000 and records.player_41.Chest==0)
assert(say(nextOne,"/resetbase","/resetbase confirm")=="adminResetExpired")

handlers.claim(nextOne,p1,p1.claim)
assert(say(nextOne,"/maxbase")=="adminMaxBase")
assert(p1.profile.Stage==80 and p1.rebuiltAt==80 and #p1.floors==4 and p1.production[4])
assert(nextOne:GetAttribute("Stage")==80 and nextOne:GetAttribute("Rate")==1000000 and profile.Cash==1000)
assert(profile.Costumes.saturnita)
assert(say(nextOne,"/resetbase")=="adminResetPrompt")
players.PlayerRemoving:Fire(nextOne)
assert(#records.player_41.Purchased==80 and records.player_41.AdminWalkSpeed==50)
local returned = mockPlayer(41)
players.list={returned,two}
players.PlayerAdded:Fire(returned)
assert(returned:GetAttribute("Stage")==80 and returned.Character.humanoid.WalkSpeed==16)
local restore = table.remove(scheduled)
restore[1](table.unpack(restore[2],1,restore[2].n))
assert(returned.Character.humanoid.WalkSpeed==50)
assert(say(returned,"/resetbase","/resetbase confirm")=="adminResetExpired")
assert(say(returned,"/resetbase")=="adminResetPrompt")
assert(say(returned,"/resetbase","/resetbase confirm")=="adminResetDone")
assert(say(returned,"/maxbase")=="adminMaxBase" and returned:GetAttribute("Stage")==80 and returned:GetAttribute("PlotId")==0)
print("Owner commands: verified creator UserIds, group transfers, bad arguments, cash limits, speed persistence, confirmed reset and factory restoration")
