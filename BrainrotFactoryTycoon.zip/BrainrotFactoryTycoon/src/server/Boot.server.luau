local shared = game:GetService("ReplicatedStorage"):WaitForChild("Brainrot")
local network = Instance.new("Folder")
network.Name = "Network"
for _, name in ipairs({"Action","Feedback","WorldFX"}) do
	local event = Instance.new("RemoteEvent")
	event.Name = name
	event.Parent = network
end
network.Parent = shared

require(script.Parent.Services.TycoonService).start(network)
