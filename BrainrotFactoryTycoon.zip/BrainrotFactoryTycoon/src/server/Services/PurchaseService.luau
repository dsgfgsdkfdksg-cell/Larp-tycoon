local Shared = game:GetService("ReplicatedStorage"):WaitForChild("Brainrot")
local Costumes = require(Shared.CostumeConfig)
local Economy = require(script.Parent.EconomyService)
local Tutorial = require(script.Parent.TutorialService)
local Purchase = {}

function Purchase.upgrade(plot,spec,now)
	-- Settle production under the current rate before applying the new one.
	if Economy.produce(plot,now) > 0 then Tutorial.advance(plot.profile,3) end
	local ok, reason = Economy.buyUpgrade(plot.profile,spec)
	if not ok then return false,reason end
	Economy.syncLanes(plot,now)
	if spec.index == 1 then Tutorial.advance(plot.profile,2) end
	if spec.index == 2 then Tutorial.advance(plot.profile,5) end
	return true
end

function Purchase.costume(plot,floor)
	local costume = Costumes[floor]
	if not costume then return false,"locked" end
	return Economy.buyCostume(plot.profile,floor,costume)
end

return Purchase
