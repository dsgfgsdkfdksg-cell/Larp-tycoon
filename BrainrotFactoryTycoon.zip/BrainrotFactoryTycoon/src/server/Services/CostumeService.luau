local Assets = game:GetService("ServerStorage"):WaitForChild("FactoryAssets")
local Shared = game:GetService("ReplicatedStorage"):WaitForChild("Brainrot")
local Costumes = require(Shared.CostumeConfig)
local Builder = require(Assets.CostumeBuilder)
local Costume = {}
local previous = setmetatable({}, {__mode="k"})
local ids = {}
for _, costume in ipairs(Costumes) do ids[costume.id] = true end

function Costume.valid(profile,id)
	return id == "" or ids[id] == true and profile.Costumes[id] == true
end

function Costume.apply(character,id)
	if not character or not character.Parent then return end
	local oldModel = character:FindFirstChild("FactoryCostume")
	if oldModel then oldModel:Destroy() end
	local original = previous[character]
	if original then
		for part, value in pairs(original) do
			if part:IsDescendantOf(character) then part.Transparency = value end
		end
	end
	previous[character] = nil
	if not ids[id] or not character:FindFirstChild("Head") then return end
	original = {}
	for _, item in ipairs(character:GetDescendants()) do
		if (item:IsA("BasePart") or item:IsA("Decal")) and item.Name ~= "HumanoidRootPart"
			and not item:FindFirstAncestorOfClass("Tool") then
			original[item] = item.Transparency
		end
	end
	Builder.wear(character,id)
	for item in pairs(original) do item.Transparency = 1 end
	previous[character] = original
end

function Costume.mask(profile)
	local mask = 0
	for floor, item in ipairs(Costumes) do
		if profile.Costumes[item.id] then mask += 2^(floor-1) end
	end
	return mask
end

return Costume
