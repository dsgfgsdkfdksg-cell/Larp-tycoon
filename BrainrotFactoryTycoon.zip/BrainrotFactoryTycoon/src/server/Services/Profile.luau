local Profile = {}
Profile.Version = 2

local function number(value, default, limit)
	if type(value) == "number" and value == value then
		return math.floor(math.clamp(value, 0, limit))
	end
	return default
end

function Profile.read(raw, economy, gameConfig, costumes, fallbackLanguage)
	local empty = raw == nil
	if not empty and type(raw) ~= "table" then return nil end
	raw = raw or {}
	local version = raw.Version or 1
	if version ~= 1 and version ~= Profile.Version then return nil end
	local profile = {
		Cash = number(raw.Cash, raw.Cash == nil and gameConfig.StartCash or 0, gameConfig.MaxCash),
		Chest = number(raw.Chest, 0, gameConfig.MaxCash),
		Tutorial = number(raw.Tutorial, 0, 5),
		Stage = 0,
		Costumes = {},
		Equipped = "",
		Settings = { Language = fallbackLanguage, Music = true, Sound = true, Doors = false },
	}
	local speed = raw.AdminWalkSpeed
	if type(speed) == "number" and speed >= 1 and speed <= gameConfig.AdminMaxWalkSpeed and speed % 1 == 0 then
		profile.AdminWalkSpeed = speed
	end
	if type(raw.Purchased) == "table" then
		local owned = {}
		for key, value in pairs(raw.Purchased) do
			if type(value) == "string" then owned[value] = true end
			if type(key) == "string" and value == true then owned[key] = true end
		end
		for i, upgrade in ipairs(economy.Upgrades) do
			if not owned[upgrade.id] then break end
			profile.Stage = i
		end
	elseif version == 1 then
		profile.Stage = number(raw.Stage, 0, #economy.Upgrades)
	end
	if profile.Stage >= 2 then profile.Tutorial = 5 end
	if type(raw.Costumes) == "table" then
		for _, costume in ipairs(costumes) do
			if raw.Costumes[costume.id] == true or table.find(raw.Costumes, costume.id) then
				profile.Costumes[costume.id] = true
			end
		end
	end
	if type(raw.Equipped) == "string" and profile.Costumes[raw.Equipped] then
		profile.Equipped = raw.Equipped
	end
	if type(raw.Settings) == "table" then
		local source = raw.Settings
		for _, key in ipairs({"Music", "Sound", "Doors"}) do
			if type(source[key]) == "boolean" then profile.Settings[key] = source[key] end
		end
		if source.Language == "en" or source.Language == "ru" then profile.Settings.Language = source.Language end
	end
	return profile
end

function Profile.snapshot(profile, economy)
	local purchases = table.create(profile.Stage)
	for i = 1, profile.Stage do purchases[i] = economy.Upgrades[i].id end
	return {
		Version = Profile.Version, Cash = profile.Cash, Chest = profile.Chest,
		Purchased = purchases, UnlockedFloors = economy.floorFor(profile.Stage),
		Costumes = table.clone(profile.Costumes), Equipped = profile.Equipped,
		Settings = table.clone(profile.Settings), Tutorial = profile.Tutorial, AdminWalkSpeed = profile.AdminWalkSpeed,
	}
end

return Profile
