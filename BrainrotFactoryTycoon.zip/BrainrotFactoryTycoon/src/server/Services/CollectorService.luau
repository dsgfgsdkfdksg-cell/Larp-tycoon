local Economy = require(script.Parent.EconomyService)
local Tutorial = require(script.Parent.TutorialService)
local Collector = {}

function Collector.collect(plot, now)
	Economy.produce(plot, now)
	if plot.profile.Chest > 0 then Tutorial.advance(plot.profile, 3) end
	local amount = Economy.collect(plot.profile)
	if amount > 0 then Tutorial.advance(plot.profile, 4) end
	return amount
end

return Collector
