return function(Config, Game)
	local Economy = {}

	function Economy.attach(plot, now)
		plot.production = {}
		if plot.profile.Stage == 0 then return end
		Economy.syncLanes(plot, now)
	end

	function Economy.syncLanes(plot, now)
		for floor, rate in ipairs(Config.Stages[plot.profile.Stage].laneRates) do
			if rate > 0 and not plot.production[floor] then
				local due = now + Game.PacketInterval
				plot.production[floor] = { last = now, due = due, remainder = 0, pending = 0 }
				plot.shell:SetAttribute("LaneEpoch" .. floor, now)
			end
		end
	end

	function Economy.produce(plot, now)
		local total = 0
		local rates = Config.Stages[plot.profile.Stage].laneRates
		for floor, lane in pairs(plot.production) do
			local rate = rates[floor]
			if now > lane.last then
				if now + 0.000001 >= lane.due then
					local batches = math.floor((now - lane.due + 0.000001) / Game.PacketInterval)
					local cutoff = lane.due + batches * Game.PacketInterval
					local earned = lane.pending + lane.remainder + (cutoff - lane.last) * rate
					local arrived = math.floor(earned + 0.000001)
					total += arrived
					lane.remainder = earned - arrived
					lane.pending = (now - cutoff) * rate
					lane.due = cutoff + Game.PacketInterval
				else
					lane.pending += (now - lane.last) * rate
				end
				lane.last = now
			end
		end
		plot.profile.Chest = math.min(Game.MaxCash, plot.profile.Chest + total)
		return total
	end

	function Economy.collect(profile)
		local amount = math.min(profile.Chest, Game.MaxCash - profile.Cash)
		profile.Cash += amount
		profile.Chest -= amount
		return amount
	end

	function Economy.buyUpgrade(profile, upgrade)
		if not upgrade or upgrade.index ~= profile.Stage + 1 then return false, "locked" end
		if profile.Cash < upgrade.price then return false, "short" end
		profile.Cash -= upgrade.price
		profile.Stage = upgrade.index
		return true
	end

	function Economy.buyCostume(profile, floor, costume)
		if profile.Stage < floor * 20 then return false, "locked" end
		if profile.Costumes[costume.id] then return false, "owned" end
		local price = Config.CostumePrices[floor]
		if profile.Cash < price then return false, "short" end
		profile.Cash -= price
		profile.Costumes[costume.id] = true
		return true
	end

	return Economy
end
