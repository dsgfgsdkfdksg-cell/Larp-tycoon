local Tutorial = {}

function Tutorial.advance(profile, milestone)
	-- Monotonic even if a returning player skips an early prompt.
	if milestone == 5 or milestone == profile.Tutorial + 1 then
		profile.Tutorial = math.max(profile.Tutorial, milestone)
	end
end

return Tutorial
