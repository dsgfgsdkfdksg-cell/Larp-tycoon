local DataStoreService = game:GetService("DataStoreService")
local HttpService = game:GetService("HttpService")
local RunService = game:GetService("RunService")
local Shared = game:GetService("ReplicatedStorage"):WaitForChild("Brainrot")
local Settings = require(Shared.GameConfig)
local Economy = require(Shared.EconomyConfig)
local Costumes = require(Shared.CostumeConfig)
local Profile = require(script.Parent.Profile)

local inMemory = RunService:IsStudio() and Settings.StudioMemory
local store
if not inMemory then
	store = DataStoreService:GetDataStore(RunService:IsStudio() and Settings.StudioDataStore or Settings.DataStore)
end
local memory, sessions = {}, {}
local Data = {}

local function update(key, transform)
	if inMemory then
		local result = transform(memory[key])
		if result ~= nil then memory[key] = result end
		return result
	end
	return store:UpdateAsync(key, transform)
end

local function retry(callback, label, attempts)
	for attempt = 1, attempts do
		local ok, result = pcall(callback)
		if ok then return true, result end
		warn(string.format("[Factory] DataStore %s (%d/%d): %s", label, attempt, attempts, tostring(result)))
		if attempt < attempts then task.wait(math.min(2 ^ (attempt - 1), 6)) end
	end
	return false
end

function Data.acquire(player)
	local userId = player.UserId
	if sessions[userId] then return nil, "busy" end
	local entry = { key = "player_" .. userId, token = HttpService:GenerateGUID(false), player = player, opening = true }
	sessions[userId] = entry
	local fallback = string.sub(string.lower(player.LocaleId), 1, 2) == "ru" and "ru" or "en"
	for attempt = 1, 5 do
		local rejection
		local ok, result = retry(function()
			return update(entry.key, function(current)
				rejection = nil
				local profile = Profile.read(current, Economy, Settings, Costumes, fallback)
				if not profile then
					rejection = "unsupported"
					return nil
				end
				local lease = current and current.Lease
				local now = os.time()
				if type(lease) == "table" and lease.Token ~= entry.token and type(lease.Expires) == "number" and lease.Expires > now then
					rejection = "busy"
					return nil
				end
				-- Atomic lease claim and migration. The callback never accepts a failed read.
				local record = Profile.snapshot(profile, Economy)
				record.Lease = { Token = entry.token, Expires = now + Settings.LeaseSeconds }
				return record
			end)
		end, "load", 3)
		if ok and result and result.Lease and result.Lease.Token == entry.token then
			entry.profile = Profile.read(result, Economy, Settings, Costumes, fallback)
			entry.expires, entry.opening = result.Lease.Expires, false
			return entry.profile
		end
		if not ok or rejection ~= "busy" or attempt == 5 then
			sessions[userId] = nil
			return nil, rejection or "offline"
		end
		task.wait(2 + attempt)
	end
end

function Data.get(player)
	local entry = sessions[player.UserId]
	if entry and entry.player == player and not entry.opening and not entry.closing and not entry.lost and os.time() < entry.expires - 9 then
		return entry.profile
	end
	return nil
end

local function save(entry, release)
	local snapshot = Profile.snapshot(entry.profile, Economy)
	local ok, result = retry(function()
		return update(entry.key, function(current)
			local lease = type(current) == "table" and current.Lease
			if type(lease) ~= "table" or lease.Token ~= entry.token then return nil end
			local nextRecord = table.clone(snapshot)
			if not release then
				nextRecord.Lease = { Token = entry.token, Expires = os.time() + Settings.LeaseSeconds }
			end
			return nextRecord
		end)
	end, release and "release" or "save", release and 4 or 3)
	if ok and result then
		if not release then entry.expires = result.Lease.Expires end
		return true
	end
	if ok and not result then entry.lost = true end
	return entry.lost == true
end

function Data.autosave(userId)
	local entry = sessions[userId]
	if not entry or entry.opening or entry.closing or entry.saving or entry.lost then return end
	entry.saving = true
	save(entry, false)
	entry.saving = false
end

function Data.release(player)
	local entry = sessions[player.UserId]
	if not entry or entry.player ~= player or entry.opening or entry.releasing then return end
	entry.closing, entry.releasing = true, true
	while entry.saving do task.wait(.1) end
	local done = entry.lost or save(entry, true)
	if done then
		sessions[player.UserId] = nil
	else
		entry.releasing = false
	end
end

function Data.maintain(closing)
	for userId, entry in pairs(sessions) do
		if entry.closing then
			task.spawn(Data.release, entry.player)
		elseif not entry.opening then
			if closing then
				task.spawn(Data.release, entry.player)
			else
				task.spawn(Data.autosave, userId)
			end
		end
	end
end

function Data.hasSessions()
	return next(sessions) ~= nil
end

return Data
