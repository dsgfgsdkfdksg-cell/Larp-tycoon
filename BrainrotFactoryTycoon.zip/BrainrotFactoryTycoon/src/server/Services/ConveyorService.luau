local RunService = game:GetService("RunService")
local Economy = require(script.Parent.EconomyService)
local Tutorial = require(script.Parent.TutorialService)
local Data = require(script.Parent.DataService)
local Conveyor = {}

function Conveyor.start(plots, onDeposit)
	local since = 0
	RunService.Heartbeat:Connect(function(dt)
		since += dt
		if since < .2 then return end
		since = 0
		local now = workspace:GetServerTimeNow()
		for _, plot in ipairs(plots) do
			if plot.owner and Data.get(plot.owner) and Economy.produce(plot, now) > 0 then
				Tutorial.advance(plot.profile, 3)
				onDeposit(plot)
			end
		end
	end)
end

return Conveyor
