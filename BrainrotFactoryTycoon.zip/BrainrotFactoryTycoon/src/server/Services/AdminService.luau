local Players = game:GetService("Players")
local GroupService = game:GetService("GroupService")
local HttpService = game:GetService("HttpService")
local Shared = game:GetService("ReplicatedStorage"):WaitForChild("Brainrot")
local Game = require(Shared.GameConfig)

local Admin = {}
local confirmationSeconds = 30
local access, sessions = {}, {}
local onAccessChanged

local commands = {
	addCash = { min = 1, max = Game.MaxCash },
	setCash = { min = 0, max = Game.MaxCash },
	infiniteCash = { kind = "boolean" },
	unlockFloor = { min = 1, max = 4 },
	walkSpeed = { min = 1, max = Game.AdminMaxWalkSpeed },
	maxBase = {},
	teleportHome = {},
	resetRequest = {},
	resetCancel = {},
	resetConfirm = { kind = "string" },
}

function Admin.isOwner(player)
	if player.Parent ~= Players or player.UserId <= 0 or game.CreatorId <= 0 then return false end
	if game.CreatorType == Enum.CreatorType.User then return player.UserId == game.CreatorId end
	if game.CreatorType ~= Enum.CreatorType.Group then return false end

	local ok, group = pcall(GroupService.GetGroupInfoAsync,GroupService,game.CreatorId)
	return ok and type(group) == "table" and type(group.Owner) == "table"
		and group.Owner.Id == player.UserId and player.Parent == Players
end

function Admin.hasAccess(player)
	return access[player] == true
end

function Admin.refreshAccess(player)
	local allowed = Admin.isOwner(player)
	if player.Parent ~= Players then return false end
	local changed = Admin.hasAccess(player) ~= allowed
	access[player] = allowed or nil
	player:SetAttribute("AdminAllowed",allowed)
	if changed then onAccessChanged(player,allowed) end
	return allowed
end

local function validValue(spec, value)
	if spec.min then
		return type(value) == "number" and value >= spec.min and value <= spec.max and value % 1 == 0
	elseif spec.kind == "boolean" then
		return type(value) == "boolean"
	elseif spec.kind == "string" then
		return type(value) == "string" and #value == 36
	end
	return value == nil
end

function Admin.start(remote, execute, accessChanged)
	onAccessChanged = accessChanged
	Players.PlayerRemoving:Connect(function(player)
		sessions[player],access[player] = nil,nil
	end)

	local function dispatch(player, session, action, value)
		if action == "resetRequest" then
			local token = HttpService:GenerateGUID(false)
			session.confirmation = { token = token, expires = os.clock() + confirmationSeconds }
			return "adminResetPrompt", { token = token, seconds = confirmationSeconds }
		elseif action == "resetCancel" then
			session.confirmation = nil
			return "adminResetCancelled"
		elseif action == "resetConfirm" then
			local pending = session.confirmation
			if not pending or os.clock() >= pending.expires or value ~= pending.token then return "adminResetExpired" end
			session.confirmation = nil
		end
		return execute(player,action,value)
	end

	remote.OnServerInvoke = function(player, action, value, ...)
		local spec = type(action) == "string" and #action <= 20 and commands[action]
		if not spec or select("#",...) ~= 0 or not validValue(spec,value) then return "adminInvalidValue" end
		local session = sessions[player]
		if not session then
			session = { nextAction = 0 }
			sessions[player] = session
		end
		local time = os.clock()
		if session.busy or time < session.nextAction then return "adminRateLimit" end
		session.nextAction,session.busy = time + .35,true
		local allowed = Admin.refreshAccess(player)
		if sessions[player] ~= session or not allowed then
			session.busy,session.confirmation = false,nil
			return "adminDenied"
		end

		local ok, key, payload = pcall(dispatch,player,session,action,value)
		session.busy = false
		if not ok then
			warn("[Factory] Owner panel action failed: " .. action .. " " .. tostring(key))
			return "adminFailed"
		end
		return key,payload
	end
end

return Admin
