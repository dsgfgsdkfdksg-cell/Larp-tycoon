local Players = game:GetService("Players")
local GroupService = game:GetService("GroupService")
local TextChatService = game:GetService("TextChatService")
local Shared = game:GetService("ReplicatedStorage"):WaitForChild("Brainrot")
local Game = require(Shared.GameConfig)

local Admin = {}
local confirmationSeconds = 30
local commands = {
	{ key = "cash", alias = "/cash", usage = "/cash 1000000000", limit = Game.MaxCash },
	{ key = "maxbase", alias = "/maxbase" },
	{ key = "resetbase", alias = "/resetbase", usage = "/resetbase confirm" },
	{ key = "setspeed", alias = "/setspeed", usage = "/setspeed 50", limit = Game.AdminMaxWalkSpeed },
	{ key = "help", alias = "/adminhelp" },
}

function Admin.isOwner(player)
	if player.Parent ~= Players or player.UserId <= 0 or game.CreatorId <= 0 then return false end
	if game.CreatorType == Enum.CreatorType.User then return player.UserId == game.CreatorId end
	if game.CreatorType ~= Enum.CreatorType.Group then return false end

	-- Roblox is authoritative for the group owner. A failed lookup grants no access.
	local ok, group = pcall(GroupService.GetGroupInfoAsync,GroupService,game.CreatorId)
	return ok and type(group) == "table" and type(group.Owner) == "table"
		and group.Owner.Id == player.UserId and player.Parent == Players
end

local function integer(argument, limit)
	if not argument:match("^%d+$") or #argument > 16 then return nil end
	local value = tonumber(argument)
	if value and value >= 1 and value <= limit then return value end
end

function Admin.start(feedback, execute)
	local sessions = {}
	Players.PlayerRemoving:Connect(function(player)
		sessions[player] = nil
	end)

	for _, spec in ipairs(commands) do
		local command = Instance.new("TextChatCommand")
		command.Name = "FactoryAdmin_" .. spec.key
		command.PrimaryAlias = spec.alias
		command.AutocompleteVisible = false
		command.Triggered:Connect(function(source, text)
			if not source or type(text) ~= "string" or #text > 64 then return end
			local player = Players:GetPlayerByUserId(source.UserId)
			if not player then return end
			local alias, argument = text:match("^%s*(%S+)%s*(.-)%s*$")
			if not alias or string.lower(alias) ~= spec.alias then return end

			local session = sessions[player]
			if not session then
				session = { nextAction = 0 }
				sessions[player] = session
			end
			local now = os.clock()
			if session.checking or now < session.nextAction then return end
			session.nextAction, session.checking = now + .45, true
			local allowed = Admin.isOwner(player)
			session.checking = false
			if not allowed or sessions[player] ~= session then return end

			local key, value
			if spec.limit then
				local amount = integer(argument,spec.limit)
				if amount then key,value = execute(player,spec.key,amount)
				else key,value = "adminUsage",spec.usage end
			elseif spec.key == "resetbase" and argument == "" then
				session.resetExpires = os.clock() + confirmationSeconds
				key,value = "adminResetPrompt",confirmationSeconds
			elseif spec.key == "resetbase" and string.lower(argument) == "confirm" then
				local expires = session.resetExpires
				session.resetExpires = nil
				if expires and os.clock() < expires then key,value = execute(player,spec.key)
				else key = "adminResetExpired" end
			elseif argument ~= "" then
				key,value = "adminUsage",spec.usage or spec.alias
			elseif spec.key == "help" then
				key = "adminHelp"
			else
				key,value = execute(player,spec.key)
			end

			if key then feedback:FireClient(player,key,value) end
		end)
		command.Parent = TextChatService
	end
end

return Admin
