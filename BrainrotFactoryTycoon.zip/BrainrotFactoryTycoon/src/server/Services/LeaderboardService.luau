local Players = game:GetService("Players")
local Shared = game:GetService("ReplicatedStorage"):WaitForChild("Brainrot")
local fmt = require(Shared.NumberFormat)
local Leaderboard = {}

function Leaderboard.sync(player, profile)
	local folder = player:FindFirstChild("leaderstats")
	if not folder then
		folder = Instance.new("Folder")
		folder.Name = "leaderstats"
		for _, key in ipairs({"Cash","Factory %"}) do
			local item = Instance.new("IntValue")
			item.Name = key
			item.Parent = folder
		end
		folder.Parent = player
	end
	folder.Cash.Value = profile.Cash
	folder["Factory %"].Value = math.floor(profile.Stage * 100 / 80)
end

function Leaderboard.start(board)
	local gui = Instance.new("SurfaceGui")
	gui.Name = "DistrictLeaderboard"
	gui.Face = Enum.NormalId.Back
	gui.SizingMode = Enum.SurfaceGuiSizingMode.FixedSize
	gui.CanvasSize = Vector2.new(900,345)
	gui.LightInfluence = 0
	gui.MaxDistance = 130
	gui.Parent = board
	local rows = {}
	for index = 0,8 do
		local line = Instance.new("TextLabel")
		line.Size = UDim2.new(1,-36,0,index == 0 and 40 or 34)
		line.Position = UDim2.fromOffset(18,index == 0 and 7 or 48+(index-1)*35)
		line.BackgroundColor3 = index % 2 == 0 and Color3.fromRGB(41,58,85) or Color3.fromRGB(31,45,67)
		line.TextColor3 = index == 0 and Color3.fromRGB(103,240,185) or Color3.fromRGB(240,247,255)
		line.Font = Enum.Font.GothamBold
		line.TextSize = index == 0 and 29 or 24
		line.Text = index == 0 and "DISTRICT LEADERS  /  CASH  /  FACTORY" or "—"
		line.Parent = gui
		if index > 0 then
			rows[index] = line
		else
			line:SetAttribute("TextEN","DISTRICT LEADERS  /  CASH  /  FACTORY")
			line:SetAttribute("TextRU","ЛИДЕРЫ РАЙОНА  /  ДЕНЬГИ  /  ФАБРИКА")
			game:GetService("CollectionService"):AddTag(line,"FactoryText")
		end
	end
	task.spawn(function()
		while board.Parent do
			local entries = {}
			for _, player in ipairs(Players:GetPlayers()) do
				if player:GetAttribute("Ready") then table.insert(entries,player) end
			end
			table.sort(entries,function(a,b)
				local delta = a:GetAttribute("Cash") - b:GetAttribute("Cash")
				if delta ~= 0 then return delta > 0 end
				local stages = a:GetAttribute("Stage") - b:GetAttribute("Stage")
				if stages ~= 0 then return stages > 0 end
				return a.UserId < b.UserId
			end)
			for i, row in ipairs(rows) do
				local player = entries[i]
				row.Text = player and string.format("%d    %s    •    $%s    •    %d%%",i,player.DisplayName,
					fmt(player:GetAttribute("Cash")),math.floor(player:GetAttribute("Stage")*1.25)) or "—"
			end
			task.wait(2)
		end
	end)
end

return Leaderboard
