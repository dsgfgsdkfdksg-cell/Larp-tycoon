local CollectionService = game:GetService("CollectionService")
local Dropper = {}

function Dropper.bind(model, plot)
	local marker = model:FindFirstChild("PacketStart")
	if marker then
		marker:SetAttribute("PlotId", plot.id)
		CollectionService:AddTag(marker, "FactoryLane")
	end
end

return Dropper
