local Shared = game:GetService("ReplicatedStorage"):WaitForChild("Brainrot")
local Assets = game:GetService("ServerStorage"):WaitForChild("FactoryAssets")
local CollectionService = game:GetService("CollectionService")
local Config = require(Shared.GameConfig)
local Economy = require(Shared.EconomyConfig)
local Costumes = require(Shared.CostumeConfig)
local fmt = require(Shared.NumberFormat)
local World = require(Assets.WorldBuilder)
local Factory = require(Assets.FactoryBuilder)
local P = require(Assets.Parts)
local Dropper = require(script.Parent.DropperService)

local Plots = {}
local availableLabel, allPlots
local green, red = Color3.fromRGB(53, 232, 127), Color3.fromRGB(246, 90, 103)
local blue, violet = Color3.fromRGB(74, 215, 255), Color3.fromRGB(182, 121, 255)

local function button(parent, frame, kind, color, labelEn, labelRu, owner, onTrigger, price)
	local part = P.part(parent, kind, Vector3.new(4.7,.32,3.35), frame, color, Enum.Material.Neon, false)
	part:SetAttribute("Interaction",kind)
	part:SetAttribute("OwnerUserId",owner)
	CollectionService:AddTag(part,"FactoryButton")
	local title = P.billboard(part,"Title",labelEn,168,price and 52 or 35,2.48,35)
	P.translate(title,labelEn,labelRu)
	if price then
		part:SetAttribute("Price",price)
		part:SetAttribute("LabelEN",labelEn)
		part:SetAttribute("LabelRU",labelRu)
	end
	local prompt = P.make("ProximityPrompt",part,"Interact")
	prompt.AutoLocalize = false
	prompt.ActionText = labelEn:match("^[^\n]+") or labelEn
	prompt.ObjectText = price and "$" .. fmt(price,true) or ""
	prompt.MaxActivationDistance = Config.PromptDistance
	prompt.RequiresLineOfSight = false
	prompt.HoldDuration = .16
	P.translate(prompt,prompt.ActionText,labelRu:match("^[^\n]+") or labelRu,"ActionText")
	prompt.Triggered:Connect(function(player)
		onTrigger(player,part)
	end)
	return part
end

local function claimPad(plot, callbacks)
	plot.claim = button(plot.shell, plot.frame * CFrame.new(0,.51,35), "Claim", green,
		"Claim Tycoon","Занять участок",0,function(player,pad)
			callbacks.claim(player,plot,pad)
		end)
	plot.claim:SetAttribute("PlotId",plot.id)
end

function Plots.create(callbacks)
	local target, spawn, board, available = World.build()
	availableLabel = available
	local factories = P.make("Folder",target.Parent,"Factories")
	local plots = {}
	for id = 1, Config.PlotCount do
		local frame = World.plotFrame(id)
		local shell, ownerTitle = World.plotShell(target,id,frame)
		local plot = {id=id, frame=frame, shell=shell, title=ownerTitle, factories=factories}
		P.translate(plot.title,"FREE PLOT","СВОБОДНЫЙ УЧАСТОК")
		claimPad(plot,callbacks)
		table.insert(plots,plot)
	end
	allPlots = plots
	Plots.wayfinding()
	return plots, spawn, board
end

function Plots.wayfinding()
	local free = {}
	for _, plot in ipairs(allPlots) do
		if not plot.owner then table.insert(free,string.format("%02d",plot.id)) end
	end
	local suffix = table.concat(free," · ")
	local en = #free == 0 and "ALL PLOTS CLAIMED" or "OPEN PLOTS\n" .. suffix
	local ru = #free == 0 and "ВСЕ УЧАСТКИ ЗАНЯТЫ" or "СВОБОДНЫЕ УЧАСТКИ\n" .. suffix
	availableLabel.Text = en
	P.translate(availableLabel,en,ru)
end

function Plots.entry(plot)
	return plot.frame * CFrame.new(0,3.9,22) * CFrame.Angles(0,math.pi,0)
end

function Plots.outside(plot)
	return plot.frame * CFrame.new(0,3.65,36)
end

function Plots.liftDestination(plot,floor)
	return Factory.floorFrame(plot.frame,floor) * CFrame.new(-31.5,3.5,23)
end

local function addLift(plot, floor, callbacks)
	if plot.liftPads[floor] then return end
	local parent = plot.floors[floor]
	local frame = Factory.liftFrame(plot.frame,floor)
	local color = Color3.fromRGB(85,236,249)
	local landing = P.make("Model",parent,"Lift landing")
	P.part(landing,"Platform",Vector3.new(8.1,.25,5.2),frame * CFrame.new(-.8,-.11,0),P.Ink,Enum.Material.Metal,true)
	for _, x in ipairs({-4.6,3}) do
		P.part(landing,"Guide",Vector3.new(.35,11.7,.4),frame * CFrame.new(x,5.75,-2.61),color,Enum.Material.Neon)
	end
	local pads = {}
	for _, step in ipairs({-1,1}) do
		if floor + step >= 1 and floor + step <= #plot.floors then
			local pad = button(landing,frame * CFrame.new(-.8,0,step*1.69),"Lift",color,
				step > 0 and "Lift up" or "Lift down",step > 0 and "Лифт вверх" or "Лифт вниз",
				0,function(player, part) callbacks.lift(player,plot,part,floor+step) end)
			pad.Size = Vector3.new(3.6,.27,2.1)
			table.insert(pads,pad)
		end
	end
	plot.liftPads[floor] = {landing=landing,pads=pads}
end

local function refreshLift(plot,callbacks)
	if plot.profile.Stage < 51 then return end
	if #plot.floors == 4 and plot.liftPads[3] and #plot.liftPads[3].pads == 1 then
		plot.liftPads[3].landing:Destroy()
		plot.liftPads[3] = nil
	end
	for floor = 1,#plot.floors do addLift(plot,floor,callbacks) end
end

local function addFloor(plot, floor, callbacks)
	plot.floors[floor] = Factory.floor(plot.factory,plot.frame,floor)
	local cash = button(plot.floors[floor],Factory.collectFrame(plot.frame,floor),"Collect",blue,
		"Collect Cash","Забрать деньги",plot.owner.UserId,function(player,part)
			callbacks.collect(player,plot,part)
		end)
	cash:SetAttribute("PlotId",plot.id)
	local amount = P.billboard(cash,"Amount","$0",92,25,3.93,34)
	amount.TextColor3 = blue
	plot.collects[floor] = amount
end

function Plots.refresh(plot)
	local profile = plot.profile
	for _, label in ipairs(plot.collects) do label.Text = "$" .. fmt(profile.Chest) end
	for part, price in pairs(plot.prices) do
		local canBuy = plot.infiniteCash == true or profile.Cash >= price
		if part:GetAttribute("Affordable") ~= canBuy then
			part:SetAttribute("Affordable",canBuy)
			part.Color = canBuy and green or red
			local en = part:GetAttribute("LabelEN") .. (canBuy and "  ·  READY" or "  ·  NEED CASH")
			local ru = part:GetAttribute("LabelRU") .. (canBuy and "  ·  ДОСТУПНО" or "  ·  НЕ ХВАТАЕТ")
			local label = part.Title.Label
			label.Text = en
			P.translate(label,en,ru)
		end
	end
end

local function addCostumePad(plot,floor,callbacks)
	local spec = Costumes[floor]
	if plot.profile.Costumes[spec.id] or plot.costumePads[floor] then return end
	local price = Economy.CostumePrices[floor]
	local en = "Buy costume\n$" .. fmt(price,true)
	local ru = "Купить костюм\n$" .. fmt(price,true)
	local pad = button(plot.floors[floor],Factory.costumeFrame(plot.frame,floor),"Costume",violet,en,ru,plot.owner.UserId,
		function(player,part) callbacks.costume(player,plot,part,floor) end,price)
	plot.costumePads[floor] = pad
	plot.prices[pad] = price
end

local function nextPurchase(plot, callbacks)
	if plot.buyPad then
		plot.prices[plot.buyPad] = nil
		plot.buyPad:Destroy()
		plot.buyPad = nil
	end
	local upgrade = Economy.Upgrades[plot.profile.Stage+1]
	if not upgrade then return end
	local price = "\n$" .. fmt(upgrade.price,true)
	local pad = button(plot.floors[upgrade.floor],Factory.padFrame(plot.frame,upgrade),"Buy",green,
		upgrade.en .. price,upgrade.ru .. price,plot.owner.UserId,function(player,part)
			callbacks.upgrade(player,plot,part,upgrade)
		end,upgrade.price)
	pad:SetAttribute("UpgradeId",upgrade.id)
	pad:SetAttribute("PlotId",plot.id)
	plot.buyPad = pad
	plot.prices[pad] = upgrade.price
end

function Plots.setDoors(plot)
	if not plot.door then return end
	local closed = plot.profile.Settings.Doors
	plot.shell:SetAttribute("Closed",closed)
	plot.door.CFrame = plot.door:GetAttribute("BaseCFrame") * CFrame.new(closed and 0 or 9.18,0,0)
	plot.door.CanCollide = closed
	plot.door.CanQuery = closed
end

local function buildUpgrade(plot,upgrade,callbacks)
	local item = Factory.upgrade(plot.floors[upgrade.floor],plot.frame,upgrade)
	Dropper.bind(item,plot)
	item:SetAttribute("PlotId",plot.id)
	if upgrade.kind == "doors" then
		plot.door = item:FindFirstChild("SecurityGate")
		local pad = button(plot.floors[1],Factory.floorFrame(plot.frame,1) * CFrame.new(-5.7,.29,26),"Door",
			violet,"Toggle access","Открыть / закрыть",plot.owner.UserId,function(player,part)
				callbacks.door(player,plot,part)
			end)
		pad.Size = Vector3.new(3.75,.32,2.7)
		Plots.setDoors(plot)
	end
	return item
end

-- Used for both saved factories and owner-granted upgrades.
function Plots.rebuild(plot,callbacks)
	if plot.factory then plot.factory:Destroy() end
	plot.buyPad,plot.door = nil,nil
	plot.shell:SetAttribute("Closed",false)
	local profile = plot.profile
	plot.factory = P.make("Model",plot.factories,"Factory" .. plot.id)
	plot.factory:SetAttribute("PlotId",plot.id)
	plot.floors,plot.prices,plot.collects,plot.costumePads,plot.liftPads = {},{},{},{},{}
	addFloor(plot,1,callbacks)
	for i=1,profile.Stage do
		local upgrade = Economy.Upgrades[i]
		buildUpgrade(plot,upgrade,callbacks)
		if i % 20 == 0 then
			addCostumePad(plot,upgrade.floor,callbacks)
			if upgrade.floor < 4 then addFloor(plot,upgrade.floor+1,callbacks) end
		end
	end
	refreshLift(plot,callbacks)
	nextPurchase(plot,callbacks)
	Plots.refresh(plot)
end

function Plots.claim(plot,player,profile,callbacks)
	plot.owner, plot.profile = player,profile
	plot.shell:SetAttribute("Owner",player.UserId)
	Plots.wayfinding()
	plot.title.Text = player.DisplayName
	P.translate(plot.title,player.DisplayName,player.DisplayName)
	plot.claim:Destroy()
	plot.claim = nil
	Plots.rebuild(plot,callbacks)
end

function Plots.upgrade(plot,upgrade,callbacks)
	local item = buildUpgrade(plot,upgrade,callbacks)
	if upgrade.order == 20 then
		addCostumePad(plot,upgrade.floor,callbacks)
		if upgrade.floor < 4 then addFloor(plot,upgrade.floor+1,callbacks) end
	end
	refreshLift(plot,callbacks)
	nextPurchase(plot,callbacks)
	Plots.refresh(plot)
	return item
end

function Plots.costumeBought(plot,floor)
	local pad = plot.costumePads[floor]
	if pad then
		plot.prices[pad] = nil
		pad:Destroy()
		plot.costumePads[floor] = nil
	end
	Plots.refresh(plot)
end

function Plots.release(plot, callbacks)
	plot.owner, plot.profile, plot.production, plot.infiniteCash = nil,nil,nil,nil
	plot.shell:SetAttribute("Owner",0)
	Plots.wayfinding()
	plot.shell:SetAttribute("Closed",false)
	for floor = 1,4 do plot.shell:SetAttribute("LaneEpoch" .. floor,nil) end
	plot.title.Text = "FREE PLOT"
	P.translate(plot.title,"FREE PLOT","СВОБОДНЫЙ УЧАСТОК")
	plot.factory:Destroy()
	plot.factory, plot.buyPad, plot.door = nil,nil,nil
	plot.floors, plot.prices, plot.collects, plot.costumePads, plot.liftPads = nil,nil,nil,nil,nil
	claimPad(plot,callbacks)
end

return Plots
