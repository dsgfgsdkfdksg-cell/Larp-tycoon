local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local Shared = game:GetService("ReplicatedStorage"):WaitForChild("Brainrot")

local Game = require(Shared.GameConfig)
local Config = require(Shared.EconomyConfig)
local Costumes = require(Shared.CostumeConfig)
local Data = require(script.Parent.DataService)
local Economy = require(script.Parent.EconomyService)
local Plot = require(script.Parent.PlotService)
local Purchase = require(script.Parent.PurchaseService)
local Collector = require(script.Parent.CollectorService)
local Conveyor = require(script.Parent.ConveyorService)
local Costume = require(script.Parent.CostumeService)
local Tutorial = require(script.Parent.TutorialService)
local Leaderboard = require(script.Parent.LeaderboardService)
local Admin = require(script.Parent.AdminService)
local Tycoon = {}

local owned, active, limiters = {}, {}, {}
local callbacks = {}
local plots, spawn, board, events
local closing = false

local function now()
	return workspace:GetServerTimeNow()
end

local function send(player,kind,value)
	events.Feedback:FireClient(player,kind,value)
end

local function admit(player,action,interval)
	local slots = limiters[player]
	if not slots then return false end
	local time = os.clock()
	if time < (slots[action] or 0) then return false end
	slots[action] = time + interval
	return true
end

local function rootOf(player)
	local character = player.Character
	local root = character and character:FindFirstChild("HumanoidRootPart")
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	if root and humanoid and humanoid.Health > 0 then return root, character end
end

local function near(player, pad)
	local root = rootOf(player)
	return closing == false and pad.Parent ~= nil and root ~= nil and
		(root.Position - pad.Position).Magnitude <= Game.PromptDistance + 2.25
end

local function owns(player,plot)
	return plot.owner == player and owned[player] == plot and Data.get(player) == plot.profile
end

local function sync(player,profile)
	if not profile then return end
	local plot = owned[player]
	player:SetAttribute("Cash",profile.Cash)
	player:SetAttribute("Chest",profile.Chest)
	player:SetAttribute("Rate",Config.Stages[profile.Stage].rate)
	player:SetAttribute("Stage",profile.Stage)
	player:SetAttribute("Floor",Config.floorFor(profile.Stage))
	player:SetAttribute("PlotId",plot and plot.id or 0)
	player:SetAttribute("Tutorial",profile.Tutorial)
	player:SetAttribute("CostumesMask",Costume.mask(profile))
	player:SetAttribute("Equipped",profile.Equipped)
	for key, value in pairs(profile.Settings) do player:SetAttribute(key,value) end
	Leaderboard.sync(player,profile)
	if plot then Plot.refresh(plot) end
end

local function relay(plot,kind,position,value)
	for _, listener in ipairs(Players:GetPlayers()) do
		local root = rootOf(listener)
		if root and (root.Position-position).Magnitude < 135 then
			events.WorldFX:FireClient(listener,kind,position,plot.id,value)
		end
	end
end

function callbacks.claim(player,plot,pad)
	if not near(player,pad) or not admit(player,"prompt",.32) or owned[player] or plot.owner or plot.claim ~= pad then return end
	local profile = Data.get(player)
	if not profile then return end
	Tutorial.advance(profile,1)
	-- Ownership, transactions and build state change in one non-yielding server turn.
	owned[player] = plot
	Plot.claim(plot,player,profile,callbacks)
	Economy.attach(plot,now())
	sync(player,profile)
	send(player,"claimed")
end

function callbacks.collect(player,plot,pad)
	if not near(player,pad) or not owns(player,plot) or not admit(player,"prompt",.26) then return end
	local amount = Collector.collect(plot,now())
	sync(player,plot.profile)
	if amount > 0 then
		send(player,"collected",amount)
		relay(plot,"collect",pad.Position,amount)
	else
		send(player,"empty")
	end
end

function callbacks.upgrade(player,plot,pad,spec)
	if not near(player,pad) or plot.buyPad ~= pad or not owns(player,plot) or not admit(player,"prompt",.25) then return end
	local position = pad.Position
	local ok, reason = Purchase.upgrade(plot,spec,now())
	if not ok then
		sync(player,plot.profile)
		send(player,reason)
		return
	end
	Plot.upgrade(plot,spec,callbacks)
	sync(player,plot.profile)
	relay(plot,"build",position,spec.id)
	if spec.index == #Config.Upgrades then
		send(player,"completed")
	elseif spec.order == 20 then
		send(player,"floor",spec.floor+1)
	else
		send(player,"upgrade",spec.id)
	end
end

function callbacks.costume(player,plot,pad,floor)
	if not near(player,pad) or plot.costumePads[floor] ~= pad or not owns(player,plot) or not admit(player,"prompt",.25) then return end
	local position = pad.Position
	local ok, reason = Purchase.costume(plot,floor)
	if not ok then send(player,reason) return end
	Plot.costumeBought(plot,floor)
	sync(player,plot.profile)
	send(player,"costume",Costumes[floor].id)
	relay(plot,"unlock",position,floor)
end

local function access(player,plot)
	plot.profile.Settings.Doors = not plot.profile.Settings.Doors
	Plot.setDoors(plot)
	sync(player,plot.profile)
	send(player,plot.profile.Settings.Doors and "closed" or "open")
end

function callbacks.door(player,plot,pad)
	if not near(player,pad) or not plot.door or not owns(player,plot) or not admit(player,"prompt",.4) then return end
	access(player,plot)
end

function callbacks.lift(player,plot,pad,floor)
	if not near(player,pad) or not plot.owner or not plot.floors[floor] or not Data.get(player)
		or not admit(player,"lift",.85) or (plot.profile.Settings.Doors and plot.owner ~= player) then return end
	local _, character = rootOf(player)
	if character then
		character:PivotTo(Plot.liftDestination(plot,floor))
		send(player,"lift")
	end
end

local function watchBorders()
	local since = 0
	RunService.Heartbeat:Connect(function(dt)
		since += dt
		if since < .3 then return end
		since = 0
		local players = Players:GetPlayers()
		for _, plot in ipairs(plots) do
			if plot.door and plot.profile.Settings.Doors then
				for _, player in ipairs(players) do
					if player ~= plot.owner then
						local root, character = rootOf(player)
						if root then
							local p = plot.frame:PointToObjectSpace(root.Position)
							if math.abs(p.X) < 42.9 and math.abs(p.Z) < 29.1 and p.Y > -4 and p.Y < 68 then
								character:PivotTo(Plot.outside(plot))
							end
						end
					end
				end
			end
		end
	end)
end

local function request(player,action,arg)
	if closing or type(action) ~= "string" or #action > 20 or not admit(player,"remote",.16) then return end
	local profile = Data.get(player)
	if not profile then return end
	local plot = owned[player]
	if action == "language" and (arg == "en" or arg == "ru") then
		profile.Settings.Language = arg
	elseif action == "music" and type(arg) == "boolean" then
		profile.Settings.Music = arg
	elseif action == "sound" and type(arg) == "boolean" then
		profile.Settings.Sound = arg
	elseif action == "equip" and type(arg) == "string" and #arg < 20 and Costume.valid(profile,arg) then
		profile.Equipped = arg
		Costume.apply(player.Character,arg)
		send(player,arg == "" and "unequipped" or "equipped")
	elseif action == "doors" and arg == nil and plot and plot.door and admit(player,"doors",.5) then
		access(player,plot)
		return
	elseif action == "teleport" and arg == nil and admit(player,"teleport",3) then
		if not plot then send(player,"noPlot") return end
		local root, character = rootOf(player)
		if not root then return end
		local target = Plot.entry(plot)
		if (root.Position-target.Position).Magnitude > 100 then
			pcall(player.RequestStreamAroundAsync,player,target.Position,2)
		end
		local _, current = rootOf(player)
		if not closing and owned[player] == plot and Data.get(player) == profile and current == character then
			character:PivotTo(target)
			send(player,"teleported")
		end
		return
	else
		return
	end
	sync(player,profile)
end

local function setWalkSpeed(player, speed)
	local character = player.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	if humanoid then humanoid.WalkSpeed = speed end
end

-- Only AdminService dispatches these operations, after verifying the chat sender.
local function adminAction(player, action, value)
	local profile = Data.get(player)
	if closing or active[player] ~= "ready" or not profile then return "adminNotReady" end
	local plot = owned[player]
	if action == "cash" then
		local added = math.min(value,Game.MaxCash-profile.Cash)
		if added == 0 then return "adminCashLimit" end
		profile.Cash += added
		sync(player,profile)
		return "adminCash", added
	elseif action == "maxbase" then
		if profile.Stage == #Config.Upgrades then return "adminMaxBase" end
		local time = now()
		if plot then Economy.produce(plot,time) end
		profile.Stage = #Config.Upgrades
		Tutorial.advance(profile,5)
		if plot then
			Plot.rebuild(plot,callbacks)
			Economy.syncLanes(plot,time)
		end
		sync(player,profile)
		return "adminMaxBase"
	elseif action == "resetbase" then
		if plot then
			owned[player] = nil
			Plot.release(plot,callbacks)
			local _, character = rootOf(player)
			if character then character:PivotTo(spawn.CFrame * CFrame.new(0,4,0)) end
		end
		profile.Cash,profile.Chest,profile.Stage,profile.Tutorial = Game.StartCash,0,0,0
		profile.Settings.Doors = false
		sync(player,profile)
		task.spawn(Data.autosave,player.UserId)
		return "adminResetDone"
	elseif action == "setspeed" then
		profile.AdminWalkSpeed = value
		setWalkSpeed(player,value)
		return "adminSpeed", value
	end
end

local function disconnect(player)
	active[player] = nil
	local plot = owned[player]
	if plot then
		if Data.get(player) then Economy.produce(plot,now()) end
		owned[player] = nil
		Plot.release(plot,callbacks)
	end
	limiters[player] = nil
end

local function leave(player)
	disconnect(player)
	Data.release(player)
end

local function joined(player)
	if active[player] or closing then return end
	local count = 0
	for _ in pairs(active) do count += 1 end
	if count >= Game.MaxPlayers then
		player:Kick("This factory district is full (8 players).")
		return
	end
	active[player] = "loading"
	player.RespawnLocation = spawn
	limiters[player] = {}
	player:SetAttribute("PlotId",0)
	local function reapply(character)
		local profile = Data.get(player)
		if profile and player.Character == character then Costume.apply(character,profile.Equipped) end
	end
	local function restoreAdminSpeed(character)
		local profile = Data.get(player)
		if not profile or not profile.AdminWalkSpeed then return end
		if character:WaitForChild("Humanoid",8) and Admin.isOwner(player)
			and player.Character == character and Data.get(player) == profile and profile.AdminWalkSpeed then
			setWalkSpeed(player,profile.AdminWalkSpeed)
		end
	end
	player.CharacterAdded:Connect(function(character)
		if character:WaitForChild("Head",8) then reapply(character) end
		restoreAdminSpeed(character)
	end)
	player.CharacterAppearanceLoaded:Connect(reapply)
	local profile, errorCode = Data.acquire(player)
	if player.Parent ~= Players or closing or not active[player] then
		Data.release(player)
		return
	end
	if not profile then
		active[player] = nil
		local ru = string.sub(string.lower(player.LocaleId),1,2) == "ru"
		local busy = ru and "Сохранение открыто на другом сервере. Войдите чуть позже." or "Your save is active on another server. Rejoin shortly."
		local failed = ru and "Не удалось безопасно загрузить прогресс. Попробуйте войти позже." or "Your factory save could not be loaded safely. Please rejoin later."
		player:Kick(errorCode == "busy" and busy or failed)
		return
	end
	active[player] = "ready"
	reapply(player.Character)
	sync(player,profile)
	player:SetAttribute("Ready",true)
	if profile.AdminWalkSpeed and player.Character then task.spawn(restoreAdminSpeed,player.Character) end
end

function Tycoon.start(network)
	events = network
	plots, spawn, board = Plot.create(callbacks)
	Leaderboard.start(board)
	Conveyor.start(plots,function(plot) sync(plot.owner,plot.profile) end)
	watchBorders()
	network.Action.OnServerEvent:Connect(request)
	Admin.start(network.Feedback,adminAction)
	Players.PlayerAdded:Connect(joined)
	Players.PlayerRemoving:Connect(leave)
	for _, player in ipairs(Players:GetPlayers()) do task.spawn(joined,player) end
	task.spawn(function()
		local age = 0
		while not closing do
			task.wait(5)
			if closing then break end
			age += 5
			for player,state in pairs(active) do
				if state == "ready" and not Data.get(player) then
					disconnect(player)
					task.spawn(Data.release,player)
					player:Kick("The save session is unavailable. Please rejoin. / Сессия сохранения недоступна. Войдите снова.")
				end
			end
			if age >= Game.SaveEvery then Data.maintain(false) age = 0 end
		end
	end)
	game:BindToClose(function()
		closing = true
		for _, player in ipairs(Players:GetPlayers()) do disconnect(player) end
		local untilTime = os.clock() + 25
		while Data.hasSessions() and os.clock() < untilTime do
			Data.maintain(true)
			task.wait(.5)
		end
	end)
end

return Tycoon
