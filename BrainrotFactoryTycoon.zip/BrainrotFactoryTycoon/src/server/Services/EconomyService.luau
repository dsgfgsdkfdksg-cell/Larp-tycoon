local Shared = game:GetService("ReplicatedStorage"):WaitForChild("Brainrot")
return require(script.Parent.EconomyRules)(require(Shared.EconomyConfig), require(Shared.GameConfig))
