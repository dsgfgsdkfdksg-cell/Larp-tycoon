local Players = game:GetService("Players")
local CollectionService = game:GetService("CollectionService")
local TweenService = game:GetService("TweenService")
local player = Players.LocalPlayer
local Controller = {}

function Controller.start()
	local changes = {}
	local function applyText(item)
		local language = player:GetAttribute("Language") or (string.sub(string.lower(player.LocaleId),1,2) == "ru" and "ru" or "en")
		local property = item:GetAttribute("TextProperty")
		local text = item:GetAttribute(language=="ru" and "TextRU" or "TextEN")
		if property and text then item[property] = text end
	end
	local function addText(item)
		if changes[item] then return end
		changes[item] = item.AttributeChanged:Connect(function() applyText(item) end)
		applyText(item)
	end
	CollectionService:GetInstanceAddedSignal("FactoryText"):Connect(addText)
	CollectionService:GetInstanceRemovedSignal("FactoryText"):Connect(function(item)
		if changes[item] then changes[item]:Disconnect() changes[item] = nil end
	end)
	for _, item in ipairs(CollectionService:GetTagged("FactoryText")) do addText(item) end
	player:GetAttributeChangedSignal("Language"):Connect(function()
		for item in pairs(changes) do applyText(item) end
	end)

	local buttons = {}
	local function buttonVisible(item)
		local owner = item:GetAttribute("OwnerUserId")
		local open = player:GetAttribute("Ready") and
			(owner == player.UserId or owner == 0 and (item:GetAttribute("Interaction")~="Claim" or (player:GetAttribute("PlotId") or 0)==0))
		for _, child in ipairs(item:GetChildren()) do
			if child:IsA("ProximityPrompt") then child.Enabled = open == true end
			if child:IsA("BillboardGui") and child.Name == "Title" then child.Enabled = open == true end
		end
	end
	local function addButton(item)
		if buttons[item] then return end
		buttons[item] = item.ChildAdded:Connect(function() buttonVisible(item) end)
		buttonVisible(item)
	end
	CollectionService:GetInstanceAddedSignal("FactoryButton"):Connect(addButton)
	CollectionService:GetInstanceRemovedSignal("FactoryButton"):Connect(function(item)
		if buttons[item] then buttons[item]:Disconnect() buttons[item] = nil end
	end)
	for _, item in ipairs(CollectionService:GetTagged("FactoryButton")) do addButton(item) end
	for _, attr in ipairs({"Ready","PlotId"}) do
		player:GetAttributeChangedSignal(attr):Connect(function()
			for item in pairs(buttons) do buttonVisible(item) end
		end)
	end

	local arrow = Instance.new("BillboardGui")
	arrow.Name,arrow.Size,arrow.StudsOffsetWorldSpace = "TutorialArrow",UDim2.fromOffset(53,53),Vector3.new(0,5.4,0)
	arrow.AlwaysOnTop,arrow.MaxDistance,arrow.Enabled = true,300,false
	arrow.Parent = player:WaitForChild("PlayerGui")
	local glyph = Instance.new("TextLabel")
	glyph.Size,glyph.BackgroundTransparency = UDim2.fromScale(1,1),1
	glyph.Font,glyph.Text,glyph.TextSize = Enum.Font.GothamBold,"▼",50
	glyph.TextColor3,glyph.TextStrokeTransparency = Color3.fromRGB(117,255,185),.18
	glyph.Parent = arrow
	TweenService:Create(arrow,TweenInfo.new(.67,Enum.EasingStyle.Sine,Enum.EasingDirection.InOut,-1,true),
		{StudsOffsetWorldSpace=Vector3.new(0,6.3,0)}):Play()
	local outline = Instance.new("Highlight")
	outline.Enabled,outline.DepthMode = false,Enum.HighlightDepthMode.AlwaysOnTop
	outline.FillTransparency,outline.OutlineColor = .8,Color3.fromRGB(117,255,185)
	outline.FillColor = outline.OutlineColor
	outline.Parent = workspace

	task.spawn(function()
		while arrow.Parent do
			local step = player:GetAttribute("Tutorial") or 0
			local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
			local target, distance = nil,math.huge
			if root and player:GetAttribute("Ready") and step < 5 then
				if step == 2 then
					for _, marker in ipairs(CollectionService:GetTagged("FactoryLane")) do
						if marker:GetAttribute("Primary") and marker:GetAttribute("PlotId") == player:GetAttribute("PlotId") then target = marker break end
					end
				else
					local buy = step==1 or step==4 and (player:GetAttribute("Cash") or 0)>=500
					local kind = step==0 and "Claim" or buy and "Buy" or "Collect"
					for item in pairs(buttons) do
						if item:GetAttribute("Interaction")==kind and (step==0 or item:GetAttribute("OwnerUserId")==player.UserId) then
							local d = (item.Position-root.Position).Magnitude
							if d<distance then target,distance = item,d end
						end
					end
				end
			end
			arrow.Adornee,arrow.Enabled = target,target~=nil
			outline.Adornee,outline.Enabled = target,target~=nil and step~=2
			task.wait(.23)
		end
	end)
end

return Controller
