local Players = game:GetService("Players")
local Shared = game:GetService("ReplicatedStorage"):WaitForChild("Brainrot")
local Game = require(Shared.GameConfig)
local Locale = require(Shared.Locale)
local formatCash = require(Shared.NumberFormat)

local AdminController = {}
local player = Players.LocalPlayer
local rgb = Color3.fromRGB
local ink, card, field = rgb(18,28,47), rgb(29,44,68), rgb(14,24,41)
local white, muted, mint, sky = rgb(244,251,255), rgb(183,204,224), rgb(111,246,185), rgb(106,220,255)
local neutral, accent, danger = rgb(43,61,88), rgb(29,94,86), rgb(119,48,66)
local warning = rgb(255,192,170)

local function make(class, parent, props)
	local object = Instance.new(class)
	object.BorderSizePixel = 0
	for key, value in pairs(props) do object[key] = value end
	object.Parent = parent
	return object
end

local function corner(object, radius)
	local shape = Instance.new("UICorner")
	shape.CornerRadius = UDim.new(0,radius)
	shape.Parent = object
end

local function outline(object, color, alpha)
	local stroke = Instance.new("UIStroke")
	stroke.Color,stroke.Transparency = color,alpha
	stroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	stroke.Parent = object
	return stroke
end

local function limit(object, max)
	local constraint = Instance.new("UISizeConstraint")
	constraint.MaxSize = max
	constraint.Parent = object
end

local function text(parent, position, size, color, fontSize)
	return make("TextLabel",parent,{
		Position=position, Size=size, Text="", BackgroundTransparency=1, TextWrapped=true,
		Font=Enum.Font.GothamBold, TextColor3=color, TextSize=fontSize, TextXAlignment=Enum.TextXAlignment.Left,
	})
end

local function button(parent,position,size,color,callback)
	local control = make("TextButton",parent,{
		Position=position, Size=size, BackgroundColor3=color, Text="", TextWrapped=true,
		Font=Enum.Font.GothamBold, TextColor3=white, TextSize=14, AutoButtonColor=true,
	})
	corner(control,9)
	control.Activated:Connect(callback)
	return control
end

local function readInteger(text, minimum, maximum)
	local digits = text:gsub("%s",""):gsub("\u{00A0}",""):gsub("\u{202F}","")
	if #digits > 16 or not digits:match("^%d+$") then return nil end
	local value = tonumber(digits)
	if value and value >= minimum and value <= maximum then return value end
end

local function numeric(parent, position, size, minimum, maximum)
	local input = make("TextBox",parent,{
		Position=position, Size=size, BackgroundColor3=field, Text="", ClearTextOnFocus=false,
		Font=Enum.Font.GothamBold, TextColor3=white, TextSize=15, PlaceholderColor3=muted,
	})
	corner(input,9)
	local border = outline(input,sky,.72)
	input:GetPropertyChangedSignal("Text"):Connect(function()
		local invalid = input.Text ~= "" and readInteger(input.Text,minimum,maximum) == nil
		border.Color = invalid and warning or sky
		border.Transparency = invalid and .25 or .72
	end)
	return input
end

function AdminController.start(gui, hud, title, remote)
	local function tr(key,...)
		local language = player:GetAttribute("Language")
		if not language then language = string.sub(string.lower(player.LocaleId),1,2) end
		return Locale(language,key,...)
	end

	local shade = make("Frame",gui,{
		Name="AdminPanel",Size=UDim2.fromScale(1,1),BackgroundColor3=ink,BackgroundTransparency=.18,
		Active=true,Visible=false,ZIndex=32,
	})
	local panel = make("Frame",shade,{
		AnchorPoint=Vector2.new(.5,.5),Position=UDim2.fromScale(.5,.5),Size=UDim2.new(1,-24,1,-20),
		BackgroundColor3=ink,
	})
	limit(panel,Vector2.new(558,638))
	corner(panel,16)
	outline(panel,sky,.27)
	local neon = make("Frame",panel,{
		Position=UDim2.fromOffset(15,10),Size=UDim2.fromOffset(51,3),BackgroundColor3=mint,
	})
	corner(neon,2)
	local heading = text(panel,UDim2.fromOffset(15,16),UDim2.new(1,-86,0,30),white,20)
	local status = text(panel,UDim2.new(0,15,1,-47),UDim2.new(1,-30,0,39),muted,13)
	local rows = make("ScrollingFrame",panel,{
		Position=UDim2.fromOffset(12,57),Size=UDim2.new(1,-24,1,-108),BackgroundTransparency=1,
		CanvasSize=UDim2.new(), AutomaticCanvasSize=Enum.AutomaticSize.Y,
		ScrollingDirection=Enum.ScrollingDirection.Y,ScrollBarThickness=4,ScrollBarImageColor3=sky,
	})
	local layout = Instance.new("UIListLayout")
	layout.Padding = UDim.new(0,8)
	layout.SortOrder = Enum.SortOrder.LayoutOrder
	layout.Parent = rows
	local gutters = Instance.new("UIPadding")
	gutters.PaddingLeft,gutters.PaddingRight,gutters.PaddingBottom = UDim.new(0,1),UDim.new(0,7),UDim.new(0,5)
	gutters.Parent = rows

	local labels = {}
	local function bind(element, key)
		labels[element] = key
		element.Text = tr(key)
		return element
	end
	local function section(order, height)
		local sectionFrame = make("Frame",rows,{
			LayoutOrder=order,Size=UDim2.new(1,0,0,height),BackgroundColor3=card,
		})
		corner(sectionFrame,12)
		outline(sectionFrame,sky,.87)
		return sectionFrame
	end

	local confirmation = make("Frame",panel,{
		Size=UDim2.fromScale(1,1),BackgroundColor3=ink,BackgroundTransparency=.08,Visible=false,Active=true,ZIndex=6,
	})
	corner(confirmation,16)
	local dialog = make("Frame",confirmation,{
		AnchorPoint=Vector2.new(.5,.5),Position=UDim2.fromScale(.5,.5),Size=UDim2.new(1,-22,0,175),
		BackgroundColor3=card,
	})
	limit(dialog,Vector2.new(418,175))
	corner(dialog,12)
	outline(dialog,warning,.28)
	bind(text(dialog,UDim2.fromOffset(12,7),UDim2.new(1,-24,0,29),warning,17),"adminResetQuestion")
	bind(text(dialog,UDim2.fromOffset(12,37),UDim2.new(1,-24,0,48),white,13),"adminResetBody")
	local countdown = text(dialog,UDim2.fromOffset(12,87),UDim2.new(1,-24,0,23),muted,12)

	local busy, token, deadline = false,nil,nil
	local activeAction, available = "",false
	local selectedFloor = 2
	local function showStatus(key, value, color)
		status.Text = tr(key, table.unpack(value or {}))
		status.TextColor3 = color or muted
	end
	local function hideConfirmation()
		token,deadline = nil,nil
		confirmation.Visible = false
	end
	local function close()
		shade.Visible = false
		hideConfirmation()
	end

	local function request(action, value)
		if busy or not available then return end
		busy,activeAction = true,action
		showStatus("adminWorking")
		task.spawn(function()
			local ok, key, payload = pcall(remote.InvokeServer,remote,action,value)
			busy,activeAction = false,""
			if not available or not shade.Visible then return end
			if not ok or type(key) ~= "string" then
				showStatus("adminFailed",nil,warning)
			elseif key == "adminResetPrompt" then
				token,deadline = payload.token,os.clock()+payload.seconds
				local expected = token
				confirmation.Visible = true
				showStatus("adminResetWaiting")
				task.spawn(function()
					while token == expected do
						local remaining = math.ceil(deadline-os.clock())
						if remaining <= 0 then
							if activeAction ~= "resetConfirm" then
								hideConfirmation()
								showStatus("adminResetExpired",nil,warning)
								return
							end
							remaining = 0
						end
						countdown.Text = tr("adminResetClock",remaining)
						task.wait(.25)
					end
				end)
			elseif key == "adminCashAdded" or key == "adminCashSet" then
				showStatus(key,{formatCash(payload,true)},mint)
			elseif key == "adminFloorDone" or key == "adminSpeedSet" then
				showStatus(key,{payload},mint)
			else
				if key == "adminResetDone" or key == "adminResetExpired" then hideConfirmation() end
				local error = key == "adminDenied" or key == "adminNotReady" or key == "adminFailed"
					or key == "adminInvalidValue" or key == "adminRateLimit" or key == "noPlot"
					or key == "adminTeleportFailed" or key == "adminResetExpired" or key == "adminCashLimit"
				if confirmation.Visible and key == "adminRateLimit" then
					countdown.Text = tr(key)
				end
				showStatus(key,nil,error and warning or mint)
			end
		end)
	end

	local function numberAction(action, input, minimum, maximum)
		local value = readInteger(input.Text,minimum,maximum)
		if value == nil then showStatus("adminInvalidValue",nil,warning) return end
		request(action,value)
	end

	local closeButton = button(panel,UDim2.new(1,-56,0,8),UDim2.fromOffset(46,44),neutral,close)
	closeButton.Text = "×"
	closeButton.TextSize = 25
	local openButton = button(hud,UDim2.new(1,-85,0,3),UDim2.fromOffset(76,36),accent,function()
		if not available then return end
		shade.Visible = not shade.Visible
		if shade.Visible then
			showStatus("adminReady")
		else
			hideConfirmation()
		end
	end)
	openButton.Name,openButton.Text,openButton.Visible = "AdminButton","ADMIN",false
	outline(openButton,mint,.34)

	local cash = section(1,186)
	bind(text(cash,UDim2.fromOffset(11,5),UDim2.new(.48,-11,0,28),sky,15),"adminBalanceLabel")
	local amount = text(cash,UDim2.new(.48,0,0,5),UDim2.new(.52,-11,0,28),mint,15)
	amount.TextXAlignment = Enum.TextXAlignment.Right
	local cashInput = numeric(cash,UDim2.fromOffset(11,37),UDim2.new(1,-22,0,42),0,Game.MaxCash)
	bind(button(cash,UDim2.fromOffset(11,85),UDim2.new(.5,-15,0,44),accent,function()
		numberAction("addCash",cashInput,1,Game.MaxCash)
	end),"adminAddCash")
	bind(button(cash,UDim2.new(.5,4,0,85),UDim2.new(.5,-15,0,44),neutral,function()
		numberAction("setCash",cashInput,0,Game.MaxCash)
	end),"adminSetCash")
	local infinity = button(cash,UDim2.fromOffset(11,135),UDim2.new(1,-22,0,44),neutral,function()
		request("infiniteCash",player:GetAttribute("InfiniteCash") ~= true)
	end)

	local factory = section(2,184)
	bind(text(factory,UDim2.fromOffset(11,4),UDim2.new(.48,-11,0,27),sky,15),"adminFactory")
	local floorStatus = text(factory,UDim2.new(.48,0,0,4),UDim2.new(.52,-11,0,27),mint,13)
	floorStatus.TextXAlignment = Enum.TextXAlignment.Right
	bind(button(factory,UDim2.fromOffset(11,33),UDim2.new(.5,-15,0,44),accent,function()
		request("maxBase")
	end),"adminMaxBase")
	bind(button(factory,UDim2.new(.5,4,0,33),UDim2.new(.5,-15,0,44),neutral,function()
		request("teleportHome")
	end),"adminTeleport")
	local floorButtons = {}
	local function chooseFloor(floor)
		selectedFloor = floor
		for index, control in ipairs(floorButtons) do
			control.BackgroundColor3 = index == floor and accent or neutral
			control.TextColor3 = index == floor and mint or white
		end
	end
	for floor=1,4 do
		local control = button(factory,UDim2.new((floor-1)/4,11-(floor-1)*4,0,84),UDim2.new(.25,-9,0,42),neutral,function()
			chooseFloor(floor)
		end)
		control.Text = tostring(floor)
		floorButtons[floor] = control
	end
	chooseFloor(selectedFloor)
	bind(button(factory,UDim2.fromOffset(11,132),UDim2.new(1,-22,0,44),accent,function()
		request("unlockFloor",selectedFloor)
	end),"adminUnlockFloor")

	local movement = section(3,91)
	bind(text(movement,UDim2.fromOffset(11,4),UDim2.new(1,-22,0,29),sky,15),"adminMovement")
	local speed = numeric(movement,UDim2.fromOffset(11,37),UDim2.new(.5,-15,0,44),1,Game.AdminMaxWalkSpeed)
	bind(button(movement,UDim2.new(.5,4,0,37),UDim2.new(.5,-15,0,44),neutral,function()
		numberAction("walkSpeed",speed,1,Game.AdminMaxWalkSpeed)
	end),"adminWalkSpeed")

	local reset = section(4,61)
	bind(button(reset,UDim2.fromOffset(11,8),UDim2.new(1,-22,0,44),danger,function()
		request("resetRequest")
	end),"adminReset")
	bind(button(dialog,UDim2.fromOffset(12,119),UDim2.new(.5,-16,0,44),neutral,function()
		if busy then return end
		hideConfirmation()
		request("resetCancel")
	end),"adminCancel")
	bind(button(dialog,UDim2.new(.5,4,0,119),UDim2.new(.5,-16,0,44),danger,function()
		if token then request("resetConfirm",token) end
	end),"adminConfirm")

	local function update()
		available = player:GetAttribute("AdminAllowed") == true and player:GetAttribute("Ready") == true
		openButton.Visible = available
		title.Size = UDim2.new(1,available and -99 or -24,0,23)
		title.TextScaled = available
		if not available then close() return end
		for object, key in pairs(labels) do object.Text = tr(key) end
		heading.Text = tr("adminTitle",Game.Version)
		cashInput.PlaceholderText = tr("adminAmount")
		speed.PlaceholderText = tr("adminSpeedHint",player:GetAttribute("AdminSpeed") or 16)
		amount.Text = "$" .. formatCash(player:GetAttribute("Cash") or 0,true)
		floorStatus.Text = tr("adminFloorStatus",player:GetAttribute("Floor") or 1)
		local enabled = player:GetAttribute("InfiniteCash") == true
		infinity.Text = tr(enabled and "adminInfinityActive" or "adminInfinityInactive")
		infinity.BackgroundColor3 = enabled and accent or neutral
	end
	local titleSize = Instance.new("UITextSizeConstraint")
	titleSize.MaxTextSize,titleSize.MinTextSize = 19,10
	titleSize.Parent = title
	for _, attribute in ipairs({"AdminAllowed","Ready","Language","AdminSpeed","Cash","Floor","InfiniteCash"}) do
		player:GetAttributeChangedSignal(attribute):Connect(update)
	end
	update()
end

return AdminController
