local RunService = game:GetService("RunService")
local Players = game:GetService("Players")
local CollectionService = game:GetService("CollectionService")
local TweenService = game:GetService("TweenService")
local Debris = game:GetService("Debris")
local SoundService = game:GetService("SoundService")
local Shared = game:GetService("ReplicatedStorage"):WaitForChild("Brainrot")
local Audio = require(Shared.AudioConfig)
local Game = require(Shared.GameConfig)
local Floors = require(Shared.FloorConfig)
local fmt = require(Shared.NumberFormat)

local Effects = {}
local rgb = Color3.fromRGB
local player = Players.LocalPlayer

local function asset(name)
	local id = Audio[name]
	if id and id ~= "" then
		return id:match("^%d+$") and ("rbxassetid://" .. id) or id
	end
	return Audio.Builtin[name]
end

local function createSound(parent,name,id,volume,looped)
	local sound = Instance.new("Sound")
	sound.Name,sound.SoundId,sound.Volume,sound.Looped = name,id,volume,looped == true
	sound.Parent = parent
	return sound
end

local function part(parent,name)
	local item = Instance.new("Part")
	item.Name,item.Anchored,item.CanCollide,item.CanTouch,item.CanQuery,item.CastShadow = name,true,false,false,false,false
	item.Material = Enum.Material.Neon
	item.Parent = parent
	return item
end

function Effects.start(gui,events)
	local effects = Instance.new("Folder")
	effects.Name,effects.Parent = "LocalFactoryEffects",workspace
	local audio = Instance.new("Folder")
	audio.Name,audio.Parent = "FactoryAudio",SoundService

	local purchase = createSound(audio,"Purchase",asset("Purchase"),.35)
	local collect = createSound(audio,"Collect",asset("Collect"),.42)
	local celebrate = createSound(audio,"Celebrate",asset("Celebrate"),.31)
	if Audio.Collect == "" then collect.PlaybackSpeed = 1.49 end
	if Audio.Celebrate == "" then celebrate.PlaybackSpeed = .97 end
	local musicFile = asset("Music")
	local music = musicFile and createSound(audio,"Music",musicFile,.18,true)
	local notes = {}
	if not music then
		for i = 1,4 do notes[i] = createSound(audio,"Music voice",asset("Note"),i == 4 and .045 or .085) end
	end
	local function musicState()
		if not music then
			if player:GetAttribute("Music") == false then for _, note in ipairs(notes) do note:Stop() end end
			return
		end
		if player:GetAttribute("Ready") and player:GetAttribute("Music") ~= false then music:Play() else music:Stop() end
	end
	player:GetAttributeChangedSignal("Ready"):Connect(musicState)
	player:GetAttributeChangedSignal("Music"):Connect(musicState)
	musicState()
	if not music then
		local score = {0,7,12,16,12,7,2,9,14,17,14,9,4,11,16,19,16,11,2,9,14,17,12,7}
		task.spawn(function()
			local i = 0
			while gui.Parent do
				if player:GetAttribute("Ready") and player:GetAttribute("Music") ~= false then
					local lead = notes[i%3+1]
					lead.PlaybackSpeed = 0.65 * 2^(score[i+1]/12)
					lead:Play()
					if i%6==0 then
						local bass = notes[4]
						bass.PlaybackSpeed = .32 * 2^(score[i+1]/12)
						bass:Play()
					end
					i = (i+1)%#score
				end
				task.wait(.49)
			end
		end)
	end

	local audioAnchor = part(effects,"Machinery audio point")
	audioAnchor.Transparency = 1
	local machinery = createSound(audioAnchor,"Conveyor",asset("Conveyor"),.16,true)
	local generator = createSound(audioAnchor,"Generator",asset("Generator"),.16)
	machinery.RollOffMinDistance, machinery.RollOffMaxDistance = 10,68
	generator.RollOffMinDistance,generator.RollOffMaxDistance = 10,55
	if Audio.Conveyor == "" then machinery.PlaybackSpeed = .49 end
	if Audio.Generator == "" then generator.PlaybackSpeed = .85 end

	local tokens = {}
	for i=1,Game.PacketPoolSize do
		local block = part(effects,"Cash billet")
		block.Size,block.Transparency = Vector3.new(1.08,.29,.75),1
		local band = part(effects,"Cash band")
		band.Size,band.Color,band.Transparency = Vector3.new(.26,.32,.8),rgb(255,247,216),1
		tokens[i] = {block=block,band=band}
	end

	local sparks = {}
	for i=1,10 do
		local anchor = part(effects,"Particle point")
		anchor.Transparency,anchor.Size = 1,Vector3.one * .25
		local emitter = Instance.new("ParticleEmitter")
		emitter.Texture = "rbxasset://textures/particles/sparkles_main.dds"
		emitter.Enabled = false
		emitter.Rate = 0
		emitter.Lifetime = NumberRange.new(.24,.66)
		emitter.Speed = NumberRange.new(3,9)
		emitter.Size = NumberSequence.new(.42,.06)
		emitter.SpreadAngle = Vector2.new(80,80)
		emitter.Acceleration = Vector3.new(0,-14,0)
		emitter.LightEmission = .65
		emitter.Parent = anchor
		sparks[i] = {anchor=anchor,emitter=emitter}
	end
	local cursor = 0
	local function spray(position,color,count)
		cursor = cursor%#sparks+1
		local effect = sparks[cursor]
		effect.anchor.Position = position
		effect.emitter.Color = ColorSequence.new(color)
		effect.emitter:Emit(count)
	end

	local markers = {}
	local function bindMarker(marker)
		markers[marker] = {}
	end
	for _, marker in ipairs(CollectionService:GetTagged("FactoryLane")) do bindMarker(marker) end
	CollectionService:GetInstanceAddedSignal("FactoryLane"):Connect(bindMarker)
	CollectionService:GetInstanceRemovedSignal("FactoryLane"):Connect(function(marker) markers[marker] = nil end)
	local visibleCount, nextScan = 0,0
	local nearby, closest = {},nil
	local function scan(origin,current)
		table.clear(nearby)
		closest = nil
		local closestDistance = 66
		local world = workspace:FindFirstChild("BrainrotWorld")
		local sites = world and world:FindFirstChild("Plots")
		for marker,state in pairs(markers) do
			local id,floor = marker:GetAttribute("PlotId"),marker:GetAttribute("Floor")
			local site = sites and id and sites:FindFirstChild(string.format("Plot%02d",id))
			local epoch = site and floor and site:GetAttribute("LaneEpoch" .. floor)
			local distance = (marker.Position-origin).Magnitude
			if epoch and current >= epoch and distance < 135 and marker:IsDescendantOf(workspace) then
				state.marker,state.floor,state.epoch = marker,floor,epoch
				state.finish,state.waypoint = marker:GetAttribute("Finish"),marker:GetAttribute("Waypoint")
				state.merge,state.offset = marker:GetAttribute("Merge"),marker:GetAttribute("PhaseOffset") or 0
				state.priority = distance + (marker:GetAttribute("Primary") and 0 or 17)
				table.insert(nearby,state)
				if marker:GetAttribute("Primary") and distance < closestDistance then closest,closestDistance = marker,distance end
			else
				state.cycle = nil
			end
		end
		table.sort(nearby,function(a,b) return a.priority < b.priority end)
		if closest and player:GetAttribute("Sound") ~= false then
			audioAnchor.Position = closest.Position
			if not machinery.IsPlaying then machinery:Play() end
		elseif machinery.IsPlaying then
			machinery:Stop()
		end
	end

	RunService.RenderStepped:Connect(function()
		local camera = workspace.CurrentCamera
		if not camera then return end
		local origin, current = camera.CFrame.Position,workspace:GetServerTimeNow()
		if current >= nextScan then
			nextScan = current + .22
			scan(origin,current)
		end
		local count = 0
		for _, state in ipairs(nearby) do
			if count >= #tokens then break end
			local marker,floor = state.marker,state.floor
			local elapsed = current - state.epoch - state.offset
			if elapsed >= 0 and marker.Parent and state.finish and state.waypoint then
				local interval = Game.PacketInterval
				local cycle = math.floor(elapsed/interval)
				local phase = (elapsed%interval)/interval
				count += 1
				local token = tokens[count]
				local position
				if phase < .18 then
					position = marker.Position:Lerp(state.waypoint,phase/.18)
				elseif state.merge and phase > .88 then
					position = state.merge:Lerp(state.finish,(phase-.88)/.12)
				else
					position = state.waypoint:Lerp(state.merge or state.finish,(phase-.18)/(state.merge and .70 or .82))
				end
				local transform = CFrame.new(position) * CFrame.Angles(0,phase*.8,.14*math.sin(phase*math.pi))
				token.block.CFrame,token.band.CFrame = transform,transform
				token.block.Color = floor == 4 and Color3.fromHSV((cycle*.17+phase*.16)%1,.72,1) or Floors.Names[floor].cash
				token.block.Transparency,token.band.Transparency = 0,.08
				if state.cycle and state.cycle < cycle then
					if state.offset==0 and (state.finish-origin).Magnitude < 68 then spray(state.finish,Floors.Names[floor].cash,5) end
					if marker==closest and player:GetAttribute("Sound") ~= false then generator:Play() end
				end
				state.cycle = cycle
			end
		end
		for i=count+1,visibleCount do tokens[i].block.Transparency,tokens[i].band.Transparency = 1,1 end
		visibleCount = count
	end)
	player:GetAttributeChangedSignal("Sound"):Connect(function()
		if player:GetAttribute("Sound")==false then
			for _, sound in ipairs({purchase,collect,celebrate,machinery,generator}) do sound:Stop() end
		end
	end)

	local function flashBuild(id,plotId)
		for _, model in ipairs(CollectionService:GetTagged("FactoryBuild")) do
			if model:GetAttribute("UpgradeId")==id and model:GetAttribute("PlotId")==plotId then
				local highlight = Instance.new("Highlight")
				highlight.Adornee,highlight.DepthMode = model,Enum.HighlightDepthMode.Occluded
				highlight.FillColor,highlight.OutlineColor = rgb(110,241,190),rgb(203,255,236)
				highlight.FillTransparency,highlight.OutlineTransparency = .35,.05
				highlight.Parent = effects
				TweenService:Create(highlight,TweenInfo.new(.75),{FillTransparency=1,OutlineTransparency=1}):Play()
				Debris:AddItem(highlight,.8)
				return true
			end
		end
	end

	local function floatingMoney(position,value)
		local point = part(effects,"Collection popup")
		point.Transparency,point.Position = 1,position + Vector3.new(0,3.5,0)
		point.Size = Vector3.one * .1
		local tag = Instance.new("BillboardGui")
		tag.Size,tag.AlwaysOnTop,tag.MaxDistance = UDim2.fromOffset(160,44),true,75
		tag.Parent = point
		local text = Instance.new("TextLabel")
		text.Size,text.BackgroundTransparency = UDim2.fromScale(1,1),1
		text.Font,text.TextSize,text.TextColor3 = Enum.Font.GothamBold,27,rgb(132,255,181)
		text.TextStrokeTransparency,text.Text = .24,"+$" .. fmt(value)
		text.Parent = tag
		local timing = TweenInfo.new(.87,Enum.EasingStyle.Quad)
		TweenService:Create(point,timing,{Position=position+Vector3.new(0,7.2,0)}):Play()
		TweenService:Create(text,timing,{TextTransparency=1,TextStrokeTransparency=1}):Play()
		Debris:AddItem(point,.96)
	end

	local function confetti(burst)
		local colors = {rgb(96,238,173),rgb(255,215,92),rgb(241,129,228),rgb(120,215,255)}
		local random = Random.new()
		for i=1,burst do
			local flake = Instance.new("Frame")
			flake.Size = UDim2.fromOffset(random:NextInteger(4,9),random:NextInteger(7,15))
			flake.Position = UDim2.fromScale(random:NextNumber(),-.06-random:NextNumber()*.31)
			flake.BackgroundColor3,flake.BorderSizePixel,flake.ZIndex = colors[i%#colors+1],0,20
			flake.Rotation = random:NextInteger(0,170)
			flake.Parent = gui
			local time = random:NextNumber(.8,1.95)
			TweenService:Create(flake,TweenInfo.new(time),{
				Position = flake.Position + UDim2.fromScale(random:NextNumber(-.28,.28),1.28),
				Rotation = flake.Rotation + random:NextInteger(-330,330), BackgroundTransparency=.38,
			}):Play()
			Debris:AddItem(flake,time+.1)
		end
	end

	events.WorldFX.OnClientEvent:Connect(function(kind,position,plotId,value)
		if kind=="build" then
			spray(position+Vector3.new(0,1.2,0),rgb(100,246,190),21)
			if not flashBuild(value,plotId) then task.delay(.25,flashBuild,value,plotId) end
		elseif kind=="collect" then
			spray(position+Vector3.new(0,1,0),rgb(255,218,103),16)
			floatingMoney(position,value)
		elseif kind=="unlock" then
			spray(position+Vector3.new(0,1.4,0),Floors.Names[value].color,30)
		end
	end)
	events.Feedback.OnClientEvent:Connect(function(kind)
		local sound = player:GetAttribute("Sound") ~= false
		if kind=="collected" then
			if sound then collect:Play() end
		elseif kind=="upgrade" then
			if sound then purchase:Play() end
		elseif kind=="costume" or kind=="floor" or kind=="completed" then
			if sound then celebrate:Play() end
			confetti(kind=="completed" and 48 or 22)
		end
	end)
end

return Effects
