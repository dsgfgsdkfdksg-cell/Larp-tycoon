local Players = game:GetService("Players")
local TweenService = game:GetService("TweenService")
local Shared = game:GetService("ReplicatedStorage"):WaitForChild("Brainrot")
local Locale = require(Shared.Locale)
local Economy = require(Shared.EconomyConfig)
local Floors = require(Shared.FloorConfig)
local Costumes = require(Shared.CostumeConfig)
local fmt = require(Shared.NumberFormat)

local UI = {}
local player = Players.LocalPlayer
local rgb = Color3.fromRGB
local ink, panel, lighter = rgb(18,28,47), rgb(29,44,68), rgb(43,61,88)
local muted, white, mint, sky, gold = rgb(183,204,224), rgb(244,251,255), rgb(111,246,185), rgb(106,220,255), rgb(255,210,102)

local function make(class, parent, props)
	local object = Instance.new(class)
	for key, value in pairs(props or {}) do object[key] = value end
	object.Parent = parent
	return object
end

local function round(object, radius)
	make("UICorner",object,{CornerRadius=UDim.new(0,radius)})
end

local function outline(object, color, alpha)
	make("UIStroke",object,{Color=color,Transparency=alpha,Thickness=1,ApplyStrokeMode=Enum.ApplyStrokeMode.Border})
end

local function label(parent,text,size,color)
	return make("TextLabel",parent,{
		BackgroundTransparency=1, Text=text, Font=Enum.Font.GothamBold, TextColor3=color or white,
		TextSize=size, TextXAlignment=Enum.TextXAlignment.Left, RichText=false,
	})
end

local function button(parent,text,color,activated)
	local control = make("TextButton",parent,{
		BackgroundColor3=color or lighter, Text=text, TextColor3=white, TextSize=14, Font=Enum.Font.GothamBold,
		TextWrapped=true, AutoButtonColor=true, Selectable=true,
	})
	round(control,8)
	if activated then control.Activated:Connect(activated) end
	return control
end

local function boundedText(text,limit,min)
	text.TextScaled = true
	make("UITextSizeConstraint",text,{MaxTextSize=limit,MinTextSize=min or 8})
end

function UI.start(gui,events)
	local language = player:GetAttribute("Language") or (string.sub(string.lower(player.LocaleId),1,2) == "ru" and "ru" or "en")
	local function tr(key,...) return Locale(language,key,...) end
	local function attr(key,default)
		local value = player:GetAttribute(key)
		if value == nil then return default end
		return value
	end

	local hud = make("Frame",gui,{
		Name="Dashboard", Position=UDim2.fromOffset(12,12), Size=UDim2.new(1,-24,0,166),
		BackgroundColor3=ink, BackgroundTransparency=.04,
	})
	make("UISizeConstraint",hud,{MaxSize=Vector2.new(459,166)})
	round(hud,15)
	outline(hud,sky,.61)
	local marker = make("Frame",hud,{Position=UDim2.fromOffset(12,9),Size=UDim2.fromOffset(34,3),BackgroundColor3=mint,BorderSizePixel=0})
	round(marker,2)
	local title = label(hud,"BRAINROT FACTORY",19,white)
	title.Position, title.Size = UDim2.fromOffset(12,16),UDim2.new(1,-24,0,23)
	local floorLabel = label(hud,"",13,muted)
	floorLabel.Position, floorLabel.Size = UDim2.fromOffset(12,41),UDim2.new(1,-77,0,20)
	boundedText(floorLabel,14,9)
	local percent = label(hud,"0%",15,mint)
	percent.TextXAlignment = Enum.TextXAlignment.Right
	percent.Position, percent.Size = UDim2.new(1,-64,0,41),UDim2.fromOffset(52,20)
	local meter = make("Frame",hud,{Position=UDim2.fromOffset(12,66),Size=UDim2.new(1,-24,0,5),BackgroundColor3=lighter,BorderSizePixel=0})
	round(meter,4)
	local fill = make("Frame",meter,{Size=UDim2.fromScale(0,1),BackgroundColor3=mint,BorderSizePixel=0})
	round(fill,4)
	local progress = label(hud,"",11,muted)
	progress.Position, progress.Size = UDim2.fromOffset(12,76),UDim2.new(1,-24,0,15)

	local metrics = make("Frame",hud,{Position=UDim2.fromOffset(12,98),Size=UDim2.new(1,-24,0,55),BackgroundTransparency=1})
	local metricLabels, values = {}, {}
	for i, entry in ipairs({{"balance",mint},{"income",sky},{"chest",gold}}) do
		local card = make("Frame",metrics,{Position=UDim2.new((i-1)/3,(i-1)*3,0,0),Size=UDim2.new(1/3,-4,1,0),BackgroundColor3=panel})
		round(card,8)
		local key = label(card,"",10,muted)
		key.Position,key.Size = UDim2.fromOffset(7,6),UDim2.new(1,-13,0,15)
		boundedText(key,11)
		local value = label(card,"—",22,entry[2])
		value.Position,value.Size = UDim2.fromOffset(7,22),UDim2.new(1,-12,0,27)
		boundedText(value,23,12)
		metricLabels[entry[1]], values[entry[1]] = key,value
	end

	local actions = make("Frame",gui,{Name="Navigation",Position=UDim2.fromOffset(12,185),Size=UDim2.new(1,-24,0,43),BackgroundTransparency=1})
	make("UISizeConstraint",actions,{MaxSize=Vector2.new(459,43)})
	local shade = make("Frame",gui,{
		Name="Modal",Visible=false,Size=UDim2.fromScale(1,1),BackgroundColor3=ink,BackgroundTransparency=.32,
		BorderSizePixel=0,Active=true,ZIndex=12,
	})
	local modal = make("Frame",shade,{
		AnchorPoint=Vector2.new(.5,.5),Position=UDim2.fromScale(.5,.49),Size=UDim2.new(1,-26,1,-66),
		BackgroundColor3=ink,ZIndex=13,
	})
	make("UISizeConstraint",modal,{MaxSize=Vector2.new(518,460),MinSize=Vector2.new(232,168)})
	round(modal,16)
	outline(modal,sky,.42)
	local modalName = label(modal,"",22,white)
	modalName.Position,modalName.Size,modalName.ZIndex = UDim2.fromOffset(17,11),UDim2.new(1,-75,0,37),14
	boundedText(modalName,23,12)
	local close = button(modal,"×",lighter)
	close.AnchorPoint,close.Position,close.Size,close.TextSize,close.ZIndex = Vector2.new(1,0),UDim2.new(1,-13,0,12),UDim2.fromOffset(43,39),25,14
	local rows = make("ScrollingFrame",modal,{
		Position=UDim2.fromOffset(13,61),Size=UDim2.new(1,-26,1,-74),CanvasSize=UDim2.new(),
		AutomaticCanvasSize=Enum.AutomaticSize.Y,BackgroundTransparency=1,BorderSizePixel=0,ScrollBarThickness=5,
		ScrollBarImageColor3=sky,ZIndex=14,ScrollingDirection=Enum.ScrollingDirection.Y,
	})
	make("UIListLayout",rows,{Padding=UDim.new(0,7),SortOrder=Enum.SortOrder.LayoutOrder})
	make("UIPadding",rows,{PaddingRight=UDim.new(0,7),PaddingBottom=UDim.new(0,8)})
	local current, rankBy = nil, "byCash"
	local function dismiss()
		current = nil
		shade.Visible = false
	end
	close.Activated:Connect(dismiss)

	local tutorial = make("Frame",gui,{Name="Tutorial",Position=UDim2.fromOffset(12,238),Size=UDim2.new(1,-24,0,53),
		BackgroundColor3=ink,BackgroundTransparency=.07,Visible=false,
	})
	make("UISizeConstraint",tutorial,{MaxSize=Vector2.new(459,53)})
	round(tutorial,9)
	outline(tutorial,mint,.53)
	local hint = label(tutorial,"",14,mint)
	hint.Position,hint.Size = UDim2.fromOffset(11,6),UDim2.new(1,-22,1,-12)
	hint.TextWrapped = true
	boundedText(hint,14,10)

	local toast = label(gui,"",17,white)
	toast.Name,toast.AnchorPoint,toast.Position = "Toast",Vector2.new(.5,.5),UDim2.fromScale(.5,.78)
	toast.Size,toast.ZIndex = UDim2.new(1,-25,0,49),17
	toast.TextXAlignment,toast.TextWrapped = Enum.TextXAlignment.Center,true
	toast.BackgroundTransparency,toast.BackgroundColor3,toast.Visible = .07,ink,false
	make("UISizeConstraint",toast,{MaxSize=Vector2.new(450,49)})
	make("UIPadding",toast,{PaddingLeft=UDim.new(0,9),PaddingRight=UDim.new(0,9)})
	round(toast,11)
	outline(toast,sky,.42)

	local function liner(text,color,height)
		local row = make("Frame",rows,{Size=UDim2.new(1,0,0,height or 60),BackgroundColor3=panel,ZIndex=15})
		round(row,9)
		local heading = label(row,text,15,color or white)
		heading.Position,heading.Size,heading.ZIndex = UDim2.fromOffset(12,7),UDim2.new(1,-24,0,25),16
		return row, heading
	end

	local function sub(row,text,size,color)
		local field = label(row,text,size or 12,color or muted)
		field.Position,field.Size,field.ZIndex = UDim2.fromOffset(12,31),UDim2.new(1,-24,0,20),16
		return field
	end

	local function control(row,text,width,callback)
		local push = button(row,text,lighter,callback)
		push.AnchorPoint,push.Position,push.Size,push.ZIndex = Vector2.new(1,.5),UDim2.new(1,-8,.5,0),UDim2.fromOffset(width,43),16
		return push
	end

	local function rerender()
		if not current then return end
		modalName.Text = tr(current)
		local order = 0
		for _, child in ipairs(rows:GetChildren()) do if child:IsA("GuiObject") then child:Destroy() end end
		local function add(text,color,height)
			local row, heading = liner(text,color,height)
			order += 1
			row.LayoutOrder = order
			return row,heading
		end
		if current == "costumes" then
			for i, costume in ipairs(Costumes) do
				local row, heading = add(language=="ru" and costume.ru or costume.name,costume.tint,69)
				local mask = attr("CostumesMask",0)
				local owned = bit32.band(mask,bit32.lshift(1,i-1)) > 0
				if owned then
					local equipped = attr("Equipped","") == costume.id
					heading.Size = UDim2.new(1,-112,0,50)
					heading.TextWrapped = true
					boundedText(heading,16,11)
					local action = control(row,tr(equipped and "remove" or "equip"),87,function()
						events.Action:FireServer("equip",equipped and "" or costume.id)
					end)
					action.BackgroundColor3 = equipped and rgb(75,66,126) or rgb(33,106,93)
				else
					boundedText(heading,16,10)
					local key = attr("Stage",0) >= i*20 and "availableCostume" or "lockedCostume"
					sub(row,tr(key,i,fmt(Economy.CostumePrices[i])))
				end
			end
		elseif current == "settings" then
			local row = add(tr("language"),white)
			local localeButton = control(row,language == "ru" and "Русский  /  EN" or "English  /  RU",124,function()
				events.Action:FireServer("language",language == "ru" and "en" or "ru")
			end)
			localeButton.TextSize = 13
			for _, entry in ipairs({{"Music","music"},{"Sound","sound"}}) do
				local enabled = attr(entry[1],true)
				local option = add(tr(entry[2]))
				local choice = control(option,tr(enabled and "on" or "off"),76,function()
					events.Action:FireServer(entry[2],not enabled)
				end)
				if enabled then choice.BackgroundColor3 = rgb(33,106,93) end
			end
			local access = add(tr("access"),white,68)
			if attr("Stage",0) >= 15 and attr("PlotId",0) > 0 then
				control(access,tr(attr("Doors",false) and "closedState" or "openState"),103,function()
					events.Action:FireServer("doors")
				end)
			else
				local note = sub(access,tr("doorLocked"))
				boundedText(note,12)
			end
		elseif current == "leaderboard" then
			local options = add("",nil,47)
			for i, key in ipairs({"byCash","byStage"}) do
				local tab = button(options,tr(key),key==rankBy and rgb(33,106,93) or lighter,function()
					rankBy = key
					rerender()
				end)
				tab.Position,tab.Size,tab.ZIndex = UDim2.new((i-1)*.5,4,0,3),UDim2.new(.5,-8,1,-6),16
			end
			local entries = {}
			for _, other in ipairs(Players:GetPlayers()) do
				if other:GetAttribute("Ready") then table.insert(entries,other) end
			end
			local rankStat = rankBy == "byStage" and "Stage" or "Cash"
			table.sort(entries,function(a,b)
				local diff = (a:GetAttribute(rankStat) or 0) - (b:GetAttribute(rankStat) or 0)
				if diff ~= 0 then return diff > 0 end
				return a.UserId < b.UserId
			end)
			for i, other in ipairs(entries) do
				local row, heading = add(string.format("%d  %s",i,other.DisplayName),other == player and mint or white,56)
				heading.TextTruncate = Enum.TextTruncate.AtEnd
				sub(row,string.format("$%s   ·   %d%%",fmt(other:GetAttribute("Cash")),math.floor((other:GetAttribute("Stage") or 0)*1.25)))
			end
		elseif current == "completed" then
			modalName.TextColor3 = gold
			local row, text = add(tr("completeBody"),mint,91)
			text.TextWrapped = true
			text.Size = UDim2.new(1,-24,1,-14)
			local action = add("",nil,59)
			control(action,tr("dismiss"),145,dismiss)
		end
	end

	local function open(key)
		current = key
		modalName.TextColor3 = white
		rows.CanvasPosition = Vector2.zero
		shade.Visible = true
		rerender()
	end

	local nav = {}
	for i,key in ipairs({"costumes","settings","teleport","leaderboard"}) do
		local action = button(actions,"",key=="teleport" and rgb(34,100,96) or panel,function()
			if key == "teleport" then events.Action:FireServer("teleport") else open(key) end
		end)
		action.Position,action.Size = UDim2.new((i-1)*.25,2,0,0),UDim2.new(.25,-5,1,0)
		boundedText(action,13,9)
		make("UIPadding",action,{PaddingLeft=UDim.new(0,4),PaddingRight=UDim.new(0,4)})
		nav[key] = action
	end

	local cash = make("NumberValue",nil,{Value=0})
	local cashTween, progressTween, targetCash, targetStage
	cash:GetPropertyChangedSignal("Value"):Connect(function() values.balance.Text = "$" .. fmt(math.floor(cash.Value+.5)) end)
	local function redraw()
		language = attr("Language",language)
		for key, field in pairs(metricLabels) do field.Text = tr(key) end
		for key, action in pairs(nav) do action.Text = tr(key) end
		local ready = attr("Ready",false)
		local stage, floorNumber = attr("Stage",0),attr("Floor",1)
		local floor = Floors.Names[floorNumber]
		floorLabel.Text = ready and tr("floor",floorNumber,floor[language]) or tr("loading")
		percent.Text = math.floor(stage*1.25) .. "%"
		progress.Text = tr("progress",stage)
		if targetStage ~= stage then
			targetStage = stage
			if progressTween then progressTween:Cancel() end
			progressTween = TweenService:Create(fill,TweenInfo.new(.32),{Size=UDim2.fromScale(stage/80,1)})
			progressTween:Play()
		end
		local balance = attr("Cash",0)
		if ready and targetCash ~= balance then
			targetCash = balance
			if cashTween then cashTween:Cancel() end
			cashTween = TweenService:Create(cash,TweenInfo.new(.35,Enum.EasingStyle.Quad),{Value=balance})
			cashTween:Play()
			values.balance.Text = "$" .. fmt(math.floor(cash.Value+.5))
		end
		values.income.Text = ready and "$" .. fmt(attr("Rate",0)) or "—"
		values.chest.Text = ready and "$" .. fmt(attr("Chest",0)) or "—"
		values.chest.TextColor3 = attr("Chest",0)>0 and gold or muted
		local step = attr("Tutorial",0)
		tutorial.Visible = ready and step < 5
		hint.Text = tr("tutorial" .. math.min(4,step))
	end

	local queue
	for _,key in ipairs({"Ready","Cash","Chest","Rate","Stage","Floor","Language","Tutorial","CostumesMask","Equipped","Music","Sound","Doors","PlotId"}) do
		player:GetAttributeChangedSignal(key):Connect(function()
			if queue then return end
			queue = true
			task.defer(function()
				queue = false
				redraw()
			end)
		end)
	end
	for _, key in ipairs({"Language","Stage","CostumesMask","Equipped","Music","Sound","Doors","PlotId"}) do
		player:GetAttributeChangedSignal(key):Connect(function()
			task.defer(function()
				if current then rerender() end
			end)
		end)
	end
	task.spawn(function()
		while gui.Parent do
			task.wait(1.6)
			if current == "leaderboard" then rerender() end
		end
	end)

	local hudScale, navScale, tutorialScale = make("UIScale",hud),make("UIScale",actions),make("UIScale",tutorial)
	local function fitViewport()
		local camera = workspace.CurrentCamera
		local scale = camera and camera.ViewportSize.Y < 470 and .74 or 1
		hudScale.Scale, navScale.Scale, tutorialScale.Scale = scale,scale,scale
		actions.Position = UDim2.fromOffset(12,12+173*scale)
		tutorial.Position = UDim2.fromOffset(12,12+226*scale)
	end
	local cameraSize
	local function trackCamera()
		if cameraSize then cameraSize:Disconnect() end
		local camera = workspace.CurrentCamera
		if camera then cameraSize = camera:GetPropertyChangedSignal("ViewportSize"):Connect(fitViewport) end
		fitViewport()
	end
	workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(trackCamera)
	trackCamera()

	local toastToken = 0
	events.Feedback.OnClientEvent:Connect(function(kind,value)
		local text
		if kind == "collected" then text = tr(kind,fmt(value))
		elseif kind == "upgrade" and Economy.ById[value] then text = tr(kind,Economy.ById[value][language])
		elseif kind == "floor" and Floors.Names[value] then text = tr("floorOpened",Floors.Names[value][language])
		elseif kind == "costume" then
			for _, spec in ipairs(Costumes) do if spec.id == value then text = tr(kind,language == "ru" and spec.ru or spec.name) end end
		elseif kind == "completed" then open("completed") return
		else text = tr(kind) end
		if not text then return end
		toastToken += 1
		local token = toastToken
		toast.Text,toast.TextColor3,toast.TextTransparency,toast.Visible = text,kind == "short" and gold or mint,0,true
		toast.Position = UDim2.fromScale(.5,.81)
		TweenService:Create(toast,TweenInfo.new(.21,Enum.EasingStyle.Quad),{Position=UDim2.fromScale(.5,.76)}):Play()
		task.delay(2.6,function() if token == toastToken then toast.Visible = false end end)
	end)
	redraw()
end

return UI
