local player = game:GetService("Players").LocalPlayer
local shared = game:GetService("ReplicatedStorage"):WaitForChild("Brainrot")
local network = shared:WaitForChild("Network")
local gui = player:WaitForChild("PlayerGui"):WaitForChild("FactoryHUD")
require(script.Parent.UIController).start(gui,network)
require(script.Parent.EffectsController).start(gui,network)
require(script.Parent.WorldController).start()
