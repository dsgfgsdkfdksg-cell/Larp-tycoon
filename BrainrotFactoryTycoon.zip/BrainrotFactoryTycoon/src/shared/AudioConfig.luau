-- Optional: enter moderated IDs for the original recordings in assets/audio.
-- Until then, the client uses sounds bundled with Roblox and plays its own note sequence.
return {
	Music = "", Conveyor = "", Generator = "", Collect = "", Purchase = "", Celebrate = "",
	Builtin = {
		Note = "rbxasset://sounds/electronicpingshort.wav",
		Conveyor = "rbxasset://sounds/action_footsteps_plastic.mp3",
		Generator = "rbxasset://sounds/bass.wav",
		Collect = "rbxasset://sounds/electronicpingshort.wav",
		Purchase = "rbxasset://sounds/button.wav",
		Celebrate = "rbxasset://sounds/electronicpingshort.wav",
	},
}
