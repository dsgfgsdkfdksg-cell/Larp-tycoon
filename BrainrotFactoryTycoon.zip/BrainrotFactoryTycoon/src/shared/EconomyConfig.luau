-- Each row sets the displayed total rate after this purchase and optionally a global multiplier.
local floors = {
	{
		{ "Starter conveyor & generator", "Стартовый конвейер и генератор", "starter", "A", 1000, 10 },
		{ "Second generator", "Второй генератор", "dropper", "B", 500, 18 },
		{ "Generator calibration", "Калибровка генераторов", "calibrator", "G", 900, 28 },
		{ "Conveyor accelerator", "Ускоритель конвейера", "speed", "B", 1400, 35 },
		{ "Third generator", "Третий генератор", "dropper", "C", 2000, 50 },
		{ "Factory walls", "Стены фабрики", "walls", "-", 4300, 50 },
		{ "Double-value chest", "Сундук ×2", "chest", "-", 5400, 100, 2 },
		{ "Fourth generator", "Четвёртый генератор", "dropper", "D", 6700, 125 },
		{ "Reinforced conveyor", "Усиленный конвейер", "belt", "D", 9400, 150 },
		{ "Gold generator", "Золотой генератор", "gold", "E", 13700, 200 },
		{ "Factory lighting", "Освещение фабрики", "lights", "-", 16300, 200 },
		{ "Twin generator", "Двойной генератор", "dual", "H", 19800, 260 },
		{ "Plated chest", "Усиленный сундук", "chest", "-", 27000, 325, 2.5 },
		{ "Plasma generator", "Плазменный генератор", "plasma", "F", 33200, 400 },
		{ "Security doors", "Защитные двери", "doors", "-", 39200, 400 },
		{ "Super generator", "Супергенератор", "super", "I", 52000, 500 },
		{ "Production booster", "Усилитель производства", "boost", "J", 65000, 650 },
		{ "Mega generator", "Мега-генератор", "mega", "K", 84000, 800 },
		{ "Final starter multiplier", "Финальный множитель цеха", "final", "L", 97000, 1000, 3.125 },
		{ "Ceiling & stairs", "Потолок и лестница", "stairs", "-", 100000, 1000 },
	},
	{
		{ "Industrial generator", "Промышленный генератор", "starter", "A", 50000, 1250 },
		{ "Dual conveyor", "Двойной конвейер", "doublebelt", "B", 80000, 1550 },
		{ "Robotic arm", "Роботизированный манипулятор", "arm", "B", 110000, 1850 },
		{ "Hydraulic press", "Гидравлический пресс", "press", "C", 150000, 2250 },
		{ "Currency furnace", "Денежная печь", "furnace", "D", 210000, 2700 },
		{ "Steel walls", "Стальные стены", "walls", "-", 220000, 2700 },
		{ "Industrial chest", "Промышленный сундук", "chest", "-", 300000, 3200, 3.6 },
		{ "Gold billet caster", "Литейная золотых слитков", "gold", "E", 320000, 3850 },
		{ "Assembly robot", "Робот-сборщик", "arm", "F", 440000, 4400 },
		{ "Twin stamping press", "Сдвоенный штамповочный пресс", "press", "G", 500000, 4900 },
		{ "Steam pipes", "Паровые трубы", "pipes", "-", 500000, 4900 },
		{ "Induction smelter", "Индукционная печь", "furnace", "H", 590000, 5600 },
		{ "Industrial multiplier", "Промышленный множитель", "boost", "I", 730000, 6350, 4 },
		{ "Automated loader", "Автоматический погрузчик", "loader", "J", 840000, 7000 },
		{ "Foundry reactor", "Реактор литейной", "core", "K", 910000, 7750 },
		{ "High-bay lamps", "Промышленные светильники", "lights", "-", 910000, 7750 },
		{ "Alloy vault", "Хранилище сплавов", "chest", "-", 1090000, 8500 },
		{ "Overdrive turbine", "Турбина форсажа", "turbine", "L", 1280000, 9250 },
		{ "Precision yield node", "Блок точной выработки", "rail", "F", 1510000, 10000, 4.3 },
		{ "Laboratory stairs", "Лестница в лабораторию", "stairs", "-", 1690000, 10000 },
	},
	{
		{ "Laser generator", "Лазерный генератор", "starter", "A", 800000, 12500 },
		{ "Magnetic conveyor", "Магнитный конвейер", "magnetic", "B", 1000000, 15500 },
		{ "Crystal reactor", "Кристаллический реактор", "crystal", "B", 1400000, 18500 },
		{ "Photon separator", "Разделитель фотонов", "laser", "C", 1900000, 22000 },
		{ "Energy core", "Энергетическое ядро", "core", "D", 2600000, 27000 },
		{ "Laboratory walls", "Стены лаборатории", "walls", "-", 2700000, 27000 },
		{ "Neon vault", "Неоновое хранилище", "chest", "-", 3600000, 32000, 5 },
		{ "Ion emitter", "Ионный эмиттер", "plasma", "E", 4100000, 38500 },
		{ "Holographic panels", "Голографические панели", "holo", "F", 5500000, 44000 },
		{ "Quantum generator", "Квантовый генератор", "quantum", "G", 6300000, 49000 },
		{ "Factory elevator", "Грузовой лифт", "lift", "-", 6300000, 49000 },
		{ "Flux accelerator", "Потоковый ускоритель", "speed", "D", 7300000, 56000 },
		{ "Quantum multiplier", "Квантовый множитель", "boost", "H", 8900000, 63500, 5.6 },
		{ "Singularity chamber", "Камера сингулярности", "void", "I", 10300000, 70000 },
		{ "Neon mint", "Монетный двор неона", "crystal", "J", 12000000, 77500 },
		{ "Ceiling light grid", "Световая решётка", "lights", "-", 12000000, 77500 },
		{ "Graviton collider", "Гравитонный коллайдер", "rail", "K", 13200000, 85000 },
		{ "Resonance stabilizer", "Стабилизатор резонанса", "core", "L", 15000000, 92500, 6 },
		{ "Future Lab amplifier", "Усилитель лаборатории", "final", "F", 18700000, 100000 },
		{ "Orbital stairs", "Лестница в орбитальный цех", "stairs", "-", 20600000, 100000 },
	},
	{
		{ "Cosmic generator", "Космический генератор", "starter", "A", 12900000, 125000 },
		{ "Antigravity conveyor", "Антигравитационный конвейер", "antigravity", "B", 16700000, 155000 },
		{ "Launch portal", "Пусковой портал", "portal", "B", 22200000, 185000 },
		{ "Stellar reactor", "Звёздный реактор", "core", "C", 27600000, 220000 },
		{ "Dark matter generator", "Генератор тёмной материи", "void", "D", 34100000, 270000 },
		{ "Panoramic windows", "Панорамные окна", "walls", "-", 41800000, 270000 },
		{ "Prismatic vault", "Призматическое хранилище", "chest", "-", 47200000, 320000, 7 },
		{ "Rainbow mint", "Радужный монетный двор", "rainbow", "E", 53300000, 385000 },
		{ "Wormhole array", "Сеть червоточин", "portal", "F", 66600000, 440000 },
		{ "Nebula separator", "Сепаратор туманности", "laser", "G", 77800000, 490000 },
		{ "Orbital light ring", "Орбитальное освещение", "lights", "-", 82400000, 490000 },
		{ "Dark fusion furnace", "Печь тёмного синтеза", "furnace", "H", 87900000, 560000 },
		{ "Cosmic multiplier", "Космический множитель", "boost", "I", 101200000, 635000, 7.9 },
		{ "Supernova reactor", "Реактор сверхновой", "core", "J", 114000000, 700000 },
		{ "Prism overdrive", "Призматический форсаж", "turbine", "K", 128000000, 775000 },
		{ "Neon roof", "Неоновая крыша", "roof", "-", 135000000, 775000 },
		{ "Galactic relay", "Галактический ретранслятор", "rail", "E", 145000000, 850000 },
		{ "Brainrot reactor", "Центральный Brainrot-реактор", "reactor", "L", 164000000, 925000 },
		{ "Ultimate multiplier", "Финальный множитель", "final", "C", 178000000, 975000, 8.3 },
		{ "Brainrot Factory sign", "Вывеска Brainrot Factory", "sign", "-", 192000000, 1000000 },
	},
}

local Economy = { Upgrades = {}, ById = {}, CostumePrices = {}, Stages = {} }
local baseByFloor, multiplier, lastBase = { 0, 0, 0, 0 }, 1, 0
Economy.Stages[0] = { rate = 0, multiplier = 1, laneRates = {0, 0, 0, 0} }
for floor, rows in ipairs(floors) do
	for order, row in ipairs(rows) do
		local index = #Economy.Upgrades + 1
		local upgrade = {
			id = string.format("F%02d_%02d", floor, order), index = index,
			floor = floor, order = order, en = row[1], ru = row[2], kind = row[3],
			slot = row[4], price = row[5], rate = row[6], multiplier = row[7] or multiplier,
		}
		-- Preserve the previous floors' production. Global boosts affect every active lane.
		multiplier = upgrade.multiplier
		local totalBase = upgrade.rate / multiplier
		assert(totalBase >= lastBase - 0.00001, "A purchase cannot remove existing production")
		baseByFloor[floor] += totalBase - lastBase
		lastBase = totalBase
		local laneRates = table.create(4, 0)
		local assigned = 0
		for lane = 1, floor - 1 do
			laneRates[lane] = math.floor(baseByFloor[lane] * multiplier + 0.00001)
			assigned += laneRates[lane]
		end
		laneRates[floor] = upgrade.rate - assigned
		Economy.Upgrades[index] = upgrade
		Economy.ById[upgrade.id] = upgrade
		Economy.Stages[index] = { rate = upgrade.rate, multiplier = multiplier, laneRates = laneRates }
	end
	Economy.CostumePrices[floor] = rows[#rows][5]
end

function Economy.floorFor(stage)
	return math.min(4, math.floor(stage / 20) + 1)
end

return Economy
