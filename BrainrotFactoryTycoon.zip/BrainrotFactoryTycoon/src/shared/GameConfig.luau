return table.freeze({
	MaxPlayers = 8,
	StartCash = 1000,
	MaxCash = 900000000000000,
	PromptDistance = 11,
	PacketInterval = 2.4,
	PacketPoolSize = 48,
	PlotCount = 8,
	StudioMemory = true,
	DataStore = "BrainrotFactoryProfiles_v1",
	StudioDataStore = "BrainrotFactoryStudioProfiles_v1",
	SaveEvery = 40,
	LeaseSeconds = 180,
})
