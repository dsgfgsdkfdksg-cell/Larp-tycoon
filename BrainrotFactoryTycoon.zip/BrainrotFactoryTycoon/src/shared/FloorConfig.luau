return {
	Height = 15,
	Names = {
		{ en = "Starter Factory", ru = "Стартовая фабрика", color = Color3.fromRGB(71, 231, 157), body = Color3.fromRGB(53, 121, 102), cash = Color3.fromRGB(120, 255, 145) },
		{ en = "Industrial Factory", ru = "Промышленный цех", color = Color3.fromRGB(255, 174, 68), body = Color3.fromRGB(162, 89, 53), cash = Color3.fromRGB(255, 204, 76) },
		{ en = "Future Laboratory", ru = "Лаборатория будущего", color = Color3.fromRGB(74, 227, 255), body = Color3.fromRGB(53, 103, 164), cash = Color3.fromRGB(116, 240, 255) },
		{ en = "Ultimate Brainrot Factory", ru = "Финальная фабрика Brainrot", color = Color3.fromRGB(214, 124, 255), body = Color3.fromRGB(97, 62, 153), cash = Color3.fromRGB(241, 139, 255) },
	},
}
