local entries = {
	loading={"Loading your factory…","Загружаем фабрику…"},
	balance={"BALANCE","БАЛАНС"}, income={"PER SECOND","В СЕКУНДУ"}, chest={"IN THE CHEST","В СУНДУКЕ"},
	floor={"Floor %d · %s","Этаж %d · %s"}, progress={"%d / 80 upgrades","Улучшения: %d / 80"},
	costumes={"Costumes","Костюмы"}, settings={"Settings","Настройки"}, teleport={"Teleport to Base","Телепорт на базу"},
	leaderboard={"Leaderboard","Лидеры"}, byCash={"By balance","По балансу"}, byStage={"By progress","По прогрессу"},
	equip={"Equip","Надеть"}, remove={"Remove","Снять"}, equipped={"Costume equipped","Костюм надет"},
	unequipped={"Costume removed","Костюм снят"}, lockedCostume={"Finish floor %d · $%s","Завершите этаж %d · $%s"},
	availableCostume={"Floor %d display · $%s","Витрина этажа %d · $%s"},
	language={"Language","Язык"}, music={"Music","Музыка"}, sound={"Sound effects","Звуковые эффекты"},
	access={"Base access","Доступ на базу"}, on={"On","Вкл"}, off={"Off","Выкл"},
	openState={"Open","Открыт"}, closedState={"Closed","Закрыт"}, doorLocked={"Unlock security doors on floor 1","Купите защитные двери на первом этаже"},
	claimed={"Plot claimed. Your factory is ready to build.","Участок занят. Можно строить фабрику."},
	collected={"+$%s collected","Получено +$%s"}, empty={"The chest is empty","Сундук пуст"},
	short={"You need more cash","Недостаточно денег"}, locked={"That upgrade is still locked","Улучшение пока недоступно"},
	owned={"Already purchased","Уже куплено"}, upgrade={"Built · %s","Построено · %s"},
	floorOpened={"Floor unlocked · %s","Открыт этаж · %s"}, costume={"Costume unlocked · %s","Костюм открыт · %s"},
	completed={"TYCOON COMPLETED","ФАБРИКА ЗАВЕРШЕНА"}, completeBody={"80 upgrades built. Your production is at full power!","Все 80 улучшений куплены. Фабрика работает на полную мощность!"},
	dismiss={"Continue","Продолжить"}, noPlot={"Claim a free plot first","Сначала займите свободный участок"},
	closed={"Base closed to visitors","База закрыта для посетителей"}, open={"Base open to visitors","База открыта для посетителей"},
	lift={"Lift arrived","Лифт прибыл"}, teleported={"Welcome back to your factory","Вы вернулись на свою фабрику"},
	tutorial0={"Follow the arrow to a free plot and activate Claim Tycoon.","Идите по стрелке к свободному участку и займите его."},
	tutorial1={"Activate the green pad to buy the starter conveyor for $1,000.","Купите стартовый конвейер за $1 000 на зелёной кнопке."},
	tutorial2={"Watch the conveyor. The first cash packet is on its way.","Следите за конвейером. Первая партия денег уже в пути."},
	tutorial3={"Go to Collect Cash and take your money. The next generator costs $500.","Подойдите к кассе и заберите деньги. Следующий генератор стоит $500."},
	tutorial4={"Collect more cash if needed, then buy the second generator for $500.","Заберите ещё денег из сундука, если нужно, и купите генератор за $500."},
}

return function(language,key,...)
	local pair = entries[key]
	local value = pair and pair[language == "ru" and 2 or 1] or key
	return select("#",...) > 0 and string.format(value,...) or value
end
