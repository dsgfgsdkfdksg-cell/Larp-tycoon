local units = {{1e12,"T"},{1e9,"B"},{1e6,"M"},{1e3,"K"}}

return function(value, exact)
	local amount = math.max(0, math.floor(value or 0))
	if exact then
		return (string.format("%.0f",amount):reverse():gsub("(%d%d%d)","%1 "):reverse():gsub("^ ",""))
	end
	for _, unit in ipairs(units) do
		if amount >= unit[1] then
			local scaled = math.floor(amount / unit[1] * 10) / 10
			return (string.format("%.1f", scaled):gsub("%.0$", "")) .. unit[2]
		end
	end
	return tostring(amount)
end
