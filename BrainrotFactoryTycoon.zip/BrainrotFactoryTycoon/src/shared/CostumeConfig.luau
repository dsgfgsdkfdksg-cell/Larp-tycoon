return {
	{ id = "sahur", name = "Tung Tung Tung Sahur", ru = "Тунг Тунг Тунг Сахур", tint = Color3.fromRGB(231, 170, 94) },
	{ id = "tralala", name = "Tralalero Tralala", ru = "Тралалеро Тралала", tint = Color3.fromRGB(84, 191, 255) },
	{ id = "patapim", name = "Brr Brr Patapim", ru = "Брр Брр Патапим", tint = Color3.fromRGB(133, 205, 102) },
	{ id = "saturnita", name = "La Vacca Saturno Saturnita", ru = "Ла Вакка Сатурно Сатурнита", tint = Color3.fromRGB(225, 130, 255) },
}
