local P = require(script.Parent.Parts)
local Lighting = game:GetService("Lighting")
local World = {}

local ink = P.Ink
local warm = Color3.fromRGB(255, 208, 100)
local teal = Color3.fromRGB(95, 238, 190)
local lawn = Color3.fromRGB(118, 198, 126)
local pavement = Color3.fromRGB(187, 205, 208)
local asphalt = Color3.fromRGB(64, 80, 107)
local neon = Enum.Material.Neon

local function box(parent, name, x, y, z, sx, sy, sz, color, solid, material)
	return P.part(parent, name, Vector3.new(sx, sy, sz), CFrame.new(x, y, z), color, material, solid)
end

local function tree(parent, x, z, variation)
	local m = P.make("Model", parent, "Tree")
	box(m, "Mulch", x, 0.14, z, 5, 0.25, 5, Color3.fromRGB(87, 107, 84), false)
	box(m, "Trunk", x, 2.9, z, 0.9, 5.8, 0.9, Color3.fromRGB(103, 71, 60), true)
	local greens = { Color3.fromRGB(78, 174, 111), Color3.fromRGB(100, 206, 121), Color3.fromRGB(54, 153, 120) }
	for i = 1, 3 do
		local spread = i == 1 and -1.1 or i == 2 and 0.9 or 0
		P.part(m, "Canopy", Vector3.new(5.2, 4.1, 5), CFrame.new(x + spread, 5.4 + i * 0.85, z + spread * 0.5), greens[(i + variation) % 3 + 1], nil, false, Enum.PartType.Ball)
	end
end

local function lamp(parent, x, z, side)
	local m = P.make("Model", parent, "Street lamp")
	box(m, "Base", x, 0.38, z, 1.7, 0.7, 1.7, ink, true)
	box(m, "Post", x, 4, z, 0.45, 7.7, 0.45, ink, true)
	box(m, "Arm", x, 7.58, z + 0.65 * side, 0.52, 0.35, 2.2, ink)
	local head = box(m, "Lamp", x, 7.38, z + 1.5 * side, 1.35, 0.2, 1.2, warm, false, neon)
	P.light(head, warm, 15, 0.6)
end

local function shop(parent, x, z, note, ru, color, side, tall)
	local m = P.make("Model", parent, note)
	local height = tall and 19 or 12
	box(m, "Foundation", x, 0.3, z, 23, 0.6, 22, pavement, true)
	box(m, "Building", x, height / 2, z, 20, height, 18, color, true)
	box(m, "Roof", x, height + 0.48, z, 21.6, 1, 19.5, ink, true)
	box(m, "Roofline", x, height - 0.45, z, 21, 0.32, 19, warm, false)
	local face = side > 0 and Enum.NormalId.Back or Enum.NormalId.Front
	local sign = box(m, "Store sign", x, 7, z + 9.3 * side, 15, 2.4, 0.42, ink, false)
	P.translate(P.surface(sign, "Name", note, face), note, ru)
	for i = -1, 1 do
		local pane = box(m, "Shop window", x + i * 5, 3, z + 9.12 * side, 4.1, 4.1, 0.24, Color3.fromRGB(148, 224, 241), false, Enum.Material.Glass)
		pane.Reflectance = 0.17
		box(m, "Awning", x + i * 5, 5.75, z + 10.1 * side, 4.9, 0.5, 2.7, i == 0 and warm or P.White, false)
		if tall then box(m, "Upstairs window", x + i * 5, 13, z + 9.12 * side, 3.8, 5, 0.25, Color3.fromRGB(180, 221, 243), false, Enum.Material.Glass) end
	end
	box(m, "Roof vent", x + 5, height + 2, z + 3, 5, 2.3, 5, pavement, false)
end

local function bench(parent, x, z)
	box(parent, "Bench seat", x, 1.2, z, 4.5, 0.35, 1.45, Color3.fromRGB(164, 109, 62), true)
	box(parent, "Bench back", x, 1.85, z - 0.7, 4.5, 0.7, 0.3, Color3.fromRGB(164, 109, 62), false)
	for _, dx in ipairs({-1.5, 1.5}) do box(parent, "Bench leg", x + dx, 0.55, z, 0.35, 1.1, 1, ink, false) end
end

local function plaza(parent)
	local m = P.make("Model", parent, "Foundry Plaza")
	box(m, "Plaza foundation", 0, 0.14, 0, 52, 0.28, 54, pavement, true)
	for x = -2, 2 do
		for z = -2, 2 do
			box(m, "Plaza paver", x * 9, 0.29, z * 9, 8.85, 0.13, 8.85,
				(x + z) % 2 == 0 and P.White or Color3.fromRGB(207, 224, 226), false)
		end
	end
	local spawn = P.make("SpawnLocation", m, "CentralSpawn")
	spawn.CFrame = CFrame.new(0, 0.63, 4)
	spawn.Size = Vector3.new(10, 0.3, 10)
	spawn.Color = teal
	spawn.Material = neon
	spawn.Anchored = true
	spawn.Neutral = true
	spawn.Duration = 0
	spawn.AllowTeamChangeOnTouch = false
	for _, x in ipairs({-20.5, 20.5}) do
		box(m, "Plaza gateway post", x, 6.5, -11, 2.2, 13, 2.4, ink, true)
		box(m, "Gateway stripe", x, 6.5, -9.7, 0.48, 11, 0.22, teal, false, neon)
		bench(m, x, 16)
	end
	local header = box(m, "Factory district marquee", 0, 12.2, -11, 42, 3.6, 1.4, ink, false)
	P.surface(header, "District title", "BRAINROT FACTORY")
	P.surface(header, "Rear district title", "BRAINROT FACTORY", Enum.NormalId.Front)
	box(m, "Marquee top", 0, 14, -11, 43, 0.25, 1.6, teal, false, neon)
	for direction = -1, 1, 2 do
		local sign = box(m, "Plot wayfinding", direction * 16, 4.1, 21, 12, 2.5, 0.48, ink, false)
		local en = direction < 0 and "‹  01 · 02 · 05 · 06" or "03 · 04 · 07 · 08  ›"
		local ru = direction < 0 and "‹  01 · 02 · 05 · 06" or "03 · 04 · 07 · 08  ›"
		P.translate(P.surface(sign, "Directions", en, nil, warm), en, ru)
		box(m, "Wayfinding post", direction * 16, 1.9, 21, 0.42, 3.8, 0.42, ink, false)
	end
	local board = box(m, "Leaderboard", 0, 5.6, -21, 25, 9.7, 0.85, ink, true)
	box(m, "Board plinth", 0, 0.5, -21, 26.5, 0.9, 2.4, Color3.fromRGB(96, 120, 140), true)
	local openPlots = box(m, "AvailablePlots", 19.5, 3.55, -17, 11, 2.75, .55, ink, false)
	box(m, "Availability post", 19.5, 1.45, -17, .48, 2.9, .55, ink, false)
	local available = P.surface(openPlots, "Open plots", "OPEN PLOTS", nil, teal)
	P.translate(available, "OPEN PLOTS", "СВОБОДНЫЕ УЧАСТКИ")
	return spawn, board, available
end

local function setupLighting()
	local atmosphere = Lighting:FindFirstChild("FactoryAtmosphere") or P.make("Atmosphere", Lighting, "FactoryAtmosphere")
	atmosphere.Density = 0.23
	atmosphere.Offset = 0.12
	atmosphere.Color = Color3.fromRGB(209, 230, 255)
	atmosphere.Decay = Color3.fromRGB(177, 195, 221)
	atmosphere.Glare = 0.12
	atmosphere.Haze = 0.85
	local bloom = Lighting:FindFirstChild("FactoryBloom") or P.make("BloomEffect", Lighting, "FactoryBloom")
	bloom.Intensity = 0.17
	bloom.Size = 27
	bloom.Threshold = 1.8
end

function World.build()
	setupLighting()
	local previous = workspace:FindFirstChild("BrainrotWorld")
	if previous and previous:GetAttribute("StaticFormat") == 1 then
		local center = previous.Scenery["Foundry Plaza"]
		return previous.Plots, center.CentralSpawn, center.Leaderboard, center.AvailablePlots["Open plots"].Label
	end
	if previous then previous:Destroy() end
	local root = P.make("Folder", workspace, "BrainrotWorld")
	local scenery = P.make("Folder", root, "Scenery")
	box(scenery, "District ground", 0, -1.05, 0, 474, 2.1, 263, lawn, true, Enum.Material.Grass)
	box(scenery, "Main road", 0, 0.06, 0, 458, 0.11, 44, asphalt, true, Enum.Material.Asphalt)
	for _, z in ipairs({-27, 27}) do
		box(scenery, "Sidewalk", 0, 0.16, z, 462, 0.3, 9, pavement, true, Enum.Material.Concrete)
		box(scenery, "Curb", 0, 0.25, z > 0 and 22.4 or -22.4, 462, 0.48, 0.4, P.White, true)
	end
	for x = -216, 216, 12 do
		if math.abs(x) > 28 then box(scenery, "Road marking", x, 0.129, 0, 6, 0.025, 0.32, warm) end
	end
	for _, x in ipairs({-112, -35, 35, 112}) do
		for stripe = -2, 2 do box(scenery, "Crosswalk", x + stripe * 1.35, 0.132, 0, 0.75, 0.025, 41, P.White) end
	end
	for _, side in ipairs({-1, 1}) do
		for i, x in ipairs({-226, -194, -123, -89, -20, 20, 89, 123, 194, 226}) do
			tree(scenery, x, side * 33, i)
			lamp(scenery, x + (i % 2 == 0 and -4 or 4), side * 28, -side)
		end
		for i, x in ipairs({-213, -107, -16, 16, 107, 213}) do tree(scenery, x, side * 118, i + 1) end
		box(scenery, "Boundary rail", 0, 2.1, side * 129, 474, 0.45, 0.56, ink, true)
		box(scenery, "Boundary footing", 0, 0.65, side * 129, 474, 1.3, 1.7, pavement, true)
		box(scenery, "Side containment", side * 236, 1.4, 0, 1.5, 2.8, 260, pavement, true)
		local wall = box(scenery, "District limit", side * 237, 18, 0, 1, 36, 264, ink, true)
		wall.Transparency = 1
		wall.CastShadow = false
		local endWall = box(scenery, "District limit", 0, 18, side * 131, 476, 36, 1, ink, true)
		endWall.Transparency = 1
		endWall.CastShadow = false
		for _, x in ipairs({-225, -175, -125, -75, -25, 25, 75, 125, 175, 225}) do
			box(scenery, "Boundary pillar", x, 1.5, side * 129, 1.25, 3, 1.25, ink, true)
		end
	end
	shop(scenery, -220, -66, "TOOL DEPOT", "ИНСТРУМЕНТЫ", Color3.fromRGB(80, 150, 193), 1, true)
	shop(scenery, 220, -66, "ROBOT REPAIR", "РЕМОНТ РОБОТОВ", Color3.fromRGB(214, 123, 130), 1, false)
	shop(scenery, -220, 66, "MINT CAFE", "МЯТНОЕ КАФЕ", Color3.fromRGB(102, 169, 138), -1, false)
	shop(scenery, 220, 66, "PARTS & PARCELS", "ДЕТАЛИ И ПОСЫЛКИ", Color3.fromRGB(173, 128, 194), -1, true)
	local spawn, board, available = plaza(scenery)
	local plots = P.make("Folder", root, "Plots")
	root:SetAttribute("StaticFormat",1)
	return plots, spawn, board, available
end

function World.plotFrame(id)
	local column = (id - 1) % 4
	local side = id <= 4 and -1 or 1
	return CFrame.new((column - 1.5) * 106,0,side * 69) * CFrame.Angles(0,side == 1 and math.pi or 0,0)
end

function World.plotShell(parent, id, frame)
	local name = string.format("Plot%02d",id)
	local previous = parent:FindFirstChild(name)
	if previous then return previous, previous["Plot marquee"].OwnerTitle.Label end
	local model = P.make("Model", parent, name)
	model.ModelStreamingMode = Enum.ModelStreamingMode.Persistent
	model:SetAttribute("PlotId", id)
	model:SetAttribute("Owner", 0)
	local function at(name, x, y, z, sx, sy, sz, color, solid)
		return P.part(model, name, Vector3.new(sx, sy, sz), frame * CFrame.new(x, y, z), color, nil, solid)
	end
	at("Plot lot", 0, 0.22, 0, 88, 0.44, 67, Color3.fromRGB(163, 196, 169), true)
	at("Entrance path", 0, 0.18, 36, 14, 0.35, 12, pavement, true)
	for _, x in ipairs({-43.9, 43.9}) do at("Plot border", x, 0.54, 0, 0.35, 0.15, 67, P.White) end
	for _, z in ipairs({-33.3, 33.3}) do at("Plot border", 0, 0.54, z, 88, 0.15, 0.35, P.White) end
	for _, x in ipairs({-8, 8}) do
		at("Gate post", x, 3.4, 32.5, 1.5, 6.2, 1.8, ink, true)
		at("Gate stripe", x, 3.4, 33.42, 0.37, 4.6, 0.2, teal)
	end
	local header = at("Plot marquee", 0, 6.3, 32.5, 17.5, 2.1, 1.1, ink)
	local title = P.surface(header, "OwnerTitle", "FREE PLOT", nil, teal)
	P.translate(title, "FREE PLOT", "СВОБОДНЫЙ УЧАСТОК")
	local display = at("District marker", 13.5, 2.2, 34.5, 4.2, 3.2, 0.56, ink)
	P.surface(display, "Plot number", string.format("%02d", id), nil, warm)
	return model, title
end

return World
