local P = require(script.Parent.Parts)
local C = {}
local function rgb(r, g, b) return Color3.fromRGB(r, g, b) end

local dark = rgb(23, 31, 48)
local white = rgb(253, 251, 240)
local gold = rgb(255, 209, 96)
local pink = rgb(255, 149, 180)
local ball, block, cylinder = Enum.PartType.Ball, Enum.PartType.Block, Enum.PartType.Cylinder
local standing = CFrame.Angles(0, 0, math.pi / 2)
local origins = {
	head = CFrame.new(0, 1.94, 0), torso = CFrame.new(0, 0.47, 0),
	leftArm = CFrame.new(-1.45, 0.48, 0), rightArm = CFrame.new(1.45, 0.48, 0),
	leftLeg = CFrame.new(-0.52, -1.22, 0), rightLeg = CFrame.new(0.52, -1.22, 0),
	leftHand = CFrame.new(-1.45,-.46,0), rightHand = CFrame.new(1.45,-.46,0),
	leftFoot = CFrame.new(-.52,-2.03,0), rightFoot = CFrame.new(.52,-2.03,0),
}
local anchors = {
	head = {"Head"}, torso = {"UpperTorso", "Torso"},
	leftArm = {"RightUpperArm", "Right Arm"}, rightArm = {"LeftUpperArm", "Left Arm"},
	leftLeg = {"RightUpperLeg", "Right Leg"}, rightLeg = {"LeftUpperLeg", "Left Leg"},
	leftHand = {"RightHand","Right Arm"}, rightHand = {"LeftHand","Left Arm"},
	leftFoot = {"RightFoot","Right Leg"}, rightFoot = {"LeftFoot","Left Leg"},
}
local legacyOffset = {
	leftHand=CFrame.new(0,-.94,0), rightHand=CFrame.new(0,-.94,0),
	leftFoot=CFrame.new(0,-.81,0), rightFoot=CFrame.new(0,-.81,0),
}
-- Display coordinates use the camera-facing left and right. Avatar welds use anatomical names.
local function create(model, id, resolve)
	local function piece(bone, label, size, x, y, z, color, shape, rotation, material)
		local base, limb, adjust = resolve(bone)
		if not base then return end
		local offset = (adjust or CFrame.identity) * CFrame.new(x, y, z) * (rotation or CFrame.identity)
		local part = P.part(model, label, Vector3.new(table.unpack(size)), base * offset, color, material, false, shape)
		if limb then
			part.Massless = true
			local weld = Instance.new("Weld")
			weld.Part0, weld.Part1, weld.C0 = limb, part, offset
			weld.Parent = part
			part.Anchored = false
		end
	end
	local function face(separation, y, z, eyeColor)
		for _, side in ipairs({-1, 1}) do
			piece("head", "Eye", {.43,.52,.19}, separation * side, y, z, white, ball)
			piece("head", "Pupil", {.2,.3,.11}, separation * side + .035, y - .02, z - .08, eyeColor or dark, ball)
		end
	end
	local function limbs(arm, pants, shoe)
		for _, side in ipairs({"left","right"}) do
			piece(side .. "Arm", "Sleeve", {.87,1.32,.91},0,-.28,0,arm,ball)
			piece(side .. "Hand", "Glove", {.69,.61,.72},0,0,-.03,shoe,ball)
			piece(side .. "Leg", "Leg", {.92,1.36,.93},0,-.24,0,pants,ball)
			local f = side .. "Foot"
			piece(f, "Boot sole", {1.03,.31,1.55},0,-.19,-.25,white,block)
			piece(f, "Boot", {1.01,.64,1.46},0,.08,-.25,shoe,ball)
			piece(f, "Lace", {.66,.08,.26},0,.34,-.43,white,block)
		end
	end
	if id == "sahur" then
		local brown, honey = rgb(149, 84, 53), rgb(225, 151, 79)
		piece("torso", "Wooden shell", {1.65,2.21,1.54},0,0,0,brown,cylinder,standing)
		piece("head", "Carved head", {1.69,1.93,1.59},0,.07,0,honey,cylinder,standing)
		for i = -2, 2 do
			piece("head", "Wood inlay", {.10,1.4,.1}, i * .31,.05,-.74 + math.abs(i)*.07,brown,block)
		end
		piece("head", "Growth ring", {.14,1.44,1.33},0,.98,0,rgb(244,188,114),cylinder,standing)
		piece("head", "Rounded nose", {.39,.37,.47},0,-.16,-.96,brown,ball)
		piece("head", "Smile", {.48,.18,.12},0,-.44,-.82,dark,ball)
		piece("torso", "Yellow strap", {.43,1.54,.14},0,.1,-.78,gold,block,CFrame.Angles(0,0,-.48))
		piece("torso", "Belt clamp", {.23,2.31,1.65},0,-.56,0,dark,cylinder,standing)
		face(.43,.29,-.86)
		limbs(brown, honey, dark)
	elseif id == "tralala" then
		local blue, navy = rgb(66, 161, 218), rgb(35, 76, 142)
		piece("torso", "Shark body", {2.36,2.12,1.75},0,.02,0,blue,ball)
		piece("torso", "Belly", {1.69,1.6,.63},0,-.07,-.61,white,ball)
		piece("torso", "Dorsal fin", {.35,1.32,1.09},0,.62,.76,navy,ball,CFrame.Angles(.55,0,0))
		piece("torso", "Tail", {.64,.61,1.52},0,-.43,1.04,blue,ball,CFrame.Angles(.32,0,0))
		piece("torso", "Tail fin", {1.51,.23,.74},0,-.17,1.69,navy,ball)
		piece("head", "Shark hood", {2.28,1.85,2.18},0,.08,0,blue,ball)
		piece("head", "Rounded muzzle", {1.87,.74,.95},0,-.39,-.73,white,ball)
		piece("head", "Grin", {1.26,.3,.16},0,-.44,-1.15,navy,ball)
		for i = -2, 2 do piece("head", "Tooth", {.12,.13,.08},i*.19,-.41,-1.226,white,block) end
		face(.57,.23,-.98)
		limbs(blue, navy, rgb(48, 117, 246))
	elseif id == "patapim" then
		local moss, leaf, bark = rgb(98, 156, 75), rgb(157, 202, 91), rgb(116, 84, 64)
		piece("torso", "Forest coat", {2.29,2.18,1.73},0,.02,0,moss,ball)
		piece("torso", "Bark bib", {1.46,1.6,.58},0,-.06,-.66,bark,ball)
		piece("head", "Moss cap", {2.25,1.99,1.81},0,.13,0,moss,ball)
		for i = -2, 2 do
			piece("head", "Leaf tuft", {.68,.46,.85}, i * .38,.86 + (2 - math.abs(i)) * .09,-.1,leaf,ball,CFrame.Angles(0,i*.19,i*.22))
		end
		piece("head", "Leaf stem", {.15,.71,.18},.27,1.1,-.03,bark,ball,CFrame.Angles(0,0,-.35))
		piece("head", "Long nose", {.46,.43,1.08},0,-.14,-.94,rgb(216, 148, 95),ball,CFrame.Angles(-.34,0,0))
		piece("head", "Smile", {.62,.19,.17},0,-.5,-.79,dark,ball)
		face(.48,.29,-.83)
		limbs(moss, bark, leaf)
	elseif id == "saturnita" then
		local plum = rgb(94, 64, 160)
		piece("torso", "Space suit", {2.31,2.19,1.88},0,.03,0,white,ball)
		piece("torso", "Cow patch", {.83,.93,.33},-.58,.33,-.79,plum,ball,CFrame.Angles(0,0,.36))
		piece("torso", "Suit controls", {.67,.58,.27},.34,-.08,-.91,plum,block)
		for i = 1, 14 do
			local angle = i * math.pi / 7
			local orbit = CFrame.Angles(0,0,.24) * CFrame.new(math.cos(angle)*1.87,-.23,math.sin(angle)*1.87)
			piece("torso", "Orbit segment", {.57,.11,.43},orbit.X,orbit.Y,orbit.Z,i % 3 == 0 and gold or pink,ball,nil,Enum.Material.Neon)
		end
		piece("head", "Cow helmet", {2.27,1.77,1.82},0,.14,0,white,ball)
		piece("head", "Muzzle", {1.6,.67,.75},0,-.32,-.83,pink,ball)
		for _, side in ipairs({-1,1}) do
			piece("head", "Nostril", {.19,.12,.1},side*.31,-.27,-1.19,plum,ball)
			piece("head", "Satellite ear", {.7,.37,.46},side*1.03,.43,0,pink,ball,CFrame.Angles(0,0,side*.36))
			piece("head", "Horn", {.38,.73,.41},side*.68,.94,-.04,gold,ball,CFrame.Angles(0,0,-side*.24))
		end
		face(.51,.33,-.86,plum)
		limbs(white, plum, pink)
	end
end

function C.display(parent, id, frame)
	local model = P.make("Model", parent, "Display_" .. id)
	create(model, id, function(bone)
		return frame * origins[bone]
	end)
	return model
end

function C.wear(character, id)
	local model = P.make("Model", character, "FactoryCostume")
	create(model, id, function(bone)
		for index, name in ipairs(anchors[bone]) do
			local limb = character:FindFirstChild(name)
			if limb and limb:IsA("BasePart") then return limb.CFrame, limb, index == 2 and legacyOffset[bone] or nil end
		end
	end)
	return model
end

return C
