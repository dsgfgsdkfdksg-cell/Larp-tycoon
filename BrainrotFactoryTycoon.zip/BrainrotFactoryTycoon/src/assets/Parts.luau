local Parts = {}
Parts.Ink = Color3.fromRGB(23, 35, 57)
Parts.White = Color3.fromRGB(242, 250, 255)

function Parts.make(className, parent, name)
	local item = Instance.new(className)
	item.Name = name
	item.Parent = parent
	return item
end

function Parts.part(parent, name, size, transform, color, material, solid, shape)
	local part = Instance.new("Part")
	part.Name = name
	part.Size = size
	part.CFrame = transform
	part.Color = color
	part.Material = material or Enum.Material.SmoothPlastic
	part.Anchored = true
	part.CanCollide = solid == true
	part.CanTouch = false
	part.CanQuery = solid == true
	part.CastShadow = solid == true
	if shape then part.Shape = shape end
	part.Parent = parent
	return part
end

function Parts.surface(part, name, text, face, color)
	local gui = Parts.make("SurfaceGui", part, name)
	gui.Face = face or Enum.NormalId.Back
	gui.SizingMode = Enum.SurfaceGuiSizingMode.FixedSize
	gui.CanvasSize = Vector2.new(720, 144)
	gui.LightInfluence = 0
	gui.MaxDistance = 100
	local label = Parts.make("TextLabel", gui, "Label")
	label.Size = UDim2.fromScale(1, 1)
	label.BackgroundTransparency = 1
	label.TextColor3 = color or Parts.White
	label.Font = Enum.Font.GothamBold
	label.TextScaled = true
	label.Text = text
	return label
end

function Parts.billboard(part, name, text, width, height, offset, distance)
	local gui = Parts.make("BillboardGui", part, name)
	gui.Size = UDim2.fromOffset(width, height)
	gui.StudsOffsetWorldSpace = Vector3.new(0, offset, 0)
	gui.AlwaysOnTop = true
	gui.MaxDistance = distance or 43
	gui.LightInfluence = 0
	local label = Parts.make("TextLabel", gui, "Label")
	label.Size = UDim2.fromScale(1, 1)
	label.BackgroundColor3 = Parts.Ink
	label.BackgroundTransparency = 0.14
	label.Font = Enum.Font.GothamBold
	label.TextScaled = true
	label.TextWrapped = true
	label.TextColor3 = Parts.White
	label.Text = text
	local pad = Parts.make("UIPadding", label, "Padding")
	pad.PaddingLeft = UDim.new(0, 6)
	pad.PaddingRight = UDim.new(0, 6)
	pad.PaddingTop = UDim.new(0, 3)
	pad.PaddingBottom = UDim.new(0, 3)
	local corner = Parts.make("UICorner", label, "Corner")
	corner.CornerRadius = UDim.new(0, 7)
	return label
end

function Parts.translate(item, en, ru, property)
	item:SetAttribute("TextEN", en)
	item:SetAttribute("TextRU", ru)
	item:SetAttribute("TextProperty", property or "Text")
	game:GetService("CollectionService"):AddTag(item, "FactoryText")
end

function Parts.light(part, color, range, brightness)
	local light = Parts.make("PointLight", part, "Glow")
	light.Color = color
	light.Range = range
	light.Brightness = brightness
	return light
end

return Parts
