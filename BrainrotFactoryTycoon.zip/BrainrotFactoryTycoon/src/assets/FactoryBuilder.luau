local Shared = game:GetService("ReplicatedStorage"):WaitForChild("Brainrot")
local CollectionService = game:GetService("CollectionService")
local Floors = require(Shared.FloorConfig)
local Costumes = require(Shared.CostumeConfig)
local P = require(script.Parent.Parts)
local CostumeBuilder = require(script.Parent.CostumeBuilder)
local F = {}

local rgb = Color3.fromRGB
local ink, white = P.Ink, P.White
local metal, neon = Enum.Material.Metal, Enum.Material.Neon
local gold = rgb(255, 206, 86)
local dark = rgb(37, 48, 66)
local concrete = rgb(119, 146, 155)
local slots = {
	A={-29,-19}, B={-18,-19}, C={-7,-19}, D={4,-19}, E={15,-19}, F={26,-19},
	G={-29,4}, H={-18,4}, I={-7,4}, J={4,4}, K={15,4}, L={26,4},
}
local featurePads = {
	walls={-18,20}, chest={31,-1}, lights={-8,19}, doors={11,24},
	stairs={36,17}, lift={-29,17}, pipes={-34,-24}, roof={3,18}, sign={18,19},
}
local floorInk = {rgb(56,84,91), rgb(80,70,69), rgb(45,73,98), rgb(62,49,94)}

local function at(parent, frame, name, x, y, z, sx, sy, sz, color, material, solid, shape, rotation)
	return P.part(parent, name, Vector3.new(sx, sy, sz), frame * CFrame.new(x,y,z) * (rotation or CFrame.identity), color, material, solid, shape)
end

local function ring(parent, frame, x, y, z, rx, ry, color, vertical)
	for i = 1, 10 do
		local angle = i * math.pi / 5
		local dx, offset = math.cos(angle) * rx, math.sin(angle) * ry
		at(parent, frame, "Ring segment", x+dx, y+(vertical and offset or 0), z+(vertical and 0 or offset),
			1.28, .55, .55, color, neon, false, nil,
			vertical and CFrame.Angles(0,0,angle+math.pi/2) or CFrame.Angles(0,-angle+math.pi/2,0))
	end
end

local function lane(parent, frame, floor, kind)
	local palette = Floors.Names[floor]
	local second = kind == "doublebelt"
	local z = second and -3.6 or -8
	local color = kind == "belt" and gold or palette.color
	at(parent,frame,"Conveyor bed",-1.9,1.1,z,59.8,.58,3.8,ink,metal)
	at(parent,frame,"Rubber belt",-1.9,1.45,z,59.8,.18,2.9,floorInk[floor],Enum.Material.Rubber)
	for _, dz in ipairs({-1.78,1.78}) do
		at(parent,frame,"Conveyor rail",-1.9,1.56,z+dz,59.8,.25,.19,color,neon)
	end
	for x = -28, 24, 7 do
		at(parent,frame,"Roller",x,1.58,z,.26,.11,2.66,white)
		if x % 2 == 0 then at(parent,frame,"Conveyor foot",x,.43,z,.59,.86,3.65,ink,metal) end
	end
end

local function vault(parent, frame, floor, tier)
	local palette = Floors.Names[floor]
	local trim = tier == 1 and palette.color or tier == 2 and gold or white
	if tier == 1 then
		at(parent,frame,"Chest base",31,.32,-8,6.4,.64,5.3,ink,metal)
		at(parent,frame,"Chest body",31,1.4,-8,6.0,1.75,4.9,palette.body,metal)
		at(parent,frame,"Chest lid",31,2.48,-8,6.2,.48,5.1,dark,metal)
	else
		local y = 2.64 + (tier - 2) * .42
		at(parent,frame,"Reinforcement",31,y,-8,6.35,.31,5.19,trim,metal)
		at(parent,frame,"Level indicator",31,y,-5.36,3.4,.19,.11,trim,neon)
		return
	end
	at(parent,frame,"Chest inlet",27.97,1.69,-8,.13,1.05,2.72,trim,neon)
	at(parent,frame,"Vault latch",31,1.75,-5.47,1.2,.95,.25,trim,metal)
end

function F.floorFrame(plotFrame, floor)
	return plotFrame * CFrame.new(0, .65 + (floor - 1) * Floors.Height, 0)
end

function F.floor(parent, plotFrame, floor)
	local frame = F.floorFrame(plotFrame, floor)
	local palette = Floors.Names[floor]
	local m = P.make("Model", parent, string.format("Floor%02d",floor))
	local shell = P.make("Model", m, "Deck")
	local function deck(name,x,z,sx,sz)
		at(shell, frame, name, x,-.24,z,sx,.48,sz,floorInk[floor],metal,true)
	end
	if floor == 1 then
		deck("Foundation slab",0,0,85,59)
	else
		deck("Main slab",-4.9,0,75.2,59)
		deck("Rear stair landing",37.6,-21.3,9.8,16.4)
		deck("Front stair landing",37.6,21.0,9.8,17)
	end
	for _, z in ipairs({-28.8,28.8}) do
		at(shell,frame,"Deck edge",0,-.03,z,84.3,.17,.41,palette.color,neon)
	end
	for _, z in ipairs({-25.4,12.7}) do
		at(shell,frame,"Walkway stripe",-1,.015,z,66,.045,.16,palette.color)
	end
	for i = -4,4 do
		local arrow = at(shell,frame,"Entry stripes",i*1.28,.035,27.65,.6,.035,1.4,gold,nil,false,nil,CFrame.Angles(0,.30,0))
		arrow.Transparency = .15
	end
	for _, x in ipairs({-41,41}) do
		at(shell,frame,"Corner post",x,3.35,-27.85,.8,6.7,.85,ink,metal,true)
		at(shell,frame,"Corner post",x,3.35,27.85,.8,6.7,.85,ink,metal,true)
	end
	local sign = at(shell,frame,"Floor identity",-13,5.1,27.9,18,1.65,.36,ink)
	P.translate(P.surface(sign,"Title",palette.en,nil,palette.color), palette.en, palette.ru)
	local back = P.surface(sign,"Inside title",palette.en,Enum.NormalId.Front,palette.color)
	P.translate(back,palette.en,palette.ru)
	local pedestal = at(m,frame,"Costume plinth",28.5,.38,21,7.5,.77,6.8,ink,metal,true)
	at(m,frame,"Display underglow",28.5,.83,21,7.3,.17,6.6,Costumes[floor].tint,neon)
	at(m,frame,"Display rear",28.5,3.1,18.4,6.5,5,.18,palette.body,metal)
	local name = P.billboard(pedestal,"Costume name",Costumes[floor].name,144,29,6.9,40)
	P.translate(name,Costumes[floor].name,Costumes[floor].ru)
	CostumeBuilder.display(m, Costumes[floor].id, frame * CFrame.new(28.5,3.07,21) * CFrame.Angles(0,math.pi,0))
	return m
end

local function wall(parent, frame, floor)
	local p = Floors.Names[floor]
	local bodyY = floor == 4 and 2 or 3.65
	local function panel(x,z,width,rotation)
		local section = frame * CFrame.new(x,0,z) * CFrame.Angles(0,rotation,0)
		at(parent,section,"Wall plinth",0,bodyY*.5,0,width,bodyY,.78,p.body,metal,true)
		local glass = at(parent,section,"Glazing",0,bodyY+(10.8-bodyY)*.5,0,width,10.8-bodyY,.44,rgb(116,199,238),Enum.Material.Glass,true)
		glass.Transparency = floor == 4 and .57 or .34
		at(parent,section,"Window header",0,11.16,0,width,.77,.64,ink,metal,true)
		at(parent,section,"Facade trim",0,10.88,.49,width,.19,.15,p.color,neon)
		for i = 1, math.floor(width/10) do
			local offset = (i/(math.floor(width/10)+1)-.5)*width
			at(parent,section,"Window mullion",offset,(10.8+bodyY)*.5,0,.28,10.8-bodyY,.61,ink,metal)
		end
	end
	panel(0,-28.3,84,0)
	panel(-41.8,0,56.2,math.pi/2)
	panel(41.8,0,56.2,math.pi/2)
	panel(-23.5,28.3,37,0)
	panel(23.5,28.3,37,0)
	at(parent,frame,"Entrance lintel",0,9.15,28.3,10.2,1.25,1.02,ink,metal,true)
end

local function stairs(parent, frame, color)
	local n, length = 19, 24.8
	for i = 1, n do
		local height = i * Floors.Height / n
		local z = 12.15 - (i-.5) * length / n
		at(parent,frame,"Step",37.5,height-.42,z,7.6,.84,length/n+.06,ink,metal,true)
		at(parent,frame,"Step tread",37.5,height+.02,z+.52,7.45,.06,.22,color,neon)
	end
	for _, x in ipairs({33.47,41.6}) do
		local rail = CFrame.Angles(math.atan(Floors.Height/length),0,0)
		at(parent,frame,"Handrail",x,9.22,-.25,.27,.28,math.sqrt(length^2+Floors.Height^2),color,metal,false,nil,rail)
		for i = 1, 4 do
			local fraction = i/5
			at(parent,frame,"Railing post",x,1.2+fraction*Floors.Height,12.15-fraction*length,.19,2.15,.2,ink,metal)
		end
	end
end

local machineKinds = {
	starter="dropper", dropper="dropper", gold="dropper", dual="dropper", mega="dropper",
	calibrator="console", boost="console", final="console", holo="console", loader="arm",
	arm="arm", press="press", furnace="furnace", plasma="core", super="core", core="core",
	quantum="core", void="core", reactor="core", crystal="crystal", rainbow="crystal",
	laser="laser", rail="laser", portal="portal", turbine="turbine",
}
local function machine(parent, frame, floor, kind, x, z)
	local palette = Floors.Names[floor]
	local accent = kind == "gold" and gold or kind == "void" and rgb(212,106,248) or palette.color
	local body = kind == "gold" and rgb(186,133,53) or palette.body
	local style = machineKinds[kind]
	at(parent,frame,"Machine plinth",x,.2,z,7.3,.4,6.8,ink,metal,true)
	at(parent,frame,"Machine housing",x,.69,z,6.65,.61,6.23,body,metal)
	at(parent,frame,"Identification stripe",x,.95,z+3.19,5.9,.23,.2,accent,neon)
	if style == "dropper" then
		local height = kind == "mega" and 5.4 or 3.4
		at(parent,frame,"Generator column",x,1+height/2,z,3.6,height,3.45,body,metal,true)
		at(parent,frame,"Generator cap",x,1+height,z,4.5,.49,4.25,ink,metal)
		for _, dx in ipairs(kind == "dual" and {-1.72,1.72} or {0}) do
			at(parent,frame,"Generator gauge",x+dx,2.36,z+1.77,.76,1.23,.16,accent,neon)
			at(parent,frame,"Feed arm",x+dx,1+height,(z-8)/2,1.08,.58,math.abs(z+8),body,metal)
			at(parent,frame,"Dispense nozzle",x+dx,1+height,-8,1.43,.78,1.2,accent,metal)
		end
	elseif style == "arm" then
		at(parent,frame,"Servo turret",x,1.25,z,1.05,3.6,3.6,body,metal,true,Enum.PartType.Cylinder,CFrame.Angles(0,0,math.pi/2))
		at(parent,frame,"Arm link",x-.52,2.48,z,.71,2.83,.79,accent,metal,false,nil,CFrame.Angles(0,0,-.5))
		at(parent,frame,"Arm link",x+.56,3.7,z,2.9,.68,.78,body,metal)
		for _, dx in ipairs({1.55,2.22}) do at(parent,frame,"Gripper",x+dx,3.14,z,.2,.62,.45,white,metal) end
	elseif style == "press" then
		for _, dx in ipairs({-2.05,2.05}) do at(parent,frame,"Press post",x+dx,3,z,.55,4,.67,body,metal,true) end
		at(parent,frame,"Press head",x,4.58,z,5.1,.73,3.0,ink,metal)
		at(parent,frame,"Press piston",x,2.97,z,1.4,2.6,1.6,accent,metal)
		at(parent,frame,"Press plate",x,1.78,z,3.55,.38,2.61,white,metal)
	elseif style == "furnace" then
		at(parent,frame,"Furnace chamber",x,2.48,z,5.35,3.4,4.9,body,metal,true)
		at(parent,frame,"Heat opening",x,2.25,z+2.49,3.7,1.68,.19,accent,neon)
		at(parent,frame,"Furnace chimney",x+1.45,4.49,z-.76,1.35,2.86,1.35,ink,metal)
		for i = -2,2 do at(parent,frame,"Heat grille",x+i*.58,2.25,z+2.65,.19,1.7,.18,ink,metal) end
	elseif style == "core" or style == "crystal" or style == "turbine" then
		local energyColor = kind == "void" and rgb(60,17,110) or accent
		local form = style == "crystal" and Enum.PartType.Block or Enum.PartType.Ball
		local formSize = style == "crystal" and Vector3.new(1.7,1.7,1.7) or Vector3.new(2.59,2.35,2.59)
		local orb = P.part(parent,"Production core",formSize,frame*CFrame.new(x,3.24,z)*CFrame.Angles(.56,0,.68),energyColor,neon,false,form)
		ring(parent,frame,x,3.25,z,2.38,2.09,accent,style ~= "turbine")
		for _, dx in ipairs({-2.45,2.45}) do
			at(parent,frame,"Reactor strut",x+dx,2.03,z,.47,2.45,.62,body,metal)
		end
		if kind == "reactor" then
			ring(parent,frame,x,4.87,z,2.69,2.35,gold,false)
			at(parent,frame,"Brainrot capacitor",x,5.33,z,2.3,1.0,2.18,white,neon,false,Enum.PartType.Ball)
			P.light(orb,accent,12,1.25)
		elseif kind == "rainbow" then
			for i = 1, 6 do
				at(parent,frame,"Prism",x-2.44+i*.71,1.64,z+2.53,.38,1.26,.31,Color3.fromHSV(i/6,.75,1),neon)
			end
		end
	elseif style == "portal" then
		ring(parent,frame,x,3.31,z,2.32,2.36,accent,true)
		local field = at(parent,frame,"Portal field",x,3.31,z,.29,3.67,3.67,body,neon,false,Enum.PartType.Cylinder,CFrame.Angles(0,math.pi/2,0))
		field.Transparency = .38
	elseif style == "laser" then
		for _, dx in ipairs({-2.27,2.27}) do at(parent,frame,"Emitter",x+dx,2.48,z,1.1,3,.85,body,metal,true) end
		for i = 1, 3 do at(parent,frame,"Energy beam",x,1.72+.65*i,z,4.6,.1,.12,accent,neon) end
	else
		at(parent,frame,"Controls",x,1.73,z,3.8,1.71,2.55,body,metal,true)
		local panel = at(parent,frame,"Control panel",x,2.69,z+.13,3.48,.43,1.66,accent,neon,false,nil,CFrame.Angles(-.32,0,0))
		if kind == "holo" then
			local screen = at(parent,frame,"Hologram",x,4.12,z,3.7,1.8,.12,accent,neon)
			screen.Transparency = .45
			for i = 1, 3 do at(parent,frame,"Hologram line",x-.42,3.68+i*.28,z+.09,i*.76,.065,.035,white,neon) end
		end
		if kind == "final" then P.light(panel,accent,9,.72) end
	end
end

local function lights(parent, frame, floor, accent)
	for _, x in ipairs({-27,0,27}) do
		at(parent,frame,"Light support",x,7.4,-25.15,.44,14.8,.45,ink,metal)
		at(parent,frame,"Light boom",x,12.95,-18.15,.45,.34,14.5,ink,metal)
		local light = at(parent,frame,"Strip light",x,12.7,-14,5.3,.32,1.5,accent,neon)
		P.light(light,accent,22,1.02)
	end
	if floor == 4 then ring(parent,frame,0,12.5,2,3,3,accent,false) end
end

local function cashSource(model,frame,floor,x,y,z,primary,sidetrack)
	local marker = at(model,frame,"PacketStart",x,y,z,.1,.1,.1,white)
	marker.Transparency = 1
	marker:SetAttribute("Floor",floor)
	marker:SetAttribute("Primary",primary == true)
	marker:SetAttribute("PhaseOffset",primary and 0 or (x+33)*.03)
	local laneZ = sidetrack and -3.6 or -8
	marker:SetAttribute("Waypoint",(frame * CFrame.new(x,1.87,laneZ)).Position)
	marker:SetAttribute("Finish",(frame * CFrame.new(29,1.95,-8)).Position)
	if sidetrack then marker:SetAttribute("Merge",(frame*CFrame.new(24,1.87,laneZ)).Position) end
end

function F.upgrade(parent, plotFrame, spec)
	local frame = F.floorFrame(plotFrame, spec.floor)
	local kind, floor = spec.kind, spec.floor
	local accent = Floors.Names[floor].color
	local m = P.make("Model",parent,spec.id)
	m:SetAttribute("UpgradeId",spec.id)
	CollectionService:AddTag(m,"FactoryBuild")
	local xy = slots[spec.slot]
	if kind == "starter" then
		lane(m,frame,floor,kind)
		vault(m,frame,floor,1)
		machine(m,frame,floor,({"dropper","mega","laser","reactor"})[floor],xy[1],xy[2])
		if floor >= 3 then
			at(m,frame,"Transfer arm",xy[1],3.1,-13.45,1.08,.58,11,Floors.Names[floor].body,metal)
			at(m,frame,"Fabrication nozzle",xy[1],2.92,-8,1.45,.73,1.23,accent,neon)
		end
		local nozzle = ({3.88,5.9,2.6,2.6})[floor]
		cashSource(m,frame,floor,-28.65,nozzle,-8,true,false)
	elseif kind == "speed" or kind == "belt" then
		local x = xy[1]
		for _, dz in ipairs({-2.2,2.2}) do
			at(m,frame,"Upgrade guard",x,1.87,-8+dz,8,.67,.32,accent,neon)
		end
		at(m,frame,"Scanner",x,3.15,-8,.78,.34,4.6,kind=="belt" and gold or accent,metal)
	elseif kind == "doublebelt" then
		lane(m,frame,floor,kind)
		at(m,frame,"Merge guide",26.35,1.51,-5.86,.37,.18,6.02,accent,neon,false,nil,CFrame.Angles(0,-.69,0))
		cashSource(m,frame,floor,-26,2.35,-3.6,false,true)
	elseif kind == "magnetic" or kind == "antigravity" then
		for _, x in ipairs({-26,-12,2,16,26}) do
			for _, side in ipairs({-1,1}) do
				at(m,frame,"Field pylon",x,2.12,-8+side*2,.51,1.42,.57,accent,neon)
			end
			at(m,frame,"Floating roller",x,1.71,-8,.17,.12,2.8,accent,neon)
		end
	elseif kind == "walls" then
		wall(m,frame,floor)
	elseif kind == "chest" then
		vault(m,frame,floor,spec.order < 10 and 2 or 3)
	elseif kind == "stairs" then
		stairs(m,frame,accent)
	elseif kind == "lights" then
		lights(m,frame,floor,accent)
	elseif kind == "doors" then
		local door = at(m,frame,"SecurityGate",0,4.05,28.35,8.8,8.1,.62,accent,metal,true)
		door:SetAttribute("BaseCFrame",door.CFrame)
		for _, x in ipairs({-4.86,4.86}) do at(m,frame,"Door guide",x,4.05,28.35,.55,8.1,1.2,ink,metal,true) end
	elseif kind == "pipes" then
		for i=1,3 do
			at(m,frame,"Steam riser",-39+i*1.41,5.15,-25.7,.65,10.22,.66,i%2==0 and accent or ink,metal)
			at(m,frame,"Steam header",-15,9.5+i*.71,-25.7,45,.4,.44,i%2==0 and accent or ink,metal)
		end
	elseif kind == "lift" then
		at(m,frame,"Elevator controller",-36,.74,21,5.4,1.48,4.7,ink,metal,true)
		at(m,frame,"Lift status",-36,1.57,21,3.5,.27,2.7,accent,neon)
	elseif kind == "roof" then
		at(m,frame,"Roof plane",0,13.56,0,85.7,.73,59.6,dark,metal,true)
		for _, z in ipairs({-29.8,29.8}) do at(m,frame,"Roof lighting",0,13.55,z,86,.48,.34,accent,neon) end
		for _, x in ipairs({-42.7,42.7}) do at(m,frame,"Roof lighting",x,13.55,0,.31,.48,59.7,accent,neon) end
	elseif kind == "sign" then
		local banner = at(m,frame,"Factory marquee",0,16.03,29.05,49,4.65,1.15,ink,metal)
		P.surface(banner,"Brainrot","BRAINROT FACTORY",nil,accent)
		P.surface(banner,"Reverse","BRAINROT FACTORY",Enum.NormalId.Front,accent)
		at(m,frame,"Marquee trim",0,18.55,29.05,50,.3,1.35,accent,neon)
	else
		local x, z = xy[1], xy[2]
		if kind == "rail" and (spec.floor == 2 or spec.floor == 4) or kind == "final" and spec.floor >= 3 then
			x, z = x + (x < 0 and 5 or -5), z < 0 and 7.8 or -23.5
		end
		machine(m,frame,floor,kind,x,z)
		local style = machineKinds[kind]
		if style == "dropper" then
			local y = kind=="mega" and 5.9 or 3.88
			cashSource(m,frame,floor,x,y,-8,false,false)
		elseif style=="core" or style=="furnace" or style=="crystal" or style=="portal" then
			cashSource(m,frame,floor,x,2.52,z<0 and z+3.4 or z-3.4,false,false)
		end
	end
	return m
end

function F.padFrame(plotFrame, upgrade)
	local frame = F.floorFrame(plotFrame,upgrade.floor)
	local spot = featurePads[upgrade.kind] or slots[upgrade.slot]
	local x, z = spot[1], spot[2]
	if not featurePads[upgrade.kind] then z = z < 0 and z + 5.1 or z + 5.2 end
	return frame * CFrame.new(x,.27,z)
end

function F.collectFrame(plotFrame,floor)
	return F.floorFrame(plotFrame,floor) * CFrame.new(32,.28,5)
end

function F.costumeFrame(plotFrame,floor)
	return F.floorFrame(plotFrame,floor) * CFrame.new(27,.27,26)
end

function F.liftFrame(plotFrame,floor)
	return F.floorFrame(plotFrame,floor) * CFrame.new(-34,.3,23)
end

return F
